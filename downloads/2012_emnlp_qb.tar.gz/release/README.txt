
Version 0.1

The quiz bowl data are split into two files: one for questions and the other for
buzzes.

------------------
Questions
------------------
id             - ID for the question
label          - the cannonical label for the question
fold           - Whether the question is train / dev / test
raw            - the raw text of the question
features       - the features we extracted from the raw text with their
corresponding index position

------------------
Buzzes
------------------
question       - The question the user saw (matches questions.csv)
user           - The user who answered the question
answer         - The response given by the user
position       - When the user gave the response
correct        - Whether the answer was correct or not

------------------
Wikipedia Articles
------------------

In addition, there is a set of Wikipedia pages aligned to the answers in the
directory wiki_labels; the name of the file corresponds to the cannonical label
of the questions.
