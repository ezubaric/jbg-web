"""
Given paths to qb dtaset and ontonotes flattened dataset,
this generates graph to compare metrics
"""

import os
import re
import matplotlib
import matplotlib.pyplot as plt
import csv
#path1 = 'G:\\corefdata\\conll-2011\\v2\\data\\train'
path1 = 'conll-train-auto'
path2 = 'berkeleyconll-correct'

font = {'size'   : 14}

matplotlib.rc('font', **font)

labelname = 'Quiz Bowl Mentions'
label2 = 'Quiz Bowl Nested Mentions'
style = ['-', '--', '-.', ':']
col = ['r','g','b','k']
sz = [2,2,1.5,1.5]
st = 0
c = []
for path in [path2,path1]:
    tokencount = 0
    mentions = 0
    x = []
    y = []
    z= []
    fc = []
    fcount = 0
    u = 0
    stack = []
    number = 0
    single = 0
    ana = 0
    sentnum = 0
    for (dirpath, dirnames, filenames) in os.walk(path):
        for filename in filenames:
            fcount += 1

            f=open(os.sep.join([dirpath, filename]),'r');
            infile = []
            ments = []
            lments = []
            for line in f:
                if line != '':
                    words = line.split()
                    if words == []:
                        sentnum += 1
                    if len(words) >= 12:
                        tokencount += 1
                        stuff = words[-1]
                        if stuff != '-':
                            number += sum(range(stuff.count('(')-1))
                            mentions += stuff.count('(')
                            terms = stuff.split('|')
                            for term in terms:
                                if '(' in term:
                                    stack.append('(')
                                    term = term.replace('(','')
                                    t = term.replace(')','')
                                    lments.append(t)
                                if ')' in term:
                                    stack.pop()
                                    term = term.replace(')','')
                                    if term in lments:
                                        lments.remove(term)
                                        ments.append(term)
                                    if len(stack)>0:
                                        number += 1                                
                                if term not in infile:
                                    infile.append(term)
                
                        
                
            for ment in set(ments):
                if ments.count(ment)>1:
                    ana+=ments.count(ment)
                else:
                    single += 1
            x.append(tokencount)
            y.append(ana)
            z.append(number)

            u += len(ments)                
            

    print tokencount, mentions, number, u, single, ana, sentnum
    if path==path2:
        largest = x[-1]
    x = [i for i in x if i <=largest]
    y = y[:len(x)]
    z = z[:len(x)]
    c.append(x)
    c.append(y)
    c.append(z)
    plt.plot(x,y,label = labelname,linewidth = sz[st],linestyle = style[st],color = col[st])
    plt.plot(x,z,label = label2,linewidth = sz[st+1],linestyle = style[st+1],color = col[st+1])
    x = []
    y = []
    z = []
    
    tokencount = 0
    mentions = 0
    labelname='CoNLL Mentions'
    label2='CoNLL Nested Mentions'
    st = 2
with open("density.csv", "wb") as f:
    writer = csv.writer(f)
    writer.writerows(c)
plt.xlabel('Tokens',fontsize=18)
plt.ylabel('Mentions',fontsize=18)
plt.title('QB and CoNLL 2011 coref density in mentions per tokens',fontsize=18)
plt.legend()                            
plt.show()
