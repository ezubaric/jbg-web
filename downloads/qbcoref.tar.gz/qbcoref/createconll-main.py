"""
Given a dump of the database from the annotation website, clipquiz.sql
and a path containing conll format files with parses
this will create conll format files with coref labels
"""
import os
import sys
import string
import re

path = 'berkeleyparse' #path to folder with parses
path1 = 'berkeleyconll-plain' #output folder
f2 = open('clipquiz.sql','r') #dump of database
lines = []
for line in f2:
    lines.append(line)
f2.close()
answers = {}
for line in lines:
    if 'INSERT INTO `answers`' in line:
        words = line.split()
        stuff = ' '.join(words[4:])
        stuff = stuff[1:-2]
        words = stuff.split(',')
        qid = words[1]
        answer = ','.join(words[2:])[1:-4]
        answer = answer.replace('\\','')
        if qid not in answers:
            answers[qid] = answer


    
incorrects = []
rows = {}

for line in lines:
    if 'INSERT INTO `coreferences`' in line:
        words = line.split()
        line = ' '.join(words[4:])
        line = line[1:-2]
        words = line.split(',')
        cid = words[0]
        qid = words[1]
        start = int(words[2])
        end = int(words[3])
        name = words[-2][1:-1]
        group = words[-3]
        phrase = ','.join(words[4:-3])
        phrase = phrase.replace('\\','')
            
        #these can be solved only after heave edits
        if qid in ['83','54','86','95','23','78']:
            continue

        #these can become the test set, still not conlled
        if qid in ['36', '7', '19', '32', '67', '50', '89', '51', '25', '6', '13', '96', '74', '31', '12', '16872', '17900', '16670', '16366', '19903', '19443', '18282', '16559', '21098', '15979', '19084', '14756', '16357', '19419']:
            continue

        if (qid,name) not in rows:
            rows[(qid,name)] = []
            f=open(os.sep.join([path, qid]),'r');
            for row in f:
                rows[(qid,name)].append(row)
            f.close()
        subset = []
        count = 0
        first = 1
        flip = 0
        appending = 0
        lastterm = ''
        suffix = ''
        idx = 0
        temprows = []
        lines = rows[(qid,name)]
        for row in lines:
            if row != '':
                terms = row.split()
                if len(terms) == 12:
                    if terms[3]=='-LRB-':
                        terms[3] = '('
                    if terms[3]=='-RRB-':
                        terms[3] = ')'
                    if terms[3]=='-LSB-':
                        terms[3] = '['
                    if terms[3]=='-RSB-':
                        terms[3] = ']'
                    if terms[3]=='-LCB-':
                        terms[3] = '{'
                    if terms[3]=='-RCB-':
                        terms[3] = '}'
                    if terms[3]=='\*':
                        terms[3] = '*'
                    if terms[3]=="''":
                        if flip==0:
                            flip = 1
                            if first==0:
                                count += 1
                                if appending == 1:
                                    subset.append(" ")
                        else:
                            flip = 0
                        terms[3] = '"'
                    if (lastterm != '"' or (lastterm=='"' and flip==0)) and lastterm not in ['-','(','[','{','...'] and (terms[3][0].isalnum() or terms[3] in ['/','(','[','{', "'em",'=','+','~']) and terms[3] not in ["n't","'s","'ve"] and first==0:
                        count += 1
                        if appending == 1:
                            subset.append(" ")

                    
                    if end>count and end<count+len(terms[3]):
                        suffix = terms[3][-1*(count+len(terms[3])-end):]
                        end = count+len(terms[3])
                    if start<=count and end>=count+len(terms[3]):
                        subset.append(terms[3])
                        appending = 1


                    if start == count and end == count+len(terms[3]):
                        if terms[11] == '-':
                            terms[11] = '('+group+')'
                        elif terms[11][0] != '(' and terms[11][-1] == ')':
                            terms[11] = '('+group+')|'+terms[11]
                        elif terms[11][0] == '(' and terms[11][-1] != ')':
                            terms[11] = terms[11]+'|('+group+')'
                        else:
                            print 'emergency', terms[11], group, qid, name
                    elif start == count:
                        if terms[11] != '-' and '(' in terms[11] and ')' in terms[11]:
                            terms[11] = '('+group+'|'+terms[11]
                        elif terms[11] != '-' and '(' not in terms[11] and ')' in terms[11]:
                            terms[11] = terms[11]+'|('+group
                        elif terms[11] != '-' and '(' in terms[11] and ')' not in terms[11]:
                            terms[11] = '('+group+'|'+terms[11]
                        else:
                            if terms[11] != '-':
                                print terms[11],group
                            terms[11] = '('+group
                    elif end == count+len(terms[3]):
                        if terms[11] != '-' and '(' in terms[11] and ')' in terms[11]:
                            terms[11] = terms[11]+'|'+group+')'
                        elif terms[11] != '-' and '(' not in terms[11] and ')' in terms[11]:
                            terms[11] = terms[11]+'|'+group+')'
                        elif terms[11] != '-' and '(' in terms[11] and ')' not in terms[11]:
                            terms[11] = group+')|'+terms[11]
                        else:
                            if terms[11] != '-':
                                print terms[11],group
                            terms[11] = group+')'
                        
##                    if start == count and end == count+len(terms[3]) and terms[11] == '-':
##                        terms[11] = '('+group+')'
##                    elif start == count and end == count+len(terms[3]) and terms[11] != '-' and terms[11][-1]==')':
##                        terms[11] = '('+group+')|'+ terms[11]
##                    elif start == count and end == count+len(terms[3]) and terms[11] != '-' and terms[11][0]=='(':
##                        terms[11] = terms[11]+'|('+group+')'
##                    elif start == count and end != count+len(terms[3]) and terms[11] == '-':
##                        terms[11] = '('+group
##                    elif start == count and end != count+len(terms[3]) and terms[11] != '-' and terms[11][0]=='(':
##                        terms[11] = '('+group+'|'+terms[11]
##                    elif start != count and end == count+len(terms[3]) and terms[11] == '-':
##                        terms[11] = group+')'
##                    elif start != count and end == count+len(terms[3]) and terms[11] != '-' and terms[11][-1]==')':
##                        terms[11] = terms[11]+'|'+group+')'


                    count += len(terms[3])
                    if end<count:
#                        terms[11] = terms[11]+','+group
                        appending = 0
                        break
                    
                    lastterm = terms[3]
                    first = 0

                    #for answers version
                    #terms[9] = answers[qid]

                    splitter = re.compile(r'(\s+|\S+)')
                    tokens = splitter.findall(row)
                    tokens[-2]=terms[11]
                    row = ''.join(tokens)
                    lines[idx] = row

            idx += 1
        rows[(qid,name)]=lines
        obtained = ''.join(subset)
        phrase = phrase[1:-1]+suffix
        if phrase != obtained.strip():
            print 'halt!',qid,name,phrase, obtained.strip()
        
    
    
print incorrects
print len(incorrects)
for (qid,name) in rows:
    lines = rows[(qid,name)]
    f=open(os.sep.join([path1, qid+'_'+name+'.v2_auto_conll']),'w');
    stack = []
    left = 0
    right = 0
    for line in lines:
##        words = line.split()
##        splitter = re.compile(r'(\s+|\S+)')
##        tokens = splitter.findall(line)
##        if words != [] and len(words)==12:
##            corefterms = words[-1].split(',')
##            if len(corefterms)==1:
##                tokens[-1]='-'
##                line = ''.join(tokens)
##            else:
##                corefterms.remove('--')
##                for term in corefterms:
##                    if term not in stack:
##                        stack.append(term)
##                        if tokens[-1][0]=='(':
##                            tokens[-1] = '('+term+'|'+tokens[-1]
##                        elif tokens[-1][-1]==')':
##                            tokens[-1] = tokens[-1]+'|('+term
##                        elif tokens[-1]=='--':
##                            tokens[-1] = '('+term
##                        left += 1
##                        continue
##                    if term in stack:
##                        stack.remove(term)
##                        if tokens[-1][-1]==')':
##                            tokens[-1] = tokens[-1]+'|'+term+')'
##                        elif tokens[-1][0]=='(':
##                            tokens[-1] = term+')|'+tokens[-1]
##                        elif tokens[-1] == '--':
##                            tokens[-1] = term+')'
##                        right += 1
##                        continue
##                    if corefterms.count(term)==2 and term not in stack:
##                        if tokens[-1] =='--':
##                            tokens[-1] = '('+term+')'
##                        if tokens[-1][-1] == ')':
##                            tokens[-1] = '('+term+')|'+tokens[-1]
##                        if tokens[-1][0] == '(':
##                            tokens[-1] = tokens[-1]+'|('+term+')'
##                        if '(' in tokens[-1] and ')' in tokens[-1]:
##                            print 'ignoring double tags'
##                        continue   
##            line = ''.join(tokens)
        f.write(line)


    #if left-right != 0 or len(stack) != 0:
    #    print qid, name, 'Attention: ',stack
        
    f.close()

    
                        
            
                
                
                
            
