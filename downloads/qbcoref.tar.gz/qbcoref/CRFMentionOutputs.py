"""
Visualising CRF outputs compared to gold
"""
import os
import sys
f1 = open('test.txt','r')
f2 = open('predictions.txt','r')
path = 'borkmentions'
f3 = open('mentioncompare.txt','w')
sents = []
for (dirpath, dirnames, filenames) in os.walk(path):
    for filename in filenames:
        f = open(os.sep.join([dirpath, filename]),'r');
        stack = []
        for line in f:
            words = line.split()
            if words == []:
                sents.append(str(' '.join(stack)))
                stack = []
            if len(words) == 12:
                word = words[3]
                last = words[-1].strip()
                terms = last.split('|')
                for term in terms:
                    if '(' in term and ')' in term:
                        word = '['+word+']'
                    if '(' in term and ')' not in term:
                        word = '['+word
                    if '(' not in term and ')' in term:
                        word = word +']'
                stack.append(word)
                
lines = []
labels = []
for line in f1:
    lines.append(line)
for line in f2:
    labels.append(line)
f1.close()
f2.close()
N = 0
idx = 0
text1 = []
text2 = []
for line in lines:
    label1 = labels[idx].strip()
    idx += 1
    words = line.split()
    
    if words == []:
        f3.write(sents[N]+'\n')
        f3.write(str(' '.join(text1))+'\n')
        f3.write(str(' '.join(text2))+'\n\n')
        text1 = []
        text2 = []
        N += 1
        continue
    label2 = words[-1].strip()
    word = words[0]
    terms = label1.split('-')
    for term in terms:
        if term == 'Singleton':
            word = '['+word+']'
        if term == 'Start':
            word = '['+word
        if term == 'Stop':
            word = word +']'
    text1.append(word)
    word = words[0]
    terms = label2.split('-')
    for term in terms:
        if term == 'Singleton':
            word = '['+word+']'
        if term == 'Start':
            word = '['+word
        if term == 'Stop':
            word = word +']'
    text2.append(word)
  
