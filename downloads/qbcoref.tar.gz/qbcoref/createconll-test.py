import os
import sys
import string

path = 'tempner'
#path = 'test'
f2 = open('clipquiz.sql','r')
lines = []
for line in f2:
    lines.append(line)
f2.close()

incorrects = []
for line in lines:
    if 'INSERT INTO `coreferences`' in line and 'aguha' in line:
        words = line.split()
        line = ' '.join(words[4:])
        line = line[1:-2]
        words = line.split(',')
        cid = words[0]
        qid = words[1]
        start = int(words[2])
        end = int(words[3])
        name = words[-2]
        group = words[-3]
        phrase = ','.join(words[4:-3])
        phrase = phrase.replace('\\','')
            
        #these can be solved only after heave edits
        #if qid in ['83','54','86','95','23','78']:
        #    continue

        
        #if qid != '94':
        #    continue
        if not os.path.isfile(os.sep.join(['tempner', qid])):
            continue
        f=open(os.sep.join([path, qid]),'r');
        rows = []
        subset = []
        count = 0
        first = 1
        flip = 0
        appending = 0
        lastterm = ''
        suffix = ''
        for row in f:
            if row != '':
                terms = row.split()
                if len(terms) == 12:
                    if terms[3]=='-LRB-':
                        terms[3] = '('
                    if terms[3]=='-RRB-':
                        terms[3] = ')'
                    if terms[3]=='-LSB-':
                        terms[3] = '['
                    if terms[3]=='-RSB-':
                        terms[3] = ']'
                    if terms[3]=='-LCB-':
                        terms[3] = '{'
                    if terms[3]=='-RCB-':
                        terms[3] = '}'
                    if terms[3]=='\*':
                        terms[3] = '*'
                    if terms[3]=="''":
                        if flip==0:
                            flip = 1
                            if first==0:
                                count += 1
                                if appending == 1:
                                    subset.append(" ")
                        else:
                            flip = 0
                        terms[3] = '"'
                    if (lastterm != '"' or (lastterm=='"' and flip==0)) and lastterm not in ['-','(','[','{','...'] and (terms[3][0].isalnum() or terms[3] in ['/','(','[','{', "'em",'=','+','~']) and terms[3] not in ["n't","'s","'ve"] and first==0:
                        count += 1
                        if appending == 1:
                            subset.append(" ")
                    
                    if end>count and end<count+len(terms[3]):
                        suffix = terms[3][-1*(count+len(terms[3])-end):]
                        end = count+len(terms[3])
                    if start<=count and end>=count+len(terms[3]):
                        subset.append(terms[3])
                        appending = 1
                    count += len(terms[3])
                    #print terms[3],count
                    if end<count:
                        appending = 0
                        break
                    
                    lastterm = terms[3]
                    first = 0
        obtained = ''.join(subset)
        phrase = phrase[1:-1]+suffix
        if phrase != obtained.strip():
            #print line
            #print suffix
            #print phrase
            #print obtained
            #print count
            #print start, end
            if qid not in incorrects:
                print qid
                print phrase
                print obtained.strip()
                incorrects.append(qid)
print incorrects
print len(incorrects)        
                
                        
                        
            
                
                
                
            
