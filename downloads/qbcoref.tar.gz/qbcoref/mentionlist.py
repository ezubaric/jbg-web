"""
Given a folder with conll data, this converts it to a format used by the LR classifier
"""
import os
import sys
import re
import math
import cPickle
from collections import Counter
from numpy import *

path = 'berkeleyconll-correct'
f2 = open('wabbitdata_w2v.txt','w')
# vocab = Counter()
print 'loading vocab...'
vocab, occ = cPickle.load(open('qb_vocab', 'rb'))
print 'loading We'
We, unknown = cPickle.load(open('glove_We', 'rb'))
print 'loading We'
We2, unknown = cPickle.load(open('word2vec_We', 'rb'))

vdict = {}
for index, word in enumerate(vocab):
    vdict[word] = index

# path = 'conll-test'
# f2 = open('conll_test.txt','w')
#f1 = open('mentionlist.txt','w')
##tokendata = []
##posdata = []
##linedata = []
##mentiondata = []
##groupdata = []
##filedata = []
positives = 0
negatives = 0
for (dirpath, dirnames, filenames) in os.walk(path):
    for filename in filenames:
        tokenlist = []
        poslist = []
        taglist = []
        linelist = []
        stack = []
        stack1 = []
        stack2 = []
        f = open(os.sep.join([dirpath, filename]),'r');
        qid = filename.split('.')[0]
        linnum = 0
        for line in f:
            words = line.strip().split()
            if words == []:
                linnum += 1
            else:
                if '#begin' not in line and '#end' not in line:
                    # vocab[words[3].strip().lower()] += 1
                    tokenlist.append(words[3])
                    poslist.append(words[4])
                    taglist.append(words[-1])
                    linelist.append(linnum)
        index = 0
        for tag in taglist:
            if tag == '-':
                index += 1
                continue
            else:
                terms = tag.split('|')
                for term in terms:
                    if '(' in term and ')' in term:
                        num = term.replace("(", "")
                        num = num.replace(")", "")
                        temp = []
                        temp.append(index)
                        temp.append(index)
                        stack1.append(temp)
                        stack2.append(num)
                    if '(' in term and ')' not in term:
                        num = term.replace("(", "")
                        stack.append((num,index))
                    if ')' in term and '(' not in term:
                        num = term.replace(")", "")
                        i = len(stack)-1
                        for (A,B) in reversed(stack):
                            if A == num:
                                temp = []
                                temp.append(B)
                                temp.append(index)
                                stack1.append(temp)
                                stack2.append(num)
                                del stack[i]
                                break
                            else:
                                i = i - 1
                index += 1
        for i in range(len(stack1)):
            A, B = stack1[i]
            C = stack2[i]
            stuff = qid+'\t'+C+'\t'+str(A)+'\t'+str(B)+'\n'
            #f1.write(stuff)
        f.close()
##        tokendata.append(tokenlist)
##        posdata.append(poslist)
##        linedata.append(linelist)
##        mentiondata.append(stack1)
##        groupdata.append(stack2)
##        filedata.append(qid)

        # all pair data
        window = 3

        print positives
        print negatives
        print filename
        for i in range(len(stack2)):
            for j in range(i,len(stack2)):
                if i == j:
                    continue
                if stack2[i]==stack2[j]:
                    label = '1'
                    positives += 1
                else:
                    label = '-1'
                    negatives += 1
                A, B = stack1[i]
                C, D = stack1[j]
                distance = float(abs(C-B))
                linedist = float(abs(linelist[j]-linelist[i]))
                l1 = float(abs(B-A+1))
                l2 = float(abs(D-C+1))

                preceding1 = ''
                preceding2 = ''
                following1 = ''
                following2 = ''
                lower_ind = max(0, A - window)
                if lower_ind == 0:
                    preceding1 += 'FIRST '
                    lower_ind += 1
                for t, p in zip(tokenlist[lower_ind: A], poslist[lower_ind: A]):
                    preceding1 += t + '_' + p + ' '

                lower_ind = max(0, C - window)
                if lower_ind == 0:
                    preceding2 += 'FIRST '
                    lower_ind += 1
                for t, p in zip(tokenlist[lower_ind: C], poslist[lower_ind: C]):
                    preceding2 += t + '_' + p + ' '

                upper_ind = min(len(tokenlist)-1, B + window)
                for t, p in zip(tokenlist[B + 1: upper_ind], poslist[B + 1: upper_ind]):
                    following1 += t + '_' + p + ' '
                if upper_ind == len(tokenlist)-1:
                    following1 += 'END '
                else:
                    following1 += tokenlist[upper_ind] + '_' + poslist[upper_ind] + ' '

                upper_ind = min(len(tokenlist)-1, D + window)
                for t, p in zip(tokenlist[D + 1: upper_ind], poslist[D + 1: upper_ind]):
                    following2 += t + '_' + p + ' '
                if upper_ind == len(tokenlist)-1:
                    following2 += 'END '
                else:
                    following2 += tokenlist[upper_ind] + '_' + poslist[upper_ind] + ' '
                # if A == 0:
                #     preceding1 = 'FIRST'
                # else:
                #     preceding1 = tokenlist[A-1] + '_' + poslist[A-1]

                # if C == 0:
                #     preceding2 = 'FIRST'
                # else:
                #     preceding2 = tokenlist[C-1] + '_' + poslist[C-1]

                # if B == len(tokenlist)-1:
                #     following1 = 'END'
                # else:
                #     following1 = tokenlist[B+1] + '_' + poslist[B+1]

                # if D == len(tokenlist)-1:
                #     following2 = 'END'
                # else:
                #     following2 = tokenlist[D+1] + '_' + poslist[D+1]
                tokens1 = tokenlist[A:B+1]
                tokens2 = tokenlist[C:D+1]
                between = tokenlist[B:C+1]
                pos1 = poslist[A:B+1]
                pos2 = poslist[C:D+1]
                tok1 = []
                tok2 = []
                for t,p in zip(tokens1,pos1):
                    tok1.append(t+'_'+p)
                tok1 = ' '.join(tok1)
                for t,p in zip(tokens2,pos2):
                    tok2.append(t+'_'+p)
                tok2 = ' '.join(tok2)
                preceding1 = preceding1.replace(':','COLON')
                preceding2 = preceding2.replace(':','COLON')
                following1 = following1.replace(':','COLON')
                following2 = following2.replace(':','COLON')
                tok1 = tok1.replace(':','COLON')
                tok2 = tok2.replace(':','COLON')
                tokens1 = ' '.join(tokens1)
                tokens2 = ' '.join(tokens2)
                t1 = tokens1.replace(':','COLON')
                t2 = tokens2.replace(':','COLON')


                #w2v
                list1 = tokenlist[A:B+1]
                list2 = tokenlist[C:D+1]
                vec1 = zeros((We.shape[0], ))
                wec1 = zeros((We2.shape[0], ))
                for tok in list1:
                    tok = tok.strip().lower()
                    vec1 += We[:, vdict[tok]]
                    wec1 += We2[:, vdict[tok]]
                vec1 /= len(list1)
                wec1 /= len(list1)

                vec2 = zeros((We.shape[0], ))
                wec2 = zeros((We2.shape[0], ))
                for tok in list2:
                    tok = tok.strip().lower()
                    vec2 += We[:, vdict[tok]]
                    wec2 += We2[:, vdict[tok]]
                vec2 /= len(list2)
                wec2 /= len(list2)

                sim1 = (vec1.T.dot(vec2)) / (linalg.norm(vec1) * linalg.norm(vec2))
                sim2 = (wec1.T.dot(wec2)) / (linalg.norm(wec1) * linalg.norm(wec2))

                # print label, sim1, sim2


                f2.write(label+' |Dist:'+str(distance)+' linedist:'+str(linedist)+' sim1:'+str(sim1)+ ' sim2:'+str(sim2)+' len1:'+str(l1)+' len2:'+str(l2)+' |prec1 '+preceding1+' |prec2 '+preceding2+' |foll1 '+following1+' |foll2 '+following2+' |tok1 '+tok1+' |tok2 '+tok2 +' |t1 '+t1+' |t2 '+t2+'\n')
                    
#f1.close()

#vowpal wabbit format
#f2 = open('wabbitdata.txt','w')


print positives
print negatives

# print vocab.most_common(20)
# print len(vocab)
# cPickle.dump((vocab.keys(), vocab), open('qb_vocab', 'wb'), protocol=cPickle.HIGHEST_PROTOCOL)

f2.close()
