"""
Given a path to a folder with conll files and another folder with the same conll files but with coref labels, one group number for every mention,
i.e. conll files with independent mentions
this will give a folder with conll files with mentions from the latter folder and coref group numbers from the former
"""
import os
import sys
import re
import math

path = 'berkeleyconll-correct'

positives = 0
negatives = 0
for (dirpath, dirnames, filenames) in os.walk(path):
    for filename in filenames:
        tokenlist = []
        poslist = []
        taglist = []
        linelist = []
        stack = []
        stack1 = []
        stack2 = []
        stack3 = []
        stack4 = []
        stack5 = []

        fc = open(os.sep.join(['berkeleyconll-automentions2', filename]),'w');
        f = open(os.sep.join([dirpath, filename]),'r');
        qid = filename.split('.')[0]
        linnum = 0
        for line in f:
            words = line.strip().split()
            if words == []:
                linnum += 1
            else:
                if '#begin' not in line and '#end' not in line:
                    tokenlist.append(words[3])
                    poslist.append(words[4])
                    taglist.append(words[-1])
                    linelist.append(linnum)
        index = 0
        for tag in taglist:
            if tag == '-':
                index += 1
                continue
            else:
                terms = tag.split('|')
                for term in terms:
                    if '(' in term and ')' in term:
                        num = term.replace("(", "")
                        num = num.replace(")", "")
                        temp = []
                        temp.append(index)
                        temp.append(index)
                        stack1.append(temp)
                        stack2.append(num)
                    if '(' in term and ')' not in term:
                        num = term.replace("(", "")
                        stack.append((num,index))
                    if ')' in term and '(' not in term:
                        num = term.replace(")", "")
                        i = len(stack)-1
                        for (A,B) in reversed(stack):
                            if A == num:
                                temp = []
                                temp.append(B)
                                temp.append(index)
                                stack1.append(temp)
                                stack2.append(num)
                                del stack[i]
                                break
                            else:
                                i = i - 1
                index += 1
        f.close()

        
        tokenlist = []
        poslist = []
        taglist = []
        linelist = []
        lines = []
        f = open(os.sep.join(['berkeleyconll-pred3', filename]),'r');
        linnum = 0
        for line in f:
            lines.append(line)
            words = line.strip().split()
            if words == []:
                linnum += 1
            else:
                if '#begin' not in line and '#end' not in line:
                    tokenlist.append(words[3])
                    poslist.append(words[4])
                    taglist.append(words[-1])
                    linelist.append(linnum)
        index = 0
        stack = []
        for tag in taglist:
            if tag == '-':
                index += 1
                continue
            else:
                terms = tag.split('|')
                for term in terms:
                    if '(' in term and ')' in term:
                        num = term.replace("(", "")
                        num = num.replace(")", "")
                        temp = []
                        temp.append(index)
                        temp.append(index)
                        stack3.append(temp)
                        stack5.append(num)

                    if '(' in term and ')' not in term:
                        num = term.replace("(", "")
                        stack.append((num,index))
                    if ')' in term and '(' not in term:
                        num = term.replace(")", "")
                        i = len(stack)-1
                        for (A,B) in reversed(stack):
                            if A == num:
                                temp = []
                                temp.append(B)
                                temp.append(index)
                                stack3.append(temp)
                                stack5.append(num)

                                del stack[i]
                                break
                            else:
                                i = i - 1
                index += 1
        f.close()
        
        ind = 0
        stack4 = ['-']*len(stack3)
        for token1 in stack1:
            for token2 in stack3:
                if token1 == token2:
                    stack4[ind] = stack2[ind]
            ind += 1
##        ind = 0
##        groupnum = 1
##        for element in stack4:
##            if element == '-':
##                while str(groupnum) in stack4:
##                    groupnum += 1
##                stack4[ind] = str(groupnum)
##            ind += 1
        
        tokennum = 0
        for line in lines:
            words = line.strip().split()
            if words == []:
                linnum += 1
            else:
                if '#begin' not in line and '#end' not in line:
                    mi = 0
                    tag = words[-1]
                    terms = tag.split('|')
                    for ment in stack3:
                        A = ment[0]
                        B = ment[1]
                        if tokennum==A and tokennum==B:
                            if '('+stack5[mi]+')' not in terms:
                                print 'halt1!',filename
                                print tag, tokennum, ment, stack5[mi], mi
                                print stack3
                                print stack5
                                print stack4
                            for k in range(0,len(terms)):
                                if terms[k]=='('+stack5[mi]+')':
                                    terms[k]='('+str(stack4[mi])+')'
                                    break
                            terms1 = []
                            for term in terms:
                                if '-' not in term:
                                    terms1.append(term)
                            tag = '|'.join(terms1)
                        if tokennum==A and tokennum!=B:
                            if '('+stack5[mi] not in terms:
                                print 'halt2!',filename
                                print tag, tokennum, ment, stack5[mi]
                                print stack3
                                print stack5
                                print stack4
                            for k in range(0,len(terms)):
                                if terms[k]=='('+stack5[mi]:
                                    terms[k]='('+str(stack4[mi])
                                    break
                            terms1 = []
                            for term in terms:
                                if '-' not in term:
                                    terms1.append(term)
                            tag = '|'.join(terms1)
                        if tokennum!=A and tokennum==B:
                            if stack5[mi]+')' not in terms:
                                print 'halt3!',filename
                                print tag, tokennum, ment, stack5[mi]
                                print stack3
                                print stack5
                                print stack4
                            for k in range(0,len(terms)):
                                if terms[k]==stack5[mi]+')':
                                    terms[k]=str(stack4[mi])+')'
                                    break
                            terms1 = []
                            for term in terms:
                                if '-' not in term:
                                    terms1.append(term)
                            tag = '|'.join(terms1)
                        mi += 1
                    tokennum += 1
                    words[-1] = tag
                    line = '\t'.join(words)+'\n'
            fc.write(line)
                        
        fc.close()
                

