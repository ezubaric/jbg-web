"""
Given a path to a folder with conll files and the predictions of CRF labels
this will give a folder with conll files with CRF mention text spans with coref group numbers from the former folder
"""
import os
import sys
import re
import math

path = 'berkeleyconll-correct'

crfs = []
f1 = open('totalpred.txt','r')
for line in f1:
    crfs.append(line.strip())
f1.close()

found = 0
notfound = 0
notfound1 = 0


ci = 0
for (dirpath, dirnames, filenames) in os.walk(path):
    for filename in filenames:
        tokenlist = []
        crflist = []
        poslist = []
        taglist = []
        linelist = []
        stack = []
        stack1 = []
        stack2 = []
        stack3 = []

        fc = open(os.sep.join(['berkeleyconll-automentionsCRF', filename]),'w');
        f = open(os.sep.join([dirpath, filename]),'r');
        qid = filename.split('.')[0]
        linnum = 0
        lines = []
        for line in f:
            lines.append(line)
            words = line.strip().split()
            if words == []:
                ci+=1
                linnum += 1
            else:
                if '#begin' not in line and '#end' not in line:
                    crflist.append(crfs[ci])
                    ci+=1
                    tokenlist.append(words[3])
                    poslist.append(words[4])
                    taglist.append(words[-1])
                    linelist.append(linnum)
        index = 0
        for tag in taglist:
            if tag == '-':
                index += 1
                continue
            else:
                terms = tag.split('|')
                for term in terms:
                    if '(' in term and ')' in term:
                        num = term.replace("(", "")
                        num = num.replace(")", "")
                        temp = []
                        temp.append(index)
                        temp.append(index)
                        stack1.append(temp)
                        stack2.append(num)
                    if '(' in term and ')' not in term:
                        num = term.replace("(", "")
                        stack.append((num,index))
                    if ')' in term and '(' not in term:
                        num = term.replace(")", "")
                        i = len(stack)-1
                        for (A,B) in reversed(stack):
                            if A == num:
                                temp = []
                                temp.append(B)
                                temp.append(index)
                                stack1.append(temp)
                                stack2.append(num)
                                del stack[i]
                                break
                            else:
                                i = i - 1
                index += 1
        f.close()

        if len(tokenlist) != len(crflist):
            print tokenlist
            print crflist
            print 'halt!', filename
        index = 0
        stack = []
        for crf in crflist:
            terms = crf.split('-')
            for term in terms:
                if term == 'Singleton':
                    temp = []
                    temp.append(index)
                    temp.append(index)
                    stack3.append(temp)
                if term == 'Start':
                    stack.append((index,'Start'))
                if term == 'Stop':
                    i = len(stack)-1
                    for (A,B) in reversed(stack):
                        if B == 'Start':
                            temp = []
                            temp.append(A)
                            temp.append(index)
                            stack3.append(temp)
                            #print stack
                            del stack[i]
                            break
                        else:
                            i = i - 1
            
            index += 1                
        stack4 = []
        stack5 = []
        groupnum = 1
        notfound1 += len(stack1)
        for ment in stack3:
            t = 0
            
            for q in range(0,len(stack1)):
                if ment==stack1[q]:
                    found += 1
                    stack4.append(ment)
                    stack5.append(stack2[q])
                    t = 1
                    notfound1 -= 1
                    break
            if t == 0:
                notfound += 1
                while str(groupnum) in stack4:
                    groupnum += 1
                stack4.append(ment)
                stack5.append(groupnum)
            
        
            

            
            
        
        tokennum = 0
        for line in lines:
            words = line.strip().split()
            if words == []:
                linnum += 1
            else:
                if '#begin' not in line and '#end' not in line:
                    mi = 0
                    terms = []
                    for ment in stack4:
                        A = ment[0]
                        B = ment[1]
                        if tokennum==A and tokennum!=B:
                            terms.append('('+str(stack5[mi]))
                        if tokennum==A and tokennum==B:
                            terms.append('('+str(stack5[mi])+')')
                        if tokennum!=A and tokennum==B:
                            terms.append(str(stack5[mi])+')')
                        
                        mi += 1
                    if len(terms)>0:
                        tag = '|'.join(terms)
                    else:
                        tag = '-'
                    tokennum += 1
                    words[-1] = tag
                    line = '\t'.join(words)+'\n'
            fc.write(line)
                        
        fc.close()
                

print 'here'
print found
print notfound
print notfound1
