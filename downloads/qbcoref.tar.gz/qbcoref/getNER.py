"""
Given a folder with conll format files with prses done using Berkelet preprocessing pipeline
this will populate the NER column of the conll files using Stanford NER
Use correctNER.py on that folder to change a sequence of NER tags line PERSON PERSON PERSOn to the conll format of (PERSON*, *, *)
"""

import os
import sys
import re
import string
import shutil
import subprocess

path = 'berkeleyparse'
path1 = 'berkeleyner'
path2 = 'testdir'
command = "java -cp stanford-ner/stanford-ner.jar -mx400m edu.stanford.nlp.ie.crf.CRFClassifier -loadClassifier stanford-ner/classifiers/english.muc.7class.distsim.crf.ser.gz -testFile testdir/temp > testdir/temp.ner"

for (dirpath, dirnames, filenames) in os.walk(path):
    for filename in filenames:
        lines = []
        f=open(os.sep.join([dirpath, filename]),'r');
        f1=open(os.sep.join([path2, 'temp']),'w');
	for line in f:
            lines.append(line)
            if line != '':
                words = line.split()
                if len(words) == 12:
                    term = words[3]+'\n'
                    f1.write(term)
        f.close()
	f1.close()
	ret = os.system(command)
	print ret
	f=open(os.sep.join([path1, filename]),'w');
	f1=open(os.sep.join([path2, 'temp.ner']),'r');
	ners = []
	for line in f1:
            words = line.split()
            if words != []:
                ners.append(words[-1].strip())
	f1.close()
	print len(ners)
	idx = 0
	for line in lines:
            if line != '':
                words = line.split()
                if len(words) == 12:
                    splitter = re.compile(r'(\s+|\S+)')
                    tokens = splitter.findall(line)
                    term = ners[idx]
                    idx += 1
                    if term == 'O':
                        term = '*'
                    tokens[20] = term
                    line = ''.join(tokens)
	    f.write(line)
	f.close()
			
						
						
					
				
			
						
					
					
