"""
Given a folder path with gold data, and a file containing the predictions from classification
this generates a folder path with evaluated coref labels, useful for running the batch scorer
"""
import os
import sys
import re
import math

path = 'berkeleyconll-correct'
path1 = 'conll-test-gen'
f2 = open('our_qb_predictions.txt','r')
labels1 = []
labels2 = []
for line in f2:
    terms = line.strip().split()
    labels1.append(int(terms[0]))
    labels2.append(int(terms[1]))
f2.close()
    
    
lindex = 0
for (dirpath, dirnames, filenames) in os.walk(path):
    for filename in filenames:
        tokenlist = []
        poslist = []
        taglist = []
        taglist1 = []
        linelist = []
        stack = []
        stack1 = []
        stack2 = []
        stack3 = []
        lines = []
        f = open(os.sep.join([dirpath, filename]),'r');
        fc = open(os.sep.join([path1, filename]),'w');

        qid = filename.split('.')[0]
        linnum = 0
        for line in f:
            lines.append(line)
            words = line.strip().split()
            if words == []:
                linnum += 1
            else:
                if '#begin' not in line and '#end' not in line:
                    tokenlist.append(words[3])
                    poslist.append(words[4])
                    taglist.append(words[-1])
                    linelist.append(linnum)
        
        index = 0

        for tag in taglist:
            if tag == '-':
                index += 1
                continue
            else:
                terms = tag.split('|')
                for term in terms:
                    if '(' in term and ')' in term:
                        num = term.replace("(", "")
                        num = num.replace(")", "")
                        temp = []
                        temp.append(index)
                        temp.append(index)
                        stack1.append(temp)
                        stack2.append(num)
                    if '(' in term and ')' not in term:
                        num = term.replace("(", "")
                        stack.append((num,index))
                    if ')' in term and '(' not in term:
                        num = term.replace(")", "")
                        i = len(stack)-1
                        for (A,B) in reversed(stack):
                            if A == num:
                                temp = []
                                temp.append(B)
                                temp.append(index)
                                stack1.append(temp)
                                stack2.append(num)
                                del stack[i]
                                break
                            else:
                                i = i - 1
                index += 1

        f.close()
        #fc.close()

        data = {}
        groupnum = 1
        for i in range(len(stack2)):
            for j in range(i,len(stack2)):
                if i==j:
                    continue
                
                label = labels2[lindex]
                labelg = labels1[lindex]
                if stack2[i]==stack2[j]:
                    if labelg != 1:
                        print 'halt!'
                lindex += 1
                if label == 1:
                    flip = 0
                    for stuff in data:
                        if stack1[i] in data[stuff]:
                            if stack1[j] not in data[stuff]:
                                data[stuff].append(stack1[j])
                                flip = 1
                        if stack1[j] in data[stuff]:
                            if stack1[i] not in data[stuff]:
                                data[stuff].append(stack1[i])
                                flip = 1
                        if stack1[j] in data[stuff] and stack1[i] in data[stuff]:
                            flip = 1
                    if flip == 0:
                        data[groupnum] = []
                        data[groupnum].append(stack1[i])
                        data[groupnum].append(stack1[j])
                        groupnum += 1
        ndata = {}
        for key in data:
            l = data[key]
            for ment in l:
                A = ment[0]
                B = ment[1]
                ndata[(A,B)] = key
            
        stack3 = []
        for ment in stack1:
            A = ment[0]
            B = ment[1]
            if (A,B) in ndata:
                stack3.append(ndata[(A,B)])
            else:
                stack3.append(groupnum)
                groupnum += 1

        if len(stack2) != len(stack3):
            print 'halt!'
            print stack2
            print stack3

        tokennum = 0
        for line in lines:
            words = line.strip().split()
            if words == []:
                linnum += 1
            else:
                if '#begin' not in line and '#end' not in line:
                    mi = 0
                    tag = words[-1]
                    terms = tag.split('|')
                    for ment in stack1:
                        A = ment[0]
                        B = ment[1]
                        if tokennum==A and tokennum==B:
                            if '('+stack2[mi]+')' not in terms:
                                print 'halt1!',filename
                                print tag, tokennum, ment, stack2[mi]
                                print stack1
                                print stack2
                                print stack3
                            for k in range(0,len(terms)):
                                if terms[k]=='('+stack2[mi]+')':
                                    terms[k]='('+str(stack3[mi])+')'
                                    break
                            tag = '|'.join(terms)
                        if tokennum==A and tokennum!=B:
                            if '('+stack2[mi] not in terms:
                                print 'halt2!',filename
                                print tag, tokennum, ment, stack2[mi]
                                print stack1
                                print stack2
                                print stack3
                            for k in range(0,len(terms)):
                                if terms[k]=='('+stack2[mi]:
                                    terms[k]='('+str(stack3[mi])
                                    break
                            tag = '|'.join(terms)
                        if tokennum!=A and tokennum==B:
                            if stack2[mi]+')' not in terms:
                                print 'halt3!',filename
                                print tag, tokennum, ment, stack2[mi]
                                print stack1
                                print stack2
                                print stack3
                            for k in range(0,len(terms)):
                                if terms[k]==stack2[mi]+')':
                                    terms[k]=str(stack3[mi])+')'
                                    break
                            tag = '|'.join(terms)
                        mi += 1
                    tokennum += 1
                    words[-1] = tag
                    line = '\t'.join(words)+'\n'
            fc.write(line)
                        
        fc.close()                    
        
               

                            




