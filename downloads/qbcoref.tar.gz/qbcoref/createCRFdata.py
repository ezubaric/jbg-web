"""
Given folder path with coll-fied files and coref labels
this creates a file with data for CRF training/testing
"""

import os
import sys
import re
import cPickle
from dtree_util import *


parents = {}
          

command = 'java -mx200m -cp ./old-coref/stanford-parser/stanford-parser.jar:./old-coref/stanford-parser/stanford-parser-3.3.1-models.jar edu.stanford.nlp.parser.lexparser.LexicalizedParser -outputFormat "typedDependencies" -outputFormatOptions "basicDependencies" -tokenized edu/stanford/nlp/models/lexparser/englishPCFG.ser.gz temp.txt'

        
print "here"
path = 'berkeleyconll-correct'
f1 = open('totalCRFdata.txt','w')
#f1 = open('CRFMentionTrain.txt','w')
#f2 = open('CRFMentionTest.txt','w')
#f3 = open('CRFMentionTestNoLabels.txt','w')
data = []
for (dirpath, dirnames, filenames) in os.walk(path):
    for filename in filenames:
        f = open(os.sep.join([dirpath, filename]),'r');
        qid = filename.split('.')[0]
        print qid
        rels = []
        lines = []
        phrase = []
        for line in f:
            words = line.split()
            lines.append(line)
            if words == []:
                pars = ['']*len(phrase)
                t = open('temp.txt','w')
                t.write(' '.join(phrase))
                t.close()
                phrase = []
                parser_out = os.popen(command).readlines()
                for text in parser_out:
                    if len(text.split('(')) == 2:
                        rel = text.split('(')[0]
                        par = text.split('(')[1].split(',')[0]
                        chi = text.split('(')[1].split(',')[1][:-2]
                        #print rel,par,chi
                        idx = int(chi.split('-')[-1].strip())-1
                        rel = rel+'-'+par.split('-')[0]
                        pars[idx] = rel
                rels.append(pars)
            if len(words) == 12:
                word = words[3]
                phrase.append(word)
                
        #print rels
        stack = []
        idx = 0
        i = 0
        for line in lines:
            label = ''
            words = line.split()
            if words == []:
                data.append('')
                idx += 1
                i = 0
            if len(words) == 12:
                text = words[3]
                dep = rels[idx][i]
                pos = words[4]
                ner = words[-2]
                last = words[-1].strip()
                terms = last.split('|')
                num = len(stack)
                i += 1
                for term in terms:
                    if '(' in term and ')' in term:
                        num += 1
                        label += 'Singleton-'
                    elif '(' in term:
                        stack.append('(')
                        num += 1
                        label += 'Start-'
                    elif ')' in term:
                        stack.pop()
                        label += 'Stop-'
                label = 'lvl'+str(num)+'-'+label
                #print text,pos,ner,dep,label[:-1]
                data.append(text+' '+pos+' '+ner+' '+dep+' '+label[:-1])


total = len(data)
train = total*8/10
idx = 0
for line in data:
    stuff = ' '.join(line.split()[:-1])
    f1.write(stuff+'\n')
##    if idx < train:
##        f1.write(line+'\n')
##    else:
##        f2.write(line+'\n')
##        stuff = ' '.join(line.split()[:-1])
##        f3.write(stuff+'\n')
    idx += 1
                    
            
