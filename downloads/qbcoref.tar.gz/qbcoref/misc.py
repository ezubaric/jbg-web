f = open('totalpred.txt','r')
prev = ''
stack = 0
index = 0
count = 0
for line in f:
    index+=1
    words = line.strip().split('-')
    if len(words) != 0:
        for word in words:
            if word=='Start':
                stack += 1
                count += 1
            if word=='Stop':
                stack -= 1
            if word=='Singleton':
                count += 1
            
    else:
        if stack != 0:
            print 'index'
        stack = 0
print 'done'
f.close()
print count
