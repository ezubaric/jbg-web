import os
import sys
import re
import string
import shutil
import subprocess

path = 'data-CRF'
path1 = 'data-CRF1'

for (dirpath, dirnames, filenames) in os.walk(path):
    for filename in filenames:
        nerlist = []
        f=open(os.sep.join([dirpath, filename]),'r');
        f1=open(os.sep.join([path1, filename]),'w');
        lines = []
        for line in f:
            lines.append(line)
            words = line.strip().split()
            if words != []:
                if '#begin' not in line and '#end' not in line:
                    nerlist.append(words[-2])
            else:
                nerlist.append('_')
        f.close()
        newner = []
        fleg = 0
        for ner in nerlist:
            if ner == '*':
                if fleg == 1:
                    if newner[-1] == '*':
                        newner[-1] += ')'
                    else:
                        newner[-1] = newner[-1][:-1]+')'
                    fleg = 0
                newner.append(ner)
            elif ner == '_':
                if fleg == 1:
                    if newner[-1] == '*':
                        newner[-1] += ')'
                    else:
                        newner[-1] = newner[-1][:-1]+')'
                    fleg = 0
                    
            else:
                if fleg == 0:
                    newner.append('('+ner+'*')
                    fleg = 1
                else:
                    newner.append('*')
        idx = 0
        for line in lines:
            words = line.strip().split()
            if words != []:
                if '#begin' not in line and '#end' not in line:
                    words[-2] = newner[idx]
                    line = '\t'.join(words)
                    idx += 1
            f1.write(line+'\n')
        f1.close()
            
                    
                
            
