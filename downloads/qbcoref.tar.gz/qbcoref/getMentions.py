"""
Given a folder of conll format files, this generates mentions using the Berkeley coref software
It takes a file at a time and predicts corefs using pretrained models, the results can be disregarded but the candidate mentions are what the Berkeley coref uses 
"""

import os
import sys
import re
import string
import shutil
import subprocess

path1 = 'bork'
newpath = 'testdir'
path2 = 'berkeleymentions'
command = 'java -jar -Xmx30g berkeleycoref/berkeleycoref-1.0.jar ++berkeleycoref/base.conf -execDir results/ -modelPath models/coref-trainplusdev-final.ser -conllEvalScriptPath scr/scorer.pl -testPath testdir -numberGenderData gender.data -mode PREDICT -outputPath ./testdir1/res';
newpath1 = 'testdir1'
terms = command.split(' ')
for (dirpath, dirnames, filenames) in os.walk(path1):
    for filename in filenames:
        print filename
        shutil.copy2(os.sep.join([dirpath, filename]), os.sep.join([newpath, filename]))
        subprocess.Popen(terms, stderr=subprocess.STDOUT, stdout=subprocess.PIPE).communicate()[0]
        shutil.copy2(os.sep.join([newpath1, 'res']), os.sep.join([path2, filename]))        
        os.remove(newpath+"/"+filename)
        os.remove(newpath1+"/"+'res')
        
    
    
