from numpy import *
import cPickle, gzip, gc, glob, sys, os
from collections import Counter

vec_file = gzip.open('../phrase2vec/data/glove.840B.300d.txt.gz', 'r')
all_vocab = {}

print 'loading vocab...'

vocab, occ = cPickle.load(open('qb_vocab', 'rb'))


for line in vec_file:
    split = line.split()
    # if split[0] in vocab:
    if occ[split[0]] > 0:
        all_vocab[split[0]] = array(split[1:])
        all_vocab[split[0]] = all_vocab[split[0]].astype(float)

print len(vocab), len(all_vocab)
d = len(all_vocab['the'])

We = empty( (d, len(vocab)) )

print 'creating We for ', len(vocab), ' words'
unknown = []

for i in range(0, len(vocab)):
    word = vocab[i]

    try:
        We[:, i] = all_vocab[word]
    except KeyError:
        unknown.append(word)
        if i == 0:
            We[:, i] = all_vocab['unknown']
        else:
            sel = random.randint(0, i, 5)
            print word
            We[:, i] = average(We[:, sel], axis=1).ravel()

print 'unknown: ', len(unknown)
print We.shape

print 'dumping...'
cPickle.dump( [We, unknown], open('glove_We', 'wb'), protocol=cPickle.HIGHEST_PROTOCOL)