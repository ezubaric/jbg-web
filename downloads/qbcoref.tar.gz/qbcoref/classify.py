import nltk.classify.util
import nltk.metrics
from nltk.classify.scikitlearn import SklearnClassifier
from sklearn.linear_model import LogisticRegression
from nltk.corpus import stopwords
import random, collections


# number feats / raw words dont help or hurt
# f-score without prec1 and prec2: 40.6
# f-score without fall1 and fall2: 38.3
# f-score without tok1 and tok2: 21.2
# conclusion: increase prec and fall windows should help
    # added pos tag to prec and fall, increased window to 3: 47.7
    # window 5: 47.2

def read_data(fname):
    feats = {}
    # feats = []
    # bad_ns = ['t1', 't2', 'tok1', 'tok2']
    bad_ns = []
    with open(fname, 'r') as f:
        for lnum, line in enumerate(f):
            curr_feats = {}
            s = line.split('|')
            label = int(float(s[0].strip()))
            for x in s[1].strip().split():
                key, val = x.split(':')
                if key != 'sim1' and key != 'sim2':
                    curr_feats[key] = int(float(val))
                else:
                    curr_feats[key] = float(val)

            for ns in s[2:]:
                nsfeats = ns.strip().split()
                ns = nsfeats[0]
                rfeats = nsfeats[1:]
                if ns not in bad_ns:
                    for feat in rfeats:
                        curr_feats[ns + '_' + feat] = 1

            feats[lnum] = (curr_feats, label)
            # feats.append((curr_feats, label))

    # random.shuffle(feats)
    return feats

def pairwise_prediction(fname):

    refsets = collections.defaultdict(set)
    testsets = collections.defaultdict(set)

    with open(fname, 'r') as f:
 
        for index, line in enumerate(f):
            s = line.strip().split()
            actual = int(s[0])
            pred = int(s[1])
            refsets[actual].add(index)
            testsets[pred].add(index)

    return refsets, testsets

def ontonotes(fname):

    refsets = collections.defaultdict(set)
    testsets = collections.defaultdict(set)

    with open(fname, 'r') as f:
 
        for index, line in enumerate(f):
            s = float(line.strip())
            if s > -1:
                s = 1
            else:
                s = -1
            testsets[s].add(index)

    with open('ontotestlabels.txt', 'r') as f:
 
        for index, line in enumerate(f):
            s = int(line.strip())
            refsets[s].add(index)

    return refsets, testsets

def write_predictions(refsets, testsets, num_feats, test_name):

    outfile = open('qb_predictions' + test_name + '.txt', 'w')
    print 'num_feats: ', num_feats

    for lnum in range(0, num_feats):
        actual = -1
        if lnum in refsets[1]:
            actual = 1

        pred = -1
        if lnum in testsets[1]:
            pred = 1
            
        outfile.write(str(actual) + ' ' + str(pred) + '\n')

    outfile.close()


if __name__ == '__main__':

    feats = read_data('wabbitdata_auto.txt')
    keys = feats.keys()

    # train_files = ['12f', '12g', '12h', '12i', '12j']
    # test_files = ['12at', '12bt', '12ct', '12dt', '12et']
    refsets = collections.defaultdict(set)
    testsets = collections.defaultdict(set)
    size = len(keys) / 5 + 1

    print size

    for i in range(0, 5):


        # train_feats = read_data('wabbitdata_' + train_files[i] + '.txt')
        # test_feats = read_data('wabbitdata_' + test_files[i] + '.txt')

        offset = i * size
        test = keys[offset:offset + size]
        test_feats = [feats[key] for key in test]
        train_feats = [feats[key] for key in keys[0:offset] + keys[offset + size:]]

        print 'training fold ', i
        classifier = SklearnClassifier(LogisticRegression(C=10))
        classifier.train(train_feats)

        for index, test_ind in enumerate(test):
            instance, label = test_feats[index]
            refsets[label].add(test_ind)
            observed = classifier.classify(instance)
            testsets[observed].add(test_ind)
        
    write_predictions(refsets, testsets, len(keys), 'auto')


    print 'our qb 1 f-score: ', nltk.metrics.f_measure(refsets[1], testsets[1])
    print 'our qb -1 f-score: ', nltk.metrics.f_measure(refsets[-1], testsets[-1])

    refsets, testsets = ontonotes('old_ontonotes_predictions.txt')
    print 'our onto 1 f-score: ', nltk.metrics.f_measure(refsets[1], testsets[1])
    print 'our onto -1 f-score: ', nltk.metrics.f_measure(refsets[-1], testsets[-1])

    refsets, testsets = pairwise_prediction('berkeley-compare.txt')
    print 'berkeley-trqb qb 1 f-score: ', nltk.metrics.f_measure(refsets[1], testsets[1])
    print 'berkeley-trqb qb -1 f-score: ', nltk.metrics.f_measure(refsets[-1], testsets[-1])

    refsets, testsets = pairwise_prediction('berkeley-compare-tronto.txt')
    print 'berkeley-tronto qb 1 f-score: ', nltk.metrics.f_measure(refsets[1], testsets[1])
    print 'berkeley-tronto qb -1 f-score: ', nltk.metrics.f_measure(refsets[-1], testsets[-1])

    refsets, testsets = pairwise_prediction('onto-tronto.txt')
    print 'berkeley-tronto onto 1 f-score: ', nltk.metrics.f_measure(refsets[1], testsets[1])
    print 'berkeley-tronto onto -1 f-score: ', nltk.metrics.f_measure(refsets[-1], testsets[-1])


