"""
Given path to the conll scorer,
and two folders containing corresponding conll files with coref labels, this gives the scores for the entire dataset
"""
import os
import sys



command = 'scr/scorer.pl all '
names = []
numbers = []
mfsc=[]
mpsc=[]
mrsc=[]
bfsc=[]
bpsc=[]
brsc=[]
cfsc=[]
cpsc=[]
crsc=[]
for filename in os.listdir('berkeleyconll-automentionsCRF'):
        command1 = command+os.sep.join(['berkeleyconll-automentionsCRF', filename])+' '+os.sep.join(['conll-auto-gen', filename])+' > temp.txt'
        #print filename
        os.system(command1)
        f = open('temp.txt','r')
        fleg = 0
        score = 0.0
        mfleg=0
        bfleg=0
        cfleg=0
        for line in f:
                
                if 'muc' in line:
                        mfleg = 1
                if mfleg == 1 and 'Coreference' in line:
                        num = line.strip().split()[-1]
                        mfsc.append(float(num[:-1]))
                        num = line.strip().split()[5]
                        mrsc.append(float(num[:-1]))
                        num = line.strip().split()[10]
                        mpsc.append(float(num[:-1]))
                        mfleg = 0
                if 'bcub' in line:
                        bfleg = 1
                if bfleg == 1 and 'Coreference' in line:
                        num = line.strip().split()[-1]
                        bfsc.append(float(num[:-1]))
                        num = line.strip().split()[5]
                        brsc.append(float(num[:-1]))
                        num = line.strip().split()[10]
                        bpsc.append(float(num[:-1]))
                        bfleg = 0
                if 'ceafe' in line:
                        cfleg = 1
                if cfleg == 1 and 'Coreference' in line:
                        num = line.strip().split()[-1]
                        cfsc.append(float(num[:-1]))
                        num = line.strip().split()[5]
                        crsc.append(float(num[:-1]))
                        num = line.strip().split()[10]
                        cpsc.append(float(num[:-1]))
                        cfleg = 0
        f.close()
print 'MUC P', sum(mpsc)/len(mpsc)
print 'MUC R', sum(mrsc)/len(mrsc)
print 'MUC F1',sum(mfsc)/len(mfsc)
print 'BCUB P', sum(bpsc)/len(bpsc)
print 'BCUB R',sum(brsc)/len(brsc)
print 'BCUB F1',sum(bfsc)/len(bfsc)
print 'CEAFE P',sum(cpsc)/len(cpsc)
print 'CEAFE R',sum(crsc)/len(crsc)
print 'CEAFE F1',sum(cfsc)/len(cfsc)
