if curl -I localhost:9200 2>/dev/null; then
    echo "elastic search already launched"
    lsof -i :9200 
    curl 'localhost:9200/_cat/indices?v'
    curl localhost:9200/wikipedia
    curl localhost:9200/beerqa_wiki_doc_para
    curl localhost:9200/beerqa_wiki_doc_para_link
    exit
fi
cd backend/elasticsearch-6.7.0
bin/elasticsearch 2>&1 >/dev/null &
while ! curl -I localhost:9200 2>/dev/null;
do
  bin/elasticsearch 2>&1 >/dev/null &
  sleep 2;
done
echo "elastic search launched"
lsof -i :9200 
curl 'localhost:9200/_cat/indices?v'
curl 'localhost:9200/_cluster/health/?level=shards'
curl localhost:9200/wikipedia
curl localhost:9200/beerqa_wiki_doc_para
curl localhost:9200/beerqa_wiki_doc_para_link