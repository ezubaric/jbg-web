import React, { useState } from 'react';


export const dataContext = React.createContext(
    {}
);