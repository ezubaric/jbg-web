import React from 'react';

import { makeStyles } from '@material-ui/core/styles';

// const useStyles = makeStyles((theme) => ({
//     root: {
//         flexGrow: 1,
//     },
//     paper: {
//         height: 200,
//         padding: theme.spacing(2),
//         textAlign: 'center',
//         color: theme.palette.text.secondary,
//     },
// }));
// const useStyles = makeStyles((theme) => ({
const drawerWidth = "25%";

const useStyles = ((theme) => ({
    
    root: {
        flexGrow: 1,
    },
    body: {
        flexGrow: 1,
        // margin: 20,
        padding: 20,
        // maxWidth: 1500, 
        // margin: "auto",
        // "border-style": "solid"
        transition: theme.transitions.create("margin", {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.leavingScreen
            }
        ),
        marginRight: 0
    },
    contentShift: {
        transition: theme.transitions.create("margin", {
          easing: theme.transitions.easing.easeOut,
          duration: theme.transitions.duration.enteringScreen
        }),
        marginRight: drawerWidth
    },
    margin: {
        margin: theme.spacing(1),
    },
    menuButton: {
        marginRight: theme.spacing(2),
      },
    title: {
        flexGrow: 1,
    },
    paper: {
        margin: 10,
        // padding: 20,
        // maxHeight: 300,
        // maxWidth: 300,
        paddingLeft: theme.spacing(2),
        paddingRight: theme.spacing(2),
        paddingTop: theme.spacing(0.1),
        paddingBottom: theme.spacing(0.1),
        textAlign: 'center',
        // color: theme.palette.text.secondary,
    },
    paperBig: {
        padding: 20,
        height: 300,
        // maxWidth: 600,
        padding: theme.spacing(2),
        textAlign: 'center',
        // color: theme.palette.text.secondary,
    },
    paperFlexVertical: {
        // padding: 20,
        maxHeight: 1000,
        // padding: theme.spacing(2),
        paddingLeft: theme.spacing(2),
        paddingRight: theme.spacing(2),
        paddingTop: theme.spacing(0.1),
        paddingBottom: theme.spacing(0.1),
        textAlign: 'center',
    },
    chips: {
        display: "flex",
        justifyContent: "center",
        flexWrap: "wrap",
        "& > *": {
          margin: theme.spacing(0.5)
        }
    },
    appBar: {
        transition: theme.transitions.create(["margin", "width"], {
          easing: theme.transitions.easing.sharp,
          duration: theme.transitions.duration.leavingScreen
        }),
        // marginRight: 0
    },
    appBarShift: {
        width: `calc(100% - ${drawerWidth})`,
        transition: theme.transitions.create(["margin", "width"], {
            easing: theme.transitions.easing.easeOut,
            duration: theme.transitions.duration.enteringScreen
        }),
        marginRight: drawerWidth
    },
    drawer: {
        width: drawerWidth,
        flexShrink: 0,
    },
    drawerPaper: {
        width: drawerWidth,
    },
    drawerContent: {
        // padding: 20,
        // maxHeight: 300,
        padding: theme.spacing(0),
        textAlign: 'center',
    },
    hide: {
        display: "none"
    },
    tooltip: {
        zIndex: '1500 !important'
    }
}));

export default useStyles;
