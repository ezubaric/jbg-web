import React from 'react';
import CircularProgress from '@material-ui/core/CircularProgress';

export default function Timer({seconds, totalMinutes}) {
  seconds = Math.max(seconds, 0);
  const minutes = Math.floor(seconds / 60);
  const paddedSeconds = (Math.floor(seconds) % 60).toString().padStart(2, '0');
  const ratio = (100 * seconds) / (totalMinutes * 60);
  let text = `${minutes}:${paddedSeconds}`;
  return (
    <div style={{marginTop: -30, marginBottom: -50}}>
      <CircularProgress
        variant="static"
        color={seconds <= 30 ? 'secondary' : 'primary'}
        value={ratio}
        thickness={6}
        style={{width: 80, height: 80}}
      />
      <div style={{bottom: 53, left: 22, position: 'relative'}}>
        {minutes}:{paddedSeconds}
      </div>
    </div>
  );
}
