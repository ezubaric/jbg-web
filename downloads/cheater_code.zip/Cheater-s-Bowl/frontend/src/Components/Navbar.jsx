import React, { useState, useEffect } from 'react';
import clsx from "clsx";
import Drawer from "@material-ui/core/Drawer";

import { makeStyles, useTheme, withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import ChevronLeftIcon from "@material-ui/icons/ChevronLeft";
import ChevronRightIcon from "@material-ui/icons/ChevronRight";
import Divider from "@material-ui/core/Divider";
import Paper from '@material-ui/core/Paper';
import List from '@material-ui/core/List';
import useStyles from '../Styles';


import { Redirect, Link } from 'react-router-dom';

import SimpleModal from './Modal';

const MAX_HEIGHT = 250;


  
function Navbar(props) {
    const { classes } = props;
    // const classes = useStyles();
    const theme = useTheme();
    const [open, setOpen] = React.useState(props.setDrawerOpen != undefined);

    const handleDrawerOpen = () => {
        props.setDrawerOpen(true);
        setOpen(true);
    };
  
    const handleDrawerClose = () => {
        props.setDrawerOpen(false);
        setOpen(false);
    };

    function calculateTimeLeft() {
        if (props.endDateTime) {
            let timeLeft = new Date(props.endDateTime) - new Date() // TODO: timezones
            // console.log('timeLeft', Math.trunc(timeLeft / 60000))
            return `Time Remaining: ${Math.trunc(timeLeft / 60000)} Minutes`
        } else {
            return ""
        }
    }
    const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());
  
    useEffect(() => {
      const timer = setTimeout(() => {
        setTimeLeft(calculateTimeLeft());
      }, 1000);
      return () => clearTimeout(timer);
    });

    let logout = (e) => {
        window.sessionStorage.clear("token");
        // return <Redirect to="/login" />;
    }

    var drawerButton;
    if (props.setDrawerOpen != undefined) {
        drawerButton = 
            <Button color="inherit"
                aria-label="open drawer"
                edge="end"
                onClick={handleDrawerOpen}
                className={clsx(open && classes.hide)}
            >
                 Total Score: {props.score} &nbsp;
                <ChevronLeftIcon />
            </Button>
    }
    
    return (

        <div className={classes.root} id="navbar">

            <AppBar
                position="static"
                className={clsx(classes.appBar, {
                        [classes.appBarShift]: open
                    }
                )
            }
            >
                <Toolbar>
                    {/* <IconButton edge="start" className={classes.menuButton} color="inherit" aria-label="menu">
                        <MenuIcon />
                    </IconButton> */}
                    <Typography variant="h6" className={classes.title}>
                        {/* {props.text} */}
                        Cheater's Bowl
                    </Typography>

                    {/* time left in minutes */}
                    {/* {new Date(props.endDateTime)} */}
                    {timeLeft}

                    {/* <SimpleModal /> */}
                    {props.tutorial}
                        
                    <Link to="/">
                        <Button variant="contained" color="primary" disableElevation>
                            Home
                        </Button>
                    </Link>
                    <Link to="/login">
                        <Button onClick={logout} variant="contained" color="primary" disableElevation>
                            Logout
                        </Button>
                    </Link>
                    {drawerButton}

                </Toolbar>
            </AppBar>
            <Drawer
                className={classes.drawer}
                variant="persistent"
                anchor="right"
                open={open}
                classes={{
                    paper: classes.drawerPaper
                }}
            >
                <div className={classes.drawerHeader}>
                <IconButton onClick={handleDrawerClose}>
                    {theme.direction === "rtl" ? (
                    <ChevronLeftIcon />
                    ) : (
                    <ChevronRightIcon />
                    )}
                </IconButton>
                </div>
                <div className={classes.drawerContent} id="toolbar">
                    {props.score ?
                        <div >                                        
                            <h2>
                            Total Score: {props.score} <br />
                            </h2>
                            {/* <h3>
                            Evidence score: {this.state.game_state['evidence_score']} <br />
                            Packet Number: {this.state.game_state['packet_number']} <br />
                            </h3> */}

                            {/* debugging */}
                            {/* Answer: {this.state.page} <br /> */}
                            {/* Question Number: {this.state.game_state['question_number']} <br /> */}
                            {/* Question ID: {this.state.game_state['question_id']} <br /> */}
                            {/* Category: {this.state.game_state['question_data']['category']} <br />
                            {question_data['tournament']} {question_data['year']} */}
                        </div>
                    : "Waiting"}

                        
                        <Paper className={classes.paper}>
                            <big><b>Evidence</b></big> 
                            <List component="nav" aria-label="search results" border={1}
                                style={{ 
                                    maxHeight: MAX_HEIGHT, 
                                    overflow: "scroll", 
                                    whiteSpace: "pre-wrap", 
                                    textAlign: "left", 
                                    }}>
                                {props.evidence_list}
                            </List>
                        </Paper>

                        <Paper className={classes.paper}>
                            <big><b>Previous queries</b></big> 
                            <List component="nav" aria-label="search results" border={1}
                                style={{ 
                                    maxHeight: MAX_HEIGHT, 
                                    overflow: "scroll", 
                                    whiteSpace: "pre-wrap", 
                                    textAlign: "left", 
                                    }}>
                                {props.queries}
                            </List>
                        </Paper>

                        <Paper className={classes.paper}>
                            <big><b>Previous documents</b></big> 
                            <List component="nav" aria-label="search results"
                                style={{ 
                                    maxHeight: MAX_HEIGHT, 
                                    overflow: "scroll", 
                                    whiteSpace: "pre-wrap", 
                                    textAlign: "left", 
                                    }}>
                                {props.prev_docs_selected}
                            </List>
                        </Paper>

                        <Paper className={classes.paper}>
                            <big><b>Keyboard shortcuts:</b></big> 
                            <div style={{ textAlign: "left"}}>
                                <ul>
                                {/* <li>Buzz: <code>space</code></li> */}
                                <li>Query (focus on search box or auto-search highlighted text): <code>Ctrl-s</code>.</li>
                                <li>Keyword search: <code>Ctrl-f</code></li>
                                <li>Record evidence: <code>Ctrl-e</code></li>     
                                <li>Answer from highlight: <code>Ctrl-space</code></li>                              
                                </ul>
                            
                            </div>
                        </Paper>

                </div>
            </Drawer>
        </div>
    )
}

export default withStyles(useStyles)(Navbar);