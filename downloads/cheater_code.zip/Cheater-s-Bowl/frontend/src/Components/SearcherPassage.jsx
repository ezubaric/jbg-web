import React from 'react';

import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Divider from '@material-ui/core/Divider';
import Button from '@material-ui/core/Button';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ClearAllRoundedIcon from '@material-ui/icons/ClearAllRounded';
import CategoryRoundedIcon from '@material-ui/icons/CategoryRounded';
import PieChartRoundedIcon from '@material-ui/icons/PieChartRounded';
import PolicyRoundedIcon from '@material-ui/icons/PolicyRounded';
import CircularProgress from '@material-ui/core/CircularProgress';
import TextField from '@material-ui/core/TextField';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';

import Chip from '@material-ui/core/Chip';
import DoneIcon from '@material-ui/icons/Done';
import DeleteIcon from '@material-ui/icons/Delete';

import Typography from '@material-ui/core/Typography';
import { withStyles } from '@material-ui/core/styles';
import useStyles from '../Styles';

// import HighLighter from './Highlighter';
import DocumentDisplay from './DocumentDisplay';
import HighlightRecorder from './HighlightRecorder';
import Box from '@material-ui/core/Box';
import QueryChip from './QueryChip';
import {getRequest, postRequest} from '../utils';
import ReactTooltip from "react-tooltip";

// search engine component. Displays search bar, titles, and document.
// controlled component: search logic is handled by parent, since we have other ways to search (tooltip, keyboard shortcut)

class Searcher extends React.Component {
    constructor(props) {
        super(props);
        // this.handleBuzz = this.handleBuzz.bind(this);

        // this.fetchWikiData = this.fetchWikiData.bind(this);
        this.handleInputChange = this.handleInputChange.bind(this);
        // this.processQuery = this.processQuery.bind(this);
        this.processShortcut = this.processShortcut.bind(this);
        this.addIntersectionEvent = this.addIntersectionEvent.bind(this);
        
        // this.handleHighlight = this.handleHighlight.bind(this);
        this.textInput = React.createRef();
        this.shortcutKeyCode = 68;
        this.documents_selected = [];
        this.state = {
            // pages: [],
            curPage: {
                text: null,
                passage_id: "",
                passage_id_list: []
            },
            exact_passage_text: "",
            curQuery: "",
            titles: [],
            
            selectedDoc: '', // HTML of doc
            isLoading: false,
            pageLimit: 8,
            titleHeight: 0,
        };
        // this.exact_passage_text = ""
    }

    componentDidMount() {
        // shortcut to search from highlight
        HighlightRecorder(83, this.processShortcut);
    }

    componentDidUpdate(prevProps) {
        // reset state if question changed
        if (prevProps.currentQuery !== this.props.currentQuery){
            // console.log('query changed');
            this.setState({
                curQuery: this.props.currentQuery
            });
        }

        // question id changed, clear screen
        if (prevProps.currentQuestionId !== this.props.currentQuestionId) {
            this.setState({curPage: {}, curQuery: "", titles: []})
        }
        if (this.props.sentenceIndex == 0 && this.state.exact_passage_text != ""){
            this.setState({exact_passage_text: ""})
        }
    }
    
    handleInputChange(event) {
        this.setState({ curQuery: event.target.value });
    }

    processShortcut(query) {
        if (!query){
            this.textInput.current.focus();
        } else {
            this.props.processQuery(query);
        }
    }

    // get document, deprecated
    async getPassageById(id) {
        console.log("doc id: ", id);

        const result = await getRequest(`/get_document_by_id/${id}`);
        this.setState({
            curPage: result,
        });
    }

    async getFullDocument(page_title, passage_id = null) {
        const { classes } = this.props;
        console.log("passage_id", this.state.curPage.passage_id);
        if (this.state.curPage.passage_id == null || this.state.curPage.passage_id == undefined){
            this.setState({
                curPage: {text: <div key="CircularProgress" style={{textAlign: "center"}}><CircularProgress/></div>, passage_id: null, passage_id_list: []},
                exact_passage_text: "",
            });
        }
        let result = await getRequest(`/get_document_passages/${page_title}`);
        if (result.length == 0){
            result.push({text: "We're sorry, but we couldn't find this page.\nThis could be because the title you requested is an alias for a Wikipedia page title.\n", id: -1});
        }
        let text = new Array();
        let passage_id_list = new Array();
        var exact_passage_text = "";
        for (const passage of result) {
            let passage_text = new Array();
            const non_button_text = passage.text.split(/<a href=".*?">.*?<\/a>/);
            const button_text = [...passage.text.matchAll(/<a href="(.*?)">(.*?)<\/a>/g)];
            for (let i = 0; i < button_text.length; i++) {
                passage_text.push(non_button_text[i]);
                passage_text.push(
                    // <button 
                    //     style={{
                    //         color: "blue",
                    //         border: "none",
                    //         backgroundColor: "transparent",
                    //         cursor: "pointer",
                    //         textDecoration: "underline"
                    //     }} 
                    //     onClick={() => { this.props.processQuery(button_text[i][2]); this.getFullDocument(button_text[i][1]) }}
                    // >
                    <a
                        data-tip={`Search for "${button_text[i][2]}" and jump to the page "${button_text[i][1]}" (if available in our database)`}
                        data-class={classes.tooltip}
                        onClick={() => { this.props.processQuery(button_text[i][2]); this.getNewDocument(button_text[i][1], null, "hyperlink") }}
                        style={{
                            textDecoration: "none",
                            cursor: "pointer",
                            color: "blue",
                            textDecoration: "underline",
                        }}
                    >
                        {button_text[i][2]}
                    </a>
                    );
                    {/* </button>); */}
            }
            passage_text.push(non_button_text[button_text.length]);
            text.push(<div id={passage.id}>{passage_text}<ReactTooltip effect="solid" place="bottom" delayShow={1000} style={{zIndex: 1500}}/></div>);
            passage_id_list.push(passage.id)
            if (passage_id == passage.id) {
                exact_passage_text = passage.text.replace(/<a href="(.*?)">(.*?)<\/a>/g, "$2");
            }
        }
        // console.log("full document: ", text);
        if (passage_id === null) {
            passage_id = passage_id_list[0];
        }
        console.log("text",text, "exact_passage_text", exact_passage_text);
        this.setState({
            curPage: {text: text, passage_id: passage_id, passage_id_list: passage_id_list},
            exact_passage_text: exact_passage_text,
        });
    }
    
    async getNewDocument(page_title, passage_id = null, origin = "search_results"){
        this.props.updateCurrentDocument(page_title); 
        // this.getPassageById(passage_id);
        this.getFullDocument(page_title, passage_id);
        if (passage_id === null) {
            passage_id = this.state.curPage.passage_id;
        }
        this.props.selectDocumentEvent(page_title);
        postRequest(`/record_action?name=select_document`, {data: {passage_id: passage_id, page_title: page_title, origin: origin}});
    }

    scrollToSection(section_title) {
        let section_element = document.getElementById(section_title);
        section_element.parentNode.scrollTop = section_element.offsetTop - section_element.parentNode.offsetTop;
    }

    addIntersectionEvent(intersectionEvent) {
        this.props.addIntersectionEvent(intersectionEvent)
    }

    
    render() {
        const { classes } = this.props;
        // suggested queries
        let suggestedQueries;
        if (this.props.showSuggestedQueries){
            // console.log("suggestedQueries", this.props.suggestedQueries);
            var queryChips;
            if (this.props.suggestedQueries.length > 0){
                queryChips = this.props.suggestedQueries.map((customQuery)=> 
                    <QueryChip
                        query={customQuery}
                        tryQuery={()=>{this.props.trySuggestedQuery(customQuery)}}
                        dislikeQuery={()=>{this.props.dislikeSuggestedQuery(customQuery)}}
                    />
                );
            } else {
                queryChips = "The AI model is generating queries ..."
            }
            suggestedQueries = 
            <Grid item xs={12} id="suggestedQueries">
                <h4 style={{ "textAlign": "left", "padding": 0, marginTop: 0, marginBottom: 10 }}>Suggested Queries</h4>
                {/* <br/> */}
                <div className={classes.chips}>
                    {queryChips}
                </div>
            </Grid>
        }
        // articles, sections
        let document_titles;
        if (typeof this.props.passages === "undefined" || this.props.passages.length === 0) {
            document_titles = <ListItem>
                <ListItemText primary={'No Results'} />
            </ListItem>
        } else {
            document_titles = this.props.passages.map((psg) =>{
                if (psg['engine']=="DPR"){
                    var icon = <PolicyRoundedIcon fontSize="small" data-tip="Retrieved using Dense Passage Retrieval"/>;
                } else if (psg['engine']=="ES"){
                    var icon = <PieChartRoundedIcon fontSize="small" data-tip="Retrieved using Elastic Search"/>;
                }

                return <ListItem button onClick={(e) => {
                    this.getNewDocument(psg['page'], psg['id']);
                }} key={psg['id'].toString()}>
                    <ListItemText primary={psg['page']} />
                    {icon}
                    <ReactTooltip effect="solid" place="right" delayShow={1000}/>
                </ListItem>
            }
        );
        } 


        // loading icon
        let loadingIcon;
        if (this.props.searchLoading) {
            loadingIcon = <CircularProgress style={{margin: 20}}/>;
        } else {
            loadingIcon = <h4>Search Results (Page Titles)</h4>
        }

        // Directly record as evidence
        // if (this.exact_passage_text !== "") {
        //     console.log("select any text to cancel");
        //     console.log(window.getSelection, typeof window.getSelection)
        //     console.log(document.selection, typeof document.selection != "undefined");
        //     this.exact_passage_text = "";
        //     if (typeof document.selection != "undefined"){ // select any text to cancel, might have bug
        //         // typeof window.getSelection != "undefined" || (typeof document.selection != "undefined" && document.selection.type == "Text")
        //     }
        // }
        let record_evidence_tool;
        if (!this.props.highlightToolOn && this.state.exact_passage_text !== "") {
            let record_evidence_button = <Button variant="contained" color="primary" style={{margin: 10}} onClick={() => {this.props.callback('record evidence', this.state.exact_passage_text, "contentpassageSearch", [this.state.curPage.passage_id, this.state.curPage.passage_id], this.state.exact_passage_text)}}>
                Record as evidence
            </Button>
            let cancel_button = <Button variant="contained" color="default" style={{margin: 10}} onClick={()=>{this.setState({exact_passage_text: ""});}}>
                Cancel
            </Button>
            record_evidence_tool = <Box border={1} style={{
                    'position':'absolute', 'zIndex': '1300',
                    'top': document.getElementById("DocumentDisplay").clientHeight + 100, // this.state.titleHeight, //window.innerHeight * 1.2, 
                    'left': window.innerWidth * 3 / 4, 
                    'backgroundColor': 'white', 
                    'display': 'flex',
                    'flexDirection': 'column',
                    'maxWidth':'15rem',
                    'padding': '0.5rem'}}
                >
                The search engine has found this paragraph in green most related to your search query.
                {record_evidence_button}
                {cancel_button}
            </Box>;
        } else {
            record_evidence_tool = null
        }
        return (
            <Paper className={classes.paperFlexVertical} >
                <br/>
                <h3 style={{textAlign:"left", display:"inline"}}>Wikipedia Passage Search     </h3>&emsp;  <FormControlLabel
                    control={
                    <Checkbox
                        checked={this.props.use_ES}
                        onChange={this.props.handle_use_ES}
                        name="use_ES"
                        color="primary"
                    />
                    }
                    label="Use Elastic Search"
                /> <FormControlLabel
                control={
                <Checkbox
                    checked={this.props.use_DPR}
                    onChange={this.props.handle_use_DPR}
                    name="use_DPR"
                    color="primary"
                />
                }
                label="Use DPR"
            />

                <Grid container spacing={3}
                    bgcolor="background.paper"
                >
                    {/* suggested queries */}
                    {suggestedQueries}
                    {/* document search */}
                    <Grid item xs={3}>
                            <form onSubmit={(event) => {event.preventDefault(); this.props.processQuery(this.state.curQuery)}} // lifting state up
                                className={classes.root} 
                                noValidate 
                                autoComplete="off" 
                                style={{"display": "flex", "alignItems": "center", "marginBottom": 10}}
                            >
                                <TextField
                                    inputRef={this.textInput}
                                    value={this.state.curQuery} 
                                    onChange={this.handleInputChange} 
                                    label="Search Passages (Ctrl-S)" 
                                    variant="outlined" 
                                    fullWidth
                                    // margin="normal"
                                    // defaultValue={this.props.curQuery}
                                />
                            </form>
                            
                            {/* article, section display */}
                            <Box border={1}>
                                {loadingIcon}
                                {/* document titles */}
                                <List component="nav" aria-label="search results"
                                    style={{ 
                                        maxHeight: 500, 
                                        overflow: "scroll", 
                                        whiteSpace: "pre-wrap", 
                                        textAlign: "left", 
                                        }}>
                                    {document_titles}
                                    
                                </List>
                            </Box>
                            
                    </Grid>
                    
                    {/* <Divider orientation="vertical" flexItem /> */}

                    {/* text display, keyword search */}
                    <Grid item xs={9} >
                        <h3 style={{marginTop: 0, paddingTop: 0}}>{this.props.curDocumentInfo.title}</h3> {/* title */}
                        <div  id = "DocumentDisplay"> 
                        <DocumentDisplay 
                            text={this.state.curPage.text} 
                            searchTerms={this.state.curQuery} 
                            recordKeywordSearchTerms={(keywords) => this.props.recordKeywordSearchTerms(keywords, 'passage')}
                            separateWordSearch={true}
                            cleanText={true}
                            searchType={"passageSearch"}
                            recordHighlight={(startIndex, endIndex) => this.props.recordHighlight(startIndex, endIndex, 'passage')}

                            passage_id={this.state.curPage.passage_id}
                            passage_id_list={this.state.curPage.passage_id_list}
                            addIntersectionEvent={this.addIntersectionEvent}
                            // currentQuestionId={this.props.currentQuestionId}
                        />
                        </div>
                    {/* direct record evidence tool */}
                    {record_evidence_tool}
                        {/* <Highlight_tools /> */}

                            {/* <Button variant="contained" 
                                color="primary" 
                                onClick={() => { this.getPassageById(this.state.curPage['id']-1) }}
                                style={{ 
                                    margin: 10, 
                                    }}>
                                {'<<< Previous Passage'}
                            </Button>
                            <Button variant="contained" 
                                color="primary" 
                                onClick={() => { this.getPassageById(this.state.curPage['id']+1) }}
                                style={{ 
                                    margin: 10, 
                                    }}>
                                {'Next Passage >>>'}
                            </Button> */}
                    </Grid>

                </Grid>
            </Paper>
        );
    }
}

export default withStyles(useStyles)(Searcher);
