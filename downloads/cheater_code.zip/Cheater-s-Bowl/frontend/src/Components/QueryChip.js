import React from 'react';
import Chip from '@material-ui/core/Chip';
import ThumbUpIcon from '@material-ui/icons/ThumbUp';
import ThumbDownIcon from '@material-ui/icons/ThumbDown';
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import FavoriteIcon from '@material-ui/icons/Favorite';
import FavoriteBorderIcon from '@material-ui/icons/FavoriteBorder';
import HighlightOffIcon from '@material-ui/icons/HighlightOff';
class QueryChip extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            liked: false
        };
        this.handleClick = this.handleClick.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
    }
    componentDidMount(){
        this.setState({liked: false});
    }
    handleClick(){
        this.props.tryQuery(this.props.query);
        this.setState({liked: true});
    }
    handleDelete(){
        this.props.dislikeQuery(this.props.query);
        this.setState({liked: false});
    }
    render(){
        if (this.state.liked){
            return <Chip
                icon={<FavoriteIcon />}
                label={this.props.query}
                onClick={this.handleDelete}
                // onClick={this.handleClick}
                // onDelete={this.handleDelete}
                // deleteIcon={<HighlightOffIcon />}
            />
        } else {
            return <Chip
                icon={<FavoriteBorderIcon />}
                label={this.props.query}
                onClick={this.handleClick}
            />
        }

    }
}
export default QueryChip;