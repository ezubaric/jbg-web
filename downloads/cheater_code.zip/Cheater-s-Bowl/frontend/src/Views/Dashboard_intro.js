import React, { useState, Fragment } from 'react';
import { Redirect } from "react-router-dom";

import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import Typography from "@material-ui/core/Typography";

import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';

import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
// import Alert from '@material-ui/lab/Alert';
import clsx from "clsx";

import Navbar from '../Components/Navbar'
import Timer from '../Components/Timer';
import AnswerForm from '../Components/AnswerForm';
import Buzzer from '../Components/BuzzerUntimed';
// import QuestionDisplay from './Components/QuestionDisplay';
import QuestionDisplay from '../Components/QuestionDisplaySentence';

import SearcherPassage from '../Components/SearcherPassage';

import {postRequest, getRequest, getScheduleInfo, debug} from '../utils';

import '../App.css';
import HighlightTool from '../Components/HighlightTool';
import HighlightAnswerTool from '../Components/HighlightRecorder';

import { createMuiTheme, withStyles, makeStyles, ThemeProvider } from '@material-ui/core/styles';
import useStyles from '../Styles';
import { positions } from '@material-ui/system';
import { green, purple } from '@material-ui/core/colors';

import { Steps, Hints } from 'intro.js-react';
import introJs from 'intro.js';
import 'intro.js/introjs.css';
import { withSnackbar } from 'notistack';
import config from "../config.json";
const fs = require('fs');

// main Dashboard. Load question, handle interrupt, load next question
// preloaded questions for experiment setting

const MAX_HEIGHT = 250;
const SEARCH_TYPE = 'passage'
const SHOW_SUGGESTED_QUERIES = true;

class Dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.config = config;
        console.log(config);

        this.handleShortcut = this.handleShortcut.bind(this);
        this.handleBuzz = this.handleBuzz.bind(this);
        this.getSuggestedQuery = this.getSuggestedQuery.bind(this);

        this.processQuery = this.processQuery.bind(this);
        this.updateGameState = this.updateGameState.bind(this);

        // this.postRequest = this.postRequest.bind(this);
        this.answerQuestion = this.answerQuestion.bind(this);
        this.advanceQuestion = this.advanceQuestion.bind(this);
        this.recordKeywordSearchTerms = this.recordKeywordSearchTerms.bind(this);
        this.updateCurrentDocument = this.updateCurrentDocument.bind(this);
        this.recordHighlight = this.recordHighlight.bind(this);        
        this.recordEvidence = this.recordEvidence.bind(this);
        this.highlightToolCallback = this.highlightToolCallback.bind(this);
        this.handleShortcut = this.handleShortcut.bind(this);
        this.deactivateShortcut = this.deactivateShortcut.bind(this);
        this.onExit = this.onExit.bind(this);
        this.addIntersectionEvent = this.addIntersectionEvent.bind(this);
        this.startTutorial = this.startTutorial.bind(this);
        this.handle_use_ES = this.handle_use_ES.bind(this);
        this.handle_use_DPR = this.handle_use_DPR.bind(this);
        

        // this.intersectionEvents = [];
        this.maxAttempts = 1;
        // this.keywords = {};
        // this.passage_keywords_map = {};
        this.curDocumentInfo = {'title': null, 'keyword_matches': [], 'intersectionEvents': []};
        this.totalMinutes = 4;
        

        this.state = {

            game_state: {}, // game state used by server
            
            isValidPlayingTime: true,
            gameOver: false,

            currentQuery: '',
            searchLoading: false,
            retrievedTitles: [],
            queries: [],
            evidence: [],
            input_reasoning_path: {},
            suggested_query: {},
            suggested_answer: {},

            answerStatus: null,
            interrupted: false,
            numSeen: 0,
            score: 0,
            isLoaded: false,
            sentenceIndex: 0,
            numAttempts: 1, // number of attempts on current question

            keywords: [],
            shortcutToggled: false,
            wordIndex: 0,

            use_DPR: config["search_engine"].hasOwnProperty("DPR"),
            use_ES: config["search_engine"].hasOwnProperty("ES"),

            secondsLeft: 60 * this.totalMinutes,
            timeOut: false,
            stepsEnabled: false,
            initialStep: 0,
            highlightToolOn: false,
            openDrawer: true,
            steps: [
            {
                intro: `<h1>Welcome to Cheater's Bowl!</h1> This tutorial will walk you through how to play the game.
            The basic goal of this game is to answer trivia questions, with a twist. <b>Click "Next" to Continue.</b>`,
                tooltipClass: 'customTooltip'

            },
              {
                element: "#questionText",
                intro: `This is the question. You can click 'Another Clue' to reveal another sentence.  
                It is better to answer early: -10 points and -30 seconds for each clue revealed.`
              },
              {
                element: "#answerBox",
                intro: "Answer here. You get 100 points for a correct answer! You're given a chance to protest, if you think we judged your answer wrong."
              },
              {
                element: "#searcher",
                intro: `You can search and read Wikipedia pages here. Once you open a document, you can also search for keywords. Some questions can be pretty tricky. You might need to search several times before finding the answer.
                <b>You cannot use any external tools to play this game.</b>`
              },
              {
                element: "#searcher",
                intro: `One important task is recording evidence. We define evidence as "text which helped lead you to the answer."
                To do this, highlight some text in a document to bring up the tooltip, then click "Record as Evidence". You earn 5 points for each piece of evidence you record!`
              },
              {
                element: "#suggestedQueries",
                intro: `We apply AI models to suggest possible queries and answers. The model generates new queries and answers when a new clue is revealed or a new evidence is recorded.`
                
              },
              {
                element: "#suggestedQueries",
                intro: `You may click on a suggested query to show your like ♥, and see the documents retrieved using that query. To dislike ♡, just click on the query again.`
              },
              {
                element: "#toolbar",
                intro: "The toolbar displays your score, queries, evidence, and other info. You can close the toolbar by clicking on the button in the upper left corner." // , current packet
              },
            {
                element: "#navbar",
                intro: `Answer the questions as best as you can before time runs out. You can access this tutorial any time from the navbar. Good luck and have fun!` // There are four packets, and each packet has 24 questions. 
            },

            ],
        }
        
        this.suggestedAnswers = new Set();
    }

    // on init: authenticate, grab the user data, fetch first question
    async componentDidMount() {
        console.log("123")
        
        // if it's not a valid playing time
        // const scheduleInfo = await getScheduleInfo()
        // if (!scheduleInfo['is_valid_playing_time']) {
        //     console.log('not valid playing time')
        //     this.setState({isValidPlayingTime: false})
        //     return
        // } else {
        //     console.log('endDateTime', new Date(this.state.endDateTime))
        //     this.setState({endDateTime: scheduleInfo['next_end_datetime']})
        // }

        let username = window.sessionStorage.getItem("username");
        let token = window.sessionStorage.getItem("token");

        // postRequest('get_player_info', {'username': username, 'session_token': token, 'mode': 'sentence'}).then(data => {
        //     console.log('player info, ', data);
        //     // this.updateGameState(data);
        // });
        // start game
        postRequest('start_new_game', {'username': username, 'session_token': token, 'mode': 'sentence'}).then(data => {
            this.updateGameState(data);
            debug("game_state", this.state.game_state);

            this.setTimer()

            // if this is a new game, show intro for the first time
            if (data.question_number === 1) {
                console.log('new game started, ', data);
                this.setState({stepsEnabled: true})
                clearInterval(this.timer);
                // introJs().start();
            }
            this.suggestedAnswers = new Set();
            this.setState({answerStatus: null});
            this.getSuggestedQuery()

        });

        // buzzer shortcut
        window.addEventListener("keydown", this.handleShortcut);
        window.addEventListener("keyup", this.deactivateShortcut);

        // answer shortcut
        HighlightAnswerTool(81, this.answerQuestion);
    }

    // keyboard shortcut to buzz
    handleShortcut(e) {
        // console.log(e.keyCode, this.state.answerStatus)
        if (this.state.answerStatus !== null) {
            this.advanceQuestion();
        } else if (e.keyCode === 32 && this.state.shortcutToggled === false && document.activeElement.tagName == 'BODY') {
          this.setState({shortcutToggled: true});
          
          e.preventDefault();
          this.handleBuzz();
          console.log('buzzed, ', this.shortcutToggled);
        }
    }

    deactivateShortcut(e) {
        this.setState({shortcutToggled: false});
    }

    // record buzz location
    handleBuzz() {
        postRequest(`/buzz?word_index=${this.state.wordIndex}`);
        this.setState({
            interrupted: !this.state.interrupted
        });
    }

    setDrawerOpen(drawerOpen) {
        this.setState({openDrawer: drawerOpen});
    }
    async getSuggestedQuery() { 
        for (const suggestion_model of Object.keys(this.config["suggestion_models"])){
            console.log("suggestion_model", suggestion_model);
            for (const task of this.config["suggestion_models"][suggestion_model]["tasks"]){
                console.log(`/get_suggested_query?suggestion_model=${suggestion_model}&task=${task}`);
                getRequest(`/get_suggested_query?suggestion_model=${suggestion_model}&task=${task}`).then(data => {
                    console.log(`Got suggested ${task} from ${suggestion_model}`, "suggested queries", data['suggested_query'], "suggested answers", data['suggested_answer']);
                    this.updateGameState(data);
                    console.log("game_state", this.state.game_state);
                    if ((this.state.game_state['game_over'] === false) & task.includes("answer")) { //this.state.game_state['suggested_answer'] & 
                        for (const [answer, input_id_like] of Object.entries(data['suggested_answer'])){
                            if ((!this.suggestedAnswers.has(answer)) & (!this.state.answerStatus)){
                                this.suggestedAnswers.add(answer);
                                const action = key => (
                                    <Fragment>
                                        <Button onClick={() => {
                                            postRequest(`/like_suggested_answer?answer=${answer}&like=true`).then(data => {
                                                this.answerQuestion(answer, "suggested"); 
                                            })
                                            this.props.closeSnackbar(key);
                                        }}>
                                            ANSWER
                                        </Button>
                                        <Button onClick={() => { this.props.closeSnackbar(key) }}>
                                            CANCEL
                                        </Button>
                                    </Fragment>
                                );
                                this.props.enqueueSnackbar("Suggested answer: " + answer, {
                                    variant: 'info',
                                    anchorOrigin: {
                                        vertical: 'bottom',
                                        horizontal: 'center',
                                    },
                                    autoHideDuration: 10000,
                                    action
                                });
                            }
                        }
                    }
                });  
            }
        }
    }

    handle_use_ES(event) {
        this.setState({use_ES: event.target.checked});
    }
    handle_use_DPR(event){
        this.setState({use_DPR: event.target.checked});
    }
    // fetch data and log query
    async processQuery(query, origin='none', selectedPassageId=[], context) {
        console.log(`query: ${query}, origin: ${origin}`);
        if (!query){
            return
        }

        // record down searched queries for "Previous queries" in the right column
        let new_game_state = this.state.game_state;
        if (!new_game_state['queries']){
            new_game_state['queries'] = [];
        }
        new_game_state['queries'].push(query);
        if (origin == "suggested"){
            postRequest(`/like_suggested_query?query=${query}&like=true`);
        }

        this.setState({
            searchLoading: true,
            currentQuery: query,
            game_state: new_game_state,
        })

        postRequest(`/record_action?name=search_documents`, {data: {query: query, origin: origin, passage_id: selectedPassageId, context: context}})

        if (SEARCH_TYPE === 'page') {
            getRequest(`/search_wiki_titles?query=${query}`)
            .then(
                (result) => {
                    // console.log('search results: ', result);
                    this.updateGameState(result);
                    let titles = result['query_results_map'][query]
                    console.log('titles: ', titles);
                    this.setState({
                        retrievedTitles: titles,
                        searchLoading: false,
                    });
                },
                (error) => {
                    console.log('Error', error)
                }
            )
        } else if (SEARCH_TYPE === 'passage') { // this one, SEARCH_TYPE = 'passage'
            this.setState({
                passages: [],
                searchLoading: true,
            });
            var passages = [];
            var title_docid_map = {};
            if (this.state.use_ES){
                getRequest(`/search_tfidf?query=${query}&limit=${60}&search_engine=ES&direct_return=true`).then(
                // getRequest(`${config["search_engine"]["ES"]}/search_passages?query=${query}`).then(
                    (result) => {
                        console.log(`search results of ES: `, result);
                        // passages.push(...result);
                        for (const r of result){
                            if (!title_docid_map.hasOwnProperty(r['title'])){
                                passages.push({'id':r['id'], 'page':r['title'], "engine": "ES"});
                                var docid = r['id'].split("-").splice(2).join("-");
                                title_docid_map[r['title']] = docid;
                            }
                        }
                        this.setState({
                            // retrievedTitles: result.map(e => e['page']),
                            passages: passages,
                            searchLoading: false,
                        });
                        postRequest(`/record_search_results?query=${query}`, {passages: passages, title_docid_map: title_docid_map});
                    }
                )
            }
            if (this.state.use_DPR){
                console.log(`fetch('${config["search_engine"]["DPR"]}/search_passages?query=${query}')`);
                fetch(`${config["search_engine"]["DPR"]}/search_passages?query=${query}`, {
                    headers: {
                      'Accept': 'application/json'
                    }
                  }).then((response) => response.json()).then((result) => 
                    {
                        // result = result.json();
                        console.log(`search results of DPR: `, result);
                        // passages.push(...result);
                        for (const r of result){
                            if (!title_docid_map.hasOwnProperty(r['page'])){
                                r["page"] = Buffer.from(r["page"], 'latin1').toString('utf8');
                                r["engine"] = "DPR";
                                var docid = r['id'].split("-").splice(2).join("-");
                                passages.push(r);
                                title_docid_map[r['page']] = docid;
                            }
                        }
                        this.setState({
                            // retrievedTitles: result.map(e => e['page']),
                            passages: passages,
                            searchLoading: false,
                        });
                        postRequest(`/record_search_results?query=${query}`, {passages: passages, title_docid_map: title_docid_map});
                    }
                ).catch(err => {console.error(err);});
            }
            // for (const search_engine of config["search_engine"]){
            //     getRequest(`/search_tfidf?query=${query}&search_engine=${search_engine}`).then(
            //         (result) => {
            //             console.log(`search results of ${search_engine}: `, result);
            //             passages.push(...result);
            //             this.setState({
            //                 passages: passages,
            //                 searchLoading: false,
            //             });
            //         }
            //     )
            // }
        }
    
    }

    async dislikeSuggestedQuery(query){
        postRequest(`/like_suggested_query?query=${query}&like=false`);
    }
    async answerQuestion(answer, origin='none', selectedPassageId=[], context) {

        // const isValid = await getScheduleInfo() # NOTE: all the time is valid now
        // if (!isValid['is_valid_playing_time']) {
        //     console.log('not valid playing time')
        //     this.setState({isValidPlayingTime: false})
        //     return
        // }

        // confirm
        if (this.state.game_state.evidence.length === 0) {
            if (!window.confirm("Are you sure you want to answer without recording evidence? By recording evidence, you can earn higher scores!")) {
                return
            }
        }
        document.activeElement.blur(); 
        this.setState({answerStatus: "judging"});
        // clearInterval(this.timer);
        postRequest(`/record_action?name=answer`, {data: {answer: answer, origin: origin, passage_id: selectedPassageId, context: context, time: Date.now()}})

        // console.log(`expanded answer: ${expanded_answer}`)
        postRequest(`/answer?answer=${answer}&sentence_index=${this.state.sentenceIndex}&timeOut=${this.state.timeOut}&time=${this.totalMinutes*60-this.state.secondsLeft}`).then(data => {
            this.updateGameState(data);
            clearInterval(this.timer);
            let game_state = data;
            console.log("timer is cleared");
            // parse answer for correctness
            if (game_state['answer_correct']){
                this.setState({answerStatus: "correct"});
            } else {
                this.setState({answerStatus: "incorrect"});
            }
            
        });
    }

    // advance to next question
    async advanceQuestion(player_decision=null, skip=false){
        this.props.closeSnackbar();
        clearInterval(this.timer);
        // NOTE: change to playing time to always valid
        // const isValid = await getScheduleInfo();
        // if (!isValid['is_valid_playing_time']) {
        //     console.log('not valid playing time')
        //     this.setState({isValidPlayingTime: false})
        //     return
        // }

        // record keyword search data and intersection events
        console.log('keywords: ', this.keywords);
        // postRequest(`/record_keyword_search`, {
        //     'keywords': this.keywords, 
        //     'passage_keywords_map': this.passage_keywords_map});
        postRequest(`/record_action?name=document_actions`, {data: {documentActions: this.curDocumentInfo}});
        // reset data structures
        this.curDocumentInfo = {'title': null, 'keyword_matches': [], 'intersectionEvents': []};
        // this.keywords = {};
        // this.passage_keywords_map = {};

        postRequest(`/advance_question?player_decision=${player_decision}&skip=${skip}`).then(data => {
            // reset state
            this.setState({game_state: data, interrupted: false, wordIndex: 0, sentenceIndex: 0, answerStatus: null, passages: []});

            let game_state = this.state.game_state;
            console.log('game state', game_state)
            //load the next question
            if (game_state['game_over']) {
                alert('Game Finished. Thank you for your participation. Have a good day!');
                this.setState({gameOver: true})
            } else if (game_state['packet_finished']) {
                alert('Packet Finished! Returning to Home...');
                this.setState({gameOver: true})
            } else {
                console.log("New question");
            }
            this.suggestedAnswers = new Set();

            if (this.state.game_state["dataset"] === 'qanta') {
                this.totalMinutes = 4;
            } else if (this.state.game_state["dataset"] === 'hotpotqa') {
                this.totalMinutes = 3;
            }

            this.setState({
                secondsLeft: 60 * this.totalMinutes,
                timeOut: false
            })
            
            this.setTimer()

            console.log("Try get suggested query");
            this.getSuggestedQuery()

        }); 
        
    }
    setTimer(){
        this.timer = setInterval(() => {
            var timeOut;
            if (this.state.secondsLeft >= 0){
                timeOut = false;
            } else {
                timeOut = true; // TODO
                if (!this.state.timeOut){
                    alert("Sorry, time's up. You may continue to answer, but you will receive a reduced score for correct answer.");
                }
            }
            this.setState({secondsLeft: this.state.secondsLeft - 1, timeOut: timeOut})
            
            // this.forceUpdate();
        }, 1000);
    }

    // update keywords dict
    recordKeywordSearchTerms(searchVal, search_type){
        // this.setState({keywords: this.state.keywords + [searchVal]}) # bug: this clears the search box
        
        let cleaned_searchVal = searchVal.trim();
        // let doc_title = this.state.game_state['cur_doc_selected']['title'];
        let curDoc = this.curDocumentInfo;
        // let doc_title = curDoc['title'];
        console.log('doc: ', curDoc)

        // let keywords = curDoc.keyword_matches
        // if (search_type === 'full') {keywords = curDoc.keywords}
        // else if (search_type === 'passage') {keywords = curDoc.passage_keywords_map}

        // if (!keywords.hasOwnProperty(doc_title)){
        //     keywords[doc_title] = [];
        // }

        // let doc_searchVals = keywords[doc_title];
        let doc_searchVals = curDoc.keyword_matches
        // check if we're adding a duplicate
        if (cleaned_searchVal !== doc_searchVals[doc_searchVals.length - 1]) {
            doc_searchVals.push(cleaned_searchVal);
            // console.log('keywords: ', keywords);
        }
    }

    recordHighlight(startIndex, endIndex) {
        this.state.game_state['highlight']['startIndex'] = startIndex;
        this.state.game_state['highlight']['endIndex'] = endIndex;
    }

    updateCurrentDocument(title){

        if (this.curDocumentInfo.title) {
            postRequest(`/record_action?name=document_actions`, {data: {documentActions: this.curDocumentInfo}}); // record actions of prev doc
            // postRequestupdateCurrentDocument(`/record_action?name=document_actions`, {data: {documentActions: this.curDocumentInfo}}); // record actions of prev doc
        }
        // reset cur doc
        this.curDocumentInfo = {'title': title, 'keyword_matches': [], 'intersectionEvents': []};
        this.setState({highlightToolOn: false});
    }

    updateGameState(gameState) {
        this.setState({game_state: gameState});
        return true;
    }

    async recordEvidence(splited_evidence, startPassageId, endPassageId) {
        // this.state.game_state['evidence'].push(text); 
        // let cur_doc_selected = this.state.game_state['cur_doc_selected']
        // this.state.game_state['evidence'][cur_doc_selected] = text;
        let game_state = await postRequest(`/record_evidence?start_passage_id=${startPassageId}&end_passage_id=${endPassageId}`, {data: splited_evidence});
        this.updateGameState(game_state);
        this.forceUpdate()
        this.getSuggestedQuery()


    }

    highlightToolCallback(action, text, selectedElement, selectedPassageId, context) {
        console.log('highlightToolCallback', "action", action, "text", text, "selectedElement", selectedElement, "selectedPassageId", selectedPassageId, "context", context);
        this.setState({highlightToolOn: true});
        if (action === 'record evidence') {
            var [startPassageId, endPassageId] = selectedPassageId;
            var splited_evidence = text.split("\n");
            this.recordEvidence(splited_evidence, startPassageId, endPassageId);
        } else if (action === 'search documents') {
            this.processQuery(text, selectedElement, selectedPassageId, context);
        } else if (action === 'answer') {
            this.answerQuestion(text, selectedElement, selectedPassageId, context);
        }
    }

    startTutorial() {
        this.setState({ stepsEnabled: true });
        clearInterval(this.timer);
    }
    onExit() {
        this.setState(() => ({ stepsEnabled: false }));
        this.setTimer();
        
    }

    addIntersectionEvent(intersectionEvent) {
        this.curDocumentInfo.intersectionEvents.push(intersectionEvent);
    }

    selectDocumentEvent(page_title){
        var game_state = this.state.game_state
        if (!game_state['tfidf_search_map']['documents_selected']){
            ['tfidf_search_map']['documents_selected'] = [];
        }
        game_state['tfidf_search_map']['documents_selected'].push(page_title);
        this.updateGameState(game_state)
    }

    render() {

        const { classes } = this.props;
        let game_state = this.state.game_state;

        // const greenTheme = createMuiTheme({ palette: { primary: green } })
        // const blueTheme = createMuiTheme({ palette: { primary: red } })

        // if there's no login token
        if (window.sessionStorage.getItem("token") == null) {
            return <Redirect to="/login" />;
        }
        // valid playing time or game over
        // console.log('game over', this.state.game_state['game_over'])
        if (!this.state.isValidPlayingTime || this.state.game_state['game_over'] || this.state.game_state['packet_finished']) {
            return <Redirect to="/" />;
        }
        

        let queries;
        if (this.state.game_state['queries']) {
            queries = this.state.game_state['queries'].map((query, index) =>
                <ListItem key={index}>
                    <ListItemText primary={query} />
                </ListItem>
            );
        }

        let prev_docs_selected;
        if (this.state.game_state['tfidf_search_map']) {
            prev_docs_selected = this.state.game_state['tfidf_search_map']['documents_selected'].map((query, index) =>
                <ListItem key={index}>
                    <ListItemText primary={query} />
                </ListItem>
            );
        }

        let evidence_list;
        if (this.state.game_state['evidence']) {
            evidence_list = Object.values(this.state.game_state['evidence']).map((evidence, index) =>
                <ListItem key={index}>
                    <ListItemText primary={evidence} />
                </ListItem>
            );
        }
        var suggestedQueries = [];
        if (this.state.game_state["suggested_query"]){
            suggestedQueries = Object.keys(this.state.game_state["suggested_query"]);
        }

        

        let override_window;
        let points_breakdown;

        if (this.state.answerStatus != null) {
            // let num_unread_clues;
            let num_read_clues;
            this.score = 0;
            if (this.state.answerStatus === 'correct') {
                // num_unread_clues = game_state['question_data']['tokenizations'].length - game_state['buzz_sentence_number']
                num_read_clues = game_state['buzz_sentence_number']
                let baseScore;
                if (this.state.timeOut){
                    baseScore = 50;
                } else {
                    baseScore = 100;
                }
                this.score = baseScore - 10 * Math.max(0, num_read_clues - 1) + 5 * evidence_list.length;
                points_breakdown = 
                <div><small>
                    Score breakdown: <br />
                    {/* Sentence number: {this.state.game_state['buzz_sentence_number']} <br />
                    Total sentences: {this.state.game_state['question_data']['tokenizations'].length} <br /> */}
                    Base score: 100 for timely answer, 50 for late answer <br />
                    Evidence: +5 per record, you recorded {evidence_list.length} evidences <br />
                    Extra clue: -10 per clue, you get {Math.max(0, num_read_clues - 1)} extra clues <br />
                    {/* Score = 10 * (Number of unread clues) + 10 = {10 * num_unread_clues + 10} */}
                    Score = {baseScore} + 5 * {evidence_list.length} - 10 * {Math.max(0, num_read_clues - 1)} = {this.score}
                </small></div>
            }
            let answer_state = this.state.answerStatus;
            let answer_info;
            let encourage_info;
            let try_harder;
            if (answer_state == "correct"){
                answer_info = <p><big><b>🎉 CORRECT ANSWER. You scored {this.score}.</b></big> Press any key to continue, or contest the decision. </p>
                let question_answer_times = this.state.game_state["question_answer_times"]; 
                let question_answer_scores = this.state.game_state["question_answer_scores"]; 
                if (question_answer_times.length === 0){
                    encourage_info = <p><big><b>Fantastic!</b></big> You are the <big><b>first</b></big> to solve this question.</p>
                } else {
                    let long_time_count = 0;
                    let low_score_count = 0;
                    for (let time of question_answer_times){
                        if (time >= 60*this.totalMinutes - this.state.secondsLeft){long_time_count++; }
                    }
                    for (let other_score of question_answer_scores){
                        if (other_score <= this.score){low_score_count++; }
                    }
                    if (low_score_count > 0){
                        encourage_info = <p>Well done! You are scoring above <big><b>{100 * low_score_count / question_answer_scores.length}</b></big>% of the players! </p>
                    } else {
                        if (long_time_count > 0){
                            encourage_info = <p>You solved the question in <big><b>{60*this.totalMinutes - this.state.secondsLeft}</b></big>s, faster than <big><b>{100 * long_time_count / question_answer_times.length}</b></big>% players! </p>
                        } else {
                            if (question_answer_scores.length - low_score_count + 1 <= question_answer_times.length - long_time_count + 1){
                                encourage_info = <p>You achieved the <big><b>{question_answer_scores.length - low_score_count + 1}</b></big> th highest score in this question. Keep going!</p>
                            } else {
                                encourage_info = <p>You are the <big><b>{question_answer_times.length - long_time_count + 1}</b></big> th fastest in solving this question. Keep going!</p>
                            }
                        }
                    }

                }
            } else if (answer_state == "incorrect") {
                answer_info = <p><big><b>🙁 INCORRECT ANSWER</b></big> Press any key to continue, or contest the decision. </p>
                try_harder = <p>Try harder next time! </p>;
            } else if (answer_state == "judging") {
                answer_info = <p><big><b>Judging...</b></big></p>
            }
            if (this.state.game_state.question_data['answer'] === null){
                this.state.game_state.question_data['answer'] = "";
            }
            override_window = 
                <div>
                    <p>{answer_info}{encourage_info}
                    Your answer: <b>{this.state.game_state['player_answer']}</b>, correct answer: <b>{this.state.game_state.question_data['answer'].replaceAll("_"," ")}</b>. {try_harder}</p>
                    {points_breakdown}

                    <Button variant="contained" color="primary" onClick={() => this.advanceQuestion()} className={classes.margin}>
                        Continue (any key)
                    </Button>
                    <Button variant="contained" color="secondary" onClick={() => this.advanceQuestion(true)} className={classes.margin}>
                        Contest decision
                    </Button>
                </div>
        }
        let data_source = "";
        if (this.state.game_state["dataset"] == "qanta"){
            data_source = "(source: Quizbowl)";
        } else if (this.state.game_state["dataset"] == "hotpotqa"){
            data_source = "(source: HotpotQA)";
        }
        

        {/* <ThemeProvider theme={greenTheme}>
                                    <Button variant="contained" color="primary" className={classes.margin}>
                                    Theme Provider
                                    </Button>
                                </ThemeProvider> */}
        
        const {
            stepsEnabled,
            steps,
            initialStep,
            } = this.state;
        
        const tutorial = <Button variant="contained" color="primary" disableElevation onClick={this.startTutorial}>
            Tutorial
        </Button>
        return (

            <div className={classes.root}>
                
                <Steps
                    enabled={stepsEnabled}
                    steps={steps}
                    initialStep={initialStep}
                    onExit={this.onExit}
                />

                
                <Navbar page="game" 
                    endDateTime={this.state.endDateTime} 
                    tutorial={tutorial} 
                    setDrawerOpen={(drawerOpen) => this.setDrawerOpen(drawerOpen)}
                    // scoreAvailable = {Object.keys(this.state.game_state).length > 0}
                    score = {
                        Object.keys(this.state.game_state).length > 0? this.state.game_state['score']: undefined
                    }
                    evidence_list = {evidence_list}
                    queries = {queries}
                    prev_docs_selected = {prev_docs_selected}
                />
                <div className={clsx(classes.body, {
                        [classes.contentShift]: this.state.openDrawer
                    })} 
                    // style={{maxWidth: 1500, margin: "auto"}}
                >
                    {/* {suggested_answer_list} */}
                    <Grid container spacing={1}
                        bgcolor="background.paper"
                    >   
                        <Grid item xs={12} style={{'justifyContent': 'flex-start'}}>

                            {/* answer form */}
                            <Grid item xs={12}>
                                <div className="flex-container" style={{"display": "flex", "alignItems": "center", "justifyContent": "space-between"}}>
                                    <div style={{padding: 10}} id="answerBox">
                                        {/* <AnswerForm onSubmit={this.finishQuestion} label="Answer" /> */}
                                        <AnswerForm 
                                            evidence={this.state.game_state['evidence']}
                                            onSubmit={(answer)=>{this.answerQuestion(answer, "user");}} 
                                            label="Answer"
                                        />
                                    </div>
                                    <Timer seconds={this.state.secondsLeft} totalMinutes={this.totalMinutes} />
                                    {/* <div style={{padding: 10}}>
                                        <Buzzer onClick={this.handleBuzz} 
                                            onTimeout={this.advanceQuestion} 
                                            interrupted={this.state.interrupted}/>
                                    </div> */}
                                    <div style={{padding: 10}}>
                                        <Button variant="contained" color="secondary" onClick={() => this.advanceQuestion(null, true)}>
                                            Skip Question
                                        </Button>
                                    </div>
                                </div>

                                {override_window}
                          
                            </Grid> 

                            {/* question display */}
                            <Grid item xs={12} id="questionText" >
                                <Paper className={classes.paper} style={{ "textAlign": "left" }}>
                                    <small><br/></small><h3 style={{display:"inline"}}>Question {this.state.game_state['question_number']}</h3> {data_source}
                                    {Object.keys(this.state.game_state).length > 0 ?
                                        <div>
                                            <QuestionDisplay
                                                text={this.state.game_state['question_data']['question']}
                                                tokenizations={this.state.game_state['question_data']['tokenizations']}
                                                updateSentencePosition={(index) => this.setState({ sentenceIndex: index })} 
                                                reduceTime={() => this.setState({secondsLeft: this.state.secondsLeft - 30})}
                                                updateGameState = {this.updateGameState}
                                                getSuggestedQuery = {this.getSuggestedQuery}
                                                GPT3_difficulty = {this.state.game_state.question_data["GPT3_difficulty"]}
                                                // sentenceIndex={this.state.sentenceIndex}
                                            />
                                        </div>
                                        
                                        // <QuestionDisplay
                                        //     text={this.state.game_state['question_data']['question']}
                                        //     interrupted={this.state.interrupted}
                                        //     updateSentencePosition={(index) => this.setState({ sentenceIndex: index })}
                                        //     wordIndex={this.state.wordIndex}
                                        //     updateWordIndex={() => this.setState({wordIndex: this.state.wordIndex + 1})}/>
                                        : "Loading..."
                                    }
                                </Paper>
                            </Grid>
                            

                        {/* full document search */}
                        {/* <Grid item xs={12}>
                            <Searcher 
                                currentQuery={this.state.currentQuery}
                                processQuery={this.processQuery}
                                searchLoading={this.state.searchLoading}
                                retrievedTitles={this.state.retrievedTitles}
                                updateGameState={this.updateGameState} 
                                recordKeywordSearchTerms={this.recordKeywordSearchTerms}
                                updateCurrentDocument={this.updateCurrentDocument}
                                recordHighlight={this.recordHighlight}
                            />
                        </Grid> */}

                        {/* passage search */}
                        <Grid item xs={12} id="searcher">
                            {/* <SearcherTfidf updateGameState={this.updateGameState} 
                                recordKeywordSearchTerms={this.recordKeywordSearchTerms}
                                updateCurrentDocument={this.updateCurrentDocument}
                                recordHighlight={this.recordHighlight}
                                /> */}
                            <SearcherPassage 
                                currentQuery={this.state.currentQuery}
                                processQuery={(query) => this.processQuery(query, 'search_box')}
                                suggestedQueries={suggestedQueries} // ["ABCDEABCDEABCDEABCDEABCDE", "FGHIJFGHIJFGHIJFGHIJFGHIJFGHIJFGHIJFGHIJ", "KLMN"] 
                                trySuggestedQuery={(query) => this.processQuery(query, 'suggested')}
                                dislikeSuggestedQuery={(query) => this.dislikeSuggestedQuery(query)}
                                showSuggestedQueries={SHOW_SUGGESTED_QUERIES}
                                searchLoading={this.state.searchLoading}
                                // retrievedTitles={this.state.retrievedTitles}
                                passages={this.state.passages}

                                updateGameState={this.updateGameState} 
                                recordKeywordSearchTerms={this.recordKeywordSearchTerms}
                                updateCurrentDocument={this.updateCurrentDocument}
                                recordHighlight={this.recordHighlight}
                                addIntersectionEvent={this.addIntersectionEvent}
                                selectDocumentEvent={this.selectDocumentEvent.bind(this)}
                                currentQuestionId={this.state.game_state.question_id}
                                curDocumentInfo={this.curDocumentInfo}
                                callback={this.highlightToolCallback}
                                highlightToolOn={this.state.highlightToolOn}
                                sentenceIndex={this.state.sentenceIndex}
                                use_ES={this.state.use_ES}
                                use_DPR={this.state.use_DPR}
                                handle_use_ES={this.handle_use_ES}
                                handle_use_DPR={this.handle_use_DPR}

                                />
                        </Grid>

                    </Grid>
                    <HighlightTool 
                        className="highlightTool"
                        shortcutKey={69} 
                        // zIndex="tooltip"
                        // style={{ zIndex: 1550 }}
                        callback={this.highlightToolCallback}
                        highlightToolOn={()=>this.setState({"highlightToolOn": true})}
                    />

                    
                </Grid>

                </div>
            </div>
        );
    }
}

export default withStyles(useStyles)(withSnackbar(Dashboard));

{/* Toolbar is moved to Navbar.jsx*/}
// <Grid item xs={3} id="toolbar">
// <Paper className={classes.paper}>
//     {Object.keys(this.state.game_state).length > 0 ?
//         <div >                                        
//             <h2>
//             Total Score: {this.state.game_state['score']} <br />
//             </h2>
//             {/* <h3>
//             Evidence score: {this.state.game_state['evidence_score']} <br />
//             Packet Number: {this.state.game_state['packet_number']} <br />
//             </h3> */}
// 
//             {/* debugging */}
//             {/* Answer: {this.state.page} <br /> */}
//             {/* Question Number: {this.state.game_state['question_number']} <br /> */}
//             {/* Question ID: {this.state.game_state['question_id']} <br /> */}
//             {/* Category: {this.state.game_state['question_data']['category']} <br />
//             {question_data['tournament']} {question_data['year']} */}
//         </div>
//     : "Waiting"}
// 
//         
// 
//         <h4>Evidence</h4> 
//         <List component="nav" aria-label="search results" border={1}
//             style={{ 
//                 maxHeight: MAX_HEIGHT, 
//                 overflow: "scroll", 
//                 whiteSpace: "pre-wrap", 
//                 textAlign: "left", 
//                 }}>
//             {evidence_list}
//         </List>
// 
//         <h4>Previous queries</h4> 
//         <List component="nav" aria-label="search results" border={1}
//             style={{ 
//                 maxHeight: MAX_HEIGHT, 
//                 overflow: "scroll", 
//                 whiteSpace: "pre-wrap", 
//                 textAlign: "left", 
//                 }}>
//             {queries}
//         </List>
//         
//         <h4>Previous documents</h4> 
//         <List component="nav" aria-label="search results"
//             style={{ 
//                 maxHeight: MAX_HEIGHT, 
//                 overflow: "scroll", 
//                 whiteSpace: "pre-wrap", 
//                 textAlign: "left", 
//                 }}>
//             {prev_docs_selected}
//         </List>
// 
//         <h4>Keyboard shortcuts:</h4>
//         <div style={{ textAlign: "left"}}>
//             <ul>
//             {/* <li>Buzz: <code>space</code></li> */}
//             <li>Query (focus on search box or auto-search highlighted text): <code>Ctrl-s</code>.</li>
//             <li>Keyword search: <code>Ctrl-f</code></li>
//             <li>Record evidence: <code>Ctrl-e</code></li>     
//             <li>Answer from highlight: <code>Ctrl-space</code></li>                              
//             </ul>
//         
//         </div>
// </Paper>
// </Grid>