# python -m data_analysis.extract_sessions
from collections import Counter, defaultdict
from http.client import UnimplementedFileMode
import json
import logging
import re
import sqlite3
from copy import deepcopy
import string
import time
import datetime
from torch import normal
import nltk
from tqdm import tqdm
from superdebug import debug
from unidecode import unidecode
from backend.irrr_v2.search.search import single_docid_query, single_match_sequence_query
from backend.database import Database, qanta_db, hotpotqa_db, get_question_by_id
from nltk.stem import WordNetLemmatizer

DEBUG = False
data = 'backend/data/spring_novice_question_data.jsonl'
logs = 'backend/data/spring_novice_play_data.jsonl'
PASSAGES = 'retrieval-based-baselines/wiki_passages.db'
if not DEBUG:
    es_logger = logging.getLogger('elasticsearch')
    es_logger.setLevel(logging.WARNING)

class Passage:
    def __init__(self):
        pass
        # self.conn = sqlite3.connect(PASSAGES)
        # self.cursor = self.conn.cursor()

    def get_text(self, psg_id):
        result = single_docid_query(psg_id)
        text = result[0]["text"]
        text = re.sub('<a href="(.*?)">', '\g<1>', text)
        text = re.sub('</a>', '', text)
        return text
        self.cursor.execute("SELECT text FROM wiki_passages where id = {}".format(psg_id))
        return self.cursor.fetchall()[0][0]
    def get_title(self, psg_id):
        result = single_docid_query(psg_id)
        return result[0]["title_unescape"]
        self.cursor.execute("SELECT title FROM wiki_passages where id = {}".format(psg_id))
        title = self.cursor.fetchall()[0][0]
        return title
    def get_text_title_pid(self, psg_id):
        result = single_docid_query(psg_id)
        if len(result) == 0:
            return None
        text = result[0]["text"]
        text = re.sub('<a href="(.*?)">', '', text)
        text = re.sub('</a>', '', text)
        return text, result[0]["title_unescape"], psg_id
    
    def get_matched_paragraph(self, text):
        matched_paras = single_match_sequence_query(text)
        if len(matched_paras) == 0:
            return None
        results = []
        for para in matched_paras:
            text = para["text"]
            text = re.sub('<a href="(.*?)">', '', text)
            text = re.sub('</a>', '', text)
            results.append((text, para["title_unescape"], para["docid"]))
        return results
        

class Questions:
    def __init__(self, dataset):
        self.dataset = dataset

    def get_sent(self, qid, sent_index):
        # bounds = self.questions[qid]['sentence_tokenizations'][sent_index]
        question = get_question_by_id(qid, self.dataset)
        if self.dataset == "qanta":
            bounds = question["tokenizations"][sent_index]
            sent = question["question"][bounds[0]:bounds[1]]
        else:
            sent = question["question"]
        return sent

    def get_answer(self, qid):
        question = get_question_by_id(qid, self.dataset)
        return question['answer']

    def get_sents(self, qid, sent_index = -1):
        question = get_question_by_id(qid, self.dataset)
        if self.dataset == "qanta":
            if sent_index == -1:
                sents = question["question"]
            else:
                bounds = question["tokenizations"][sent_index]
                sents = question["question"][0:bounds[1]]
        else:
            sents = question["question"]
        return sents


class Evidence:
    def __init__(self, type, text=None, title="", pid="", selected_text="", from_query = None):
        self.type = type  #type is either 'passage' or 'span'
        self.text = text
        self.title = title
        self.pid = pid
        self.selected_text = selected_text
        if from_query is None:
            self.from_query = []
        else:
            self.from_query = from_query

def evidences_to_json(evidences):
    def to_json(evidence):
        return {'evidence-type': evidence.type, 'text': evidence.text, "title": evidence.title, "pid": evidence.pid, "selected_text": evidence.selected_text, "from_query": [query[:2] for query in evidence.from_query]}
    if type(evidences) == Evidence:
        return to_json(evidences)
    elif type(evidences) == list:
        return [to_json(evidence) for evidence in evidences ]
    elif type(evidences) == dict:
        for key in evidences:
            if type(evidences[key]) == list:
                evidences[key] = [to_json(evidence) for evidence in evidences[key]]
            elif type(evidences[key]) == Evidence:
                evidences[key] = to_json(evidences[key])
        return evidences

def normalize(text, do_unidecode = False):
    if do_unidecode:
        text = unidecode(text)
    words =  text.lower().translate(str.maketrans(string.punctuation, '                                ')).split()
    return " ".join(words)

wordnet_lemmatizer = WordNetLemmatizer()
def lemmatize_split(text):
    text = nltk.tokenize.word_tokenize(unidecode(text))
    word_tags = nltk.pos_tag(text)
    lemmas = []
    for word, pos_tag in word_tags:
        if word not in string.punctuation:
            try:
                lemma = wordnet_lemmatizer.lemmatize(word.lower(), pos=pos_tag)
            except KeyError:
                lemma = word.lower()
            lemmas.append(lemma)
    return lemmas

def add_type(orig_type, new_type):
    if new_type in orig_type:
        return orig_type
    else:
        return orig_type + "|" + new_type
class Example:
    def __init__(self, packet_num, qid, player_ans, buzz_sent, start_time):
        self.packet_num = packet_num
        self.qid = qid
        self.player_ans = player_ans
        self.buzz_sent = buzz_sent

        self.num_sents = 0
        self.evidences = []
        self.gold_actions = [] #(num_sents, evidence, action)
                               #action: next-sent; query:xx; answer
        self.num_ans_attempts = 0

        self.selected_docs = set()
        self.last_answer = None
        self.last_answer_time = None
        self.search_times = set()

        self.start_time = time.mktime(
                    datetime.datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S.%f').timetuple())
                    #'%b %d, %Y %I:%M:%S %p'

        self.passages_visible = set()
        self.passages_onquery = set()
        self.passages_most_visible = set()

        self.ai_interaction = defaultdict(int)
        self.ai_interaction["query_origin"] = defaultdict(int)

        self.queries = []


    def _add_action(self, typ, arg=None, data=None):
        if arg is None:
            label = typ
        else:
            label = '{}:{}'.format(typ, arg)

        self.gold_actions.append((self.num_sents, deepcopy(self.evidences), label, data))
    def find_complex_query_source(self, query, question_text, data):
        """Find the source of the query when the query is not a substring of any evidence, nor a substring of the question"""
        assert data["origin"] == "search_box"
        # find overlapping words with question
        query_words = Counter(lemmatize_split(query))
        question_words = Counter(lemmatize_split(question_text))
        question_overlap_score = sum((question_words & query_words).values()) / sum((query_words).values())
        if question_overlap_score > 0:
            data["origin"] += "-derived_from_question"
            data["source"]["question_text"] = question_text
            data["question_overlap_score"] = question_overlap_score

        # find overlapping words with evidences
        query_words = query_words - (question_words & query_words) # words that are not in question
        data["source"]["evidences"] = []; data["overlap_score"] = []
        max_overlap_score = 0.00001
        while max_overlap_score > 0 and sum((query_words).values()) > 0: # while max_overlap_score of the last round > 0, and there are still query words that have no source
            max_overlap_score = 0
            for evidence in self.evidences[::-1]:
                evidence_words = Counter(lemmatize_split(evidence.text))
                overlap_score = sum((evidence_words & query_words).values()) / sum((query_words).values())
                if overlap_score > max_overlap_score:
                    max_overlap_score = overlap_score
                    max_overlap_evidence = evidence
                    max_overlap_evidence_words = evidence_words
                    # data["source"] = {"evidences": [evidence]}
            if max_overlap_score > 0:
                if "derived_from_evidence" not in data["origin"]:
                    data["origin"] += "-derived_from_evidence"
                data["overlap_score"].append(max_overlap_score)
                max_overlap_evidence.type = add_type(max_overlap_evidence.type, "source-of-search-box")
                self.decide_query_retrieved_evidence(max_overlap_evidence, True)
                data["source"]["evidences"].append(max_overlap_evidence)
                query_words = query_words - (max_overlap_evidence_words & query_words)

        if data["origin"] == "search_box": # nothing found
            data["origin"] = "search_box-other"
        if sum(query_words.values()) > 0: # exists words that are not in question nor evidences
            data["source"]["user_words"] = query_words
            debug("exists user words!", query=query, data=data)
        return data

    def get_query_data(self, origin, query, passage_ids, play):
        norm_query = normalize(query)
        if len(self.queries) > 0 and query == self.queries[-1][0] and origin == self.queries[-1][2]: # identical with the last query
            return None

        new_query = True
        for _query, proccessed_origin, orig_origin, query_data in self.queries:
            if query == _query and origin == orig_origin:
                new_query = False
                break

        data = {"origin": origin, "source": {}, "retrieved_evidence": False, "retrieved_important_evidence": False}
        question_text = questions.get_sents(self.qid, self.num_sents - 1)
        if origin == "search_box":
            for evidence in self.evidences[::-1]:
                if norm_query in normalize(evidence.text):
                    evidence.type = add_type(evidence.type, "source-of-search-box")
                    self.decide_query_retrieved_evidence(evidence, True)
                    data["source"] = {"evidences": [evidence]}
                    data["origin"] = "search_box-substring_of_evidence"
                    break
            if data["origin"] == "search_box" and norm_query in normalize(question_text):
                data["origin"] = "search_box-substring_of_question"
                data["source"] = {"question_text": question_text}
            if data["origin"] == "search_box":
                data = self.find_complex_query_source(query, question_text, data)

        elif origin == "questionText":
            data["origin"] = "substring_of_question"
            data["source"] = {"question_text": question_text}
        elif origin == "contentpassageSearch":
            passage_ids = list(set(passage_ids))
            passage_ids.sort()
            data["source"], data["overlap_score"] = {"evidences": []}, []
            max_overlap_score = None
            for passage_id in passage_ids:
                origin = "contentpassageSearch"
                for evidence in self.evidences[::-1]:
                    if passage_id == evidence.pid or (passage_id == "" and norm_query in normalize(evidence.text)):
                        origin = "passage_content-substring_of_evidence"
                        source = evidence
                        evidence.type = add_type(evidence.type, "source-of-passage-content-search")
                        self.decide_query_retrieved_evidence(evidence, True)
                        break
                if origin == "contentpassageSearch": # passage_id not in self.evidences
                    text_title_pid = passage_retriver.get_text_title_pid(passage_id)
                    if text_title_pid is not None:
                        origin = "passage_content-substring_of_evidence" # add to evidences
                        source = Evidence('source-of-query|source-of-passage-content-search', *text_title_pid, from_query = [self.queries[-1]])
                        self.decide_query_retrieved_evidence(source, True)
                        self.evidences.append(source)
                    else:
                        return None
                        raise Exception(f"passage_id {passage_id} not exists")
                        max_overlap_score = 0
                        query_words = Counter(lemmatize_split(query))
                        for evidence in self.evidences[::-1]:
                            evidence_text = evidence.text
                            evidence_words = Counter(lemmatize_split(evidence_text))
                            overlap_score = sum((evidence_words & query_words).values()) / sum((query_words).values())
                            if overlap_score > max_overlap_score:
                                max_overlap_score = overlap_score
                                source = evidence

                        if max_overlap_score > 0.3:
                            
                            origin = "passage_content-derived_from_evidence"
                            source.type = add_type(source.type, "source-of-passage-content-search")
                        else:
                            origin = "passage_content-other"
                            source = None
                data["origin"] = origin
                data["source"]["evidences"].append(source)
                data["overlap_score"].append(max_overlap_score)
        elif origin == "suggested":
            query_found = False
            for suggested_query in play["suggested_query"]:
                if norm_query == normalize(suggested_query):
                    query_found = True
                    model = play["suggested_query"][suggested_query][2] if len(play["suggested_query"][suggested_query]) > 2 else "IRRR"
                    if new_query:
                        self.ai_interaction[f"used_query_{model}"] += 1
                        liked = play["suggested_query"][suggested_query][1]
                        if liked:
                            self.ai_interaction[f"liked_query_{model}"] += 1
                    reasoning_path_id = play["suggested_query"][suggested_query][0]
                    question_text = play["current_reasoning_path_map"][reasoning_path_id][0]
                    reasoning_path_evidence_num = play["current_reasoning_path_map"][reasoning_path_id][1]
                    reasoning_path_evidences = play["reasoning_path"][:reasoning_path_evidence_num]
                    data["origin"] = f"suggested-{model}"
                    data["source"] = {"question_text": question_text, "evidences": []}
                    for _evidence in reasoning_path_evidences:
                        evidence_found = False
                        for evidence in self.evidences[::-1]:
                            if _evidence["docid"] == evidence.pid:
                                assert normalize(_evidence["evidence"]) == normalize(evidence.selected_text)
                                data["source"]["evidences"].append(evidence)
                                query_words = Counter(lemmatize_split(query))
                                if sum((Counter(lemmatize_split(evidence.selected_text)) & query_words).values()) / sum((query_words).values()) > 0.3:
                                    evidence.type = add_type(evidence.type, "source-of-model-query-suggestion")
                                    self.decide_query_retrieved_evidence(evidence, True)
                                evidence_found = True
                                
                                break
                        if not evidence_found: # _evidence not in self.evidences
                            context = self.clean_links(_evidence["context"])
                            evidence = Evidence('source-of-query|source-of-model-query-suggestion', context, _evidence["title"], _evidence["docid"], _evidence["evidence"])
                            evidence.from_query = self.find_from_query(evidence, play)
                            data["source"]["evidences"].append(evidence)
                            self.decide_query_retrieved_evidence(evidence, True)
                            self.evidences.append(evidence)

                    break
            assert query_found
        else:
            raise NotImplementedError

        return data
    def decide_query_retrieved_evidence(self, evidence, important=False):
        for query in evidence.from_query:
            query[3]["retrieved_evidence"] = True
            if important:
                query[3]["retrieved_important_evidence"] = True

    def find_from_query(self, evidence:Evidence, play):
        query_results_map = play["tfidf_search_map"]["query_results_map"]
        query_texts = []
        for query in query_results_map:
            for result in query_results_map[query]:
                if result["id"].split("-")[:2] == evidence.pid.split("-")[:2]:
                    query_texts.append(query)
                    assert result["page"] == evidence.title
                    break
        from_query = []
        for query_text in query_texts:
            for _query in self.queries[::-1]:
                if _query[0] == query_text:
                    from_query.append(_query)
                    break
        return from_query


    def proc_next_sent(self, sent_index):
        if sent_index > 0:
            self._add_action('next-sent')
        self.num_sents = sent_index+1

    def proc_search(self, query, timestamp, origin, passage_id, play):
        if origin == "":
            origin = "search_box"
        data = self.get_query_data(origin, query, passage_id, play)
        if data is None: # the query is identical to the last query
            return
        self.queries.append((query, data["origin"], origin, data))
        self._add_action('query', query, data)
        self.search_times.add(timestamp - self.start_time)


    def proc_sel_document(self, passage_id):
        if passage_id not in self.selected_docs:
            text_title_pid = passage_retriver.get_text_title_pid(passage_id)
            if text_title_pid is not None:
                pid = text_title_pid[2]
                self.evidences_append_nonrepeat(Evidence('selected-passage', *text_title_pid, from_query = [self.queries[-1]]))
                self.selected_docs.add(passage_id)

    def proc_record_evidence(self, splited_evidence, reasoning_path): # refer to record_evidence in game_manager_generic.py
        for evidence_text in splited_evidence:
            in_reasoning_path = False
            norm_evidence_text = normalize(evidence_text)
            for ev in reasoning_path:
                if norm_evidence_text == normalize(ev["evidence"]):
                    context = self.clean_links(ev["context"])
                    if norm_evidence_text in normalize(context): # might not be satisfied due to bugs
                        evidence = Evidence('player-recorded', context, ev["title"], ev["docid"], evidence_text, from_query = [self.queries[-1]])
                        in_reasoning_path = True
                        break
            if not in_reasoning_path:
                evidence_found = False
                text_title_pids = passage_retriver.get_matched_paragraph(evidence_text)
                for text_title_pid in text_title_pids:
                    if norm_evidence_text in normalize(text_title_pid[0]):
                        evidence = Evidence('player-recorded', *text_title_pid, evidence_text, from_query = [self.queries[-1]])
                        evidence_found = True
                        break
                if not evidence_found:
                    evidence = Evidence('player-recorded', *text_title_pids[0], evidence_text, from_query = [self.queries[-1]])
                    debug("Evidence not found", self.evidences[-1])
            
            self.evidences_append_nonrepeat(evidence)
            

    def clean_links(self, context):
        context = re.sub('<a href="(.*?)">', '', context)
        context = re.sub('</a>', '', context)
        return context

    def proc_answer(self, answer, timestamp, origin, passage_ids, play): 
        if origin == "":
            origin = "user"
        data = self.get_answer_data(origin, answer, passage_ids, play)
        self.last_answer = (answer, data)
        self.last_answer_time = timestamp - self.start_time
        """
        self._add_action('answer', answer)
        self.num_ans_attempts += 1
        if self.num_ans_attempts == 2:
            print('ERROR: multiple answer attempts')
        """

    def get_answer_data(self, origin, answer, passage_ids, play):
        """
        suggested_answer dict {..} with 2 keys ['Battle of the Alamo', 'Bowie County']
        Battle of the Alamo list size: 3 [...]
            item 0:  str len 40: 1cfd6f31efa40edcb815360b7a61f4c75e5d4345
            item 1:  bool: False
            item 2:  str len 4: IRRR
        Bowie County list size: 3 [...]
            item 0:  str len 40: 5124090cd577df5d2628e2951402f29b9287a93d
            item 1:  bool: False
            item 2:  str len 4: IRRR
        """
        data = {"origin": origin, "source": {"evidences": []}} # "question_text": question_text
        answer = answer
        if origin == "user":
            for evidence in self.evidences[::-1]:
                evidence_text = evidence.text
                if normalize(answer) in normalize(evidence_text):
                    data["source"] = {"evidences": [evidence]}
                    evidence.type = add_type(evidence.type, "source-of-user-answer")
                    self.decide_query_retrieved_evidence(evidence, True)
                    data["origin"] = "user-substring_of_evidence"
                    break
            if data["origin"] == "user":
                max_overlap_score = 0
                answer_words = Counter(lemmatize_split(answer))
                for evidence in self.evidences[::-1]:
                    evidence_text = evidence.text
                    evidence_words = Counter(lemmatize_split(evidence_text))
                    overlap_score = sum((evidence_words & answer_words).values()) / sum((answer_words).values())
                    if overlap_score > max_overlap_score:
                        max_overlap_score = overlap_score
                        data["source"] = {"evidences": [evidence]}
                if max_overlap_score > 0.3:
                    data["origin"] = f"user-derived_from_evidence"
                    data["overlap_score"] = [max_overlap_score]
                    data["source"]["evidences"][0].type = add_type(data["source"]["evidences"][0].type, "source-of-user-answer")
                    self.decide_query_retrieved_evidence(data["source"]["evidences"][0], True)
                else:
                    data["source"] = {"evidences": []}
            if data["origin"] == "user":
                data["origin"] = "user-other"
        elif origin == "contentpassageSearch":
            passage_ids = list(set(passage_ids))
            passage_ids.sort()
            data = {"origin": origin, "source": {"evidences": []}, "overlap_score": []}
            max_overlap_score = None
            for passage_id in passage_ids:
                origin = "contentpassageSearch"
                for evidence in self.evidences[::-1]:
                    if passage_id == evidence.pid:
                        origin = "passage_content-substring_of_evidence"
                        source = evidence
                        evidence.type = add_type(evidence.type, "source-of-passage-content-answer")
                        self.decide_query_retrieved_evidence(evidence, True)
                        break
                if origin == "contentpassageSearch": # not in self.evidences
                    text_title_pid = passage_retriver.get_text_title_pid(passage_id)
                    if text_title_pid is not None:
                        origin = "passage_content-substring_of_evidence" # add to evidences
                        source = Evidence('source-of-answer|source-of-passage-content-answer', *text_title_pid, from_query = [self.queries[-1]])
                        self.decide_query_retrieved_evidence(source, True)
                        self.evidences.append(source)
                    else:
                        max_overlap_score = 0
                        answer_words = Counter(lemmatize_split(answer))
                        for evidence in self.evidences[::-1]:
                            evidence_text = evidence.text
                            evidence_words = Counter(lemmatize_split(evidence_text))
                            overlap_score = sum((evidence_words & answer_words).values()) / sum((answer_words).values())
                            if overlap_score > max_overlap_score:
                                max_overlap_score = overlap_score
                                source = evidence

                        if max_overlap_score > 0.3:
                            origin = "passage_content-derived_from_evidence"
                            source.type = add_type(source.type, "source-of-passage-content-answer")
                            self.decide_query_retrieved_evidence(source, True)
                        else:
                            origin = "passage_content-other"
                            source = None
                data["origin"] = origin
                if source is not None:
                    data["source"]["evidences"].append(source)
                    data["overlap_score"].append(max_overlap_score)
        elif origin == "suggested":
            answer_found = False
            for suggested_answer in play["suggested_answer"]:
                if normalize(answer) == normalize(suggested_answer):
                    answer_found = True
                    model = play["suggested_answer"][suggested_answer][2] if len(play["suggested_answer"][suggested_answer]) > 2 else "IRRR"
                    self.ai_interaction[f"used_answer_{model}"] += 1
                    liked = play["suggested_answer"][suggested_answer][1]
                    if liked:
                        self.ai_interaction[f"liked_answer_{model}"] = 1
                        if play["answer_correct"]:
                            self.ai_interaction[f"liked_answer_correct_{model}"] = 1
                    reasoning_path_id = play["suggested_answer"][suggested_answer][0]
                    question_text = play["current_reasoning_path_map"][reasoning_path_id][0]
                    reasoning_path_evidence_num = play["current_reasoning_path_map"][reasoning_path_id][1]
                    reasoning_path_evidences = play["reasoning_path"][:reasoning_path_evidence_num]
                    data["origin"] = f"suggested-{model}"
                    data["source"] = {"question_text": question_text, "evidences": []}
                    for _evidence in reasoning_path_evidences:
                        evidence_found = False
                        for evidence in self.evidences[::-1]:
                            if _evidence["docid"] == evidence.pid:
                                if evidence.selected_text == "":
                                    evidence.selected_text = _evidence["evidence"]
                                assert _evidence["evidence"] == evidence.selected_text or sum((Counter(lemmatize_split(evidence.text)) & Counter(lemmatize_split(_evidence["evidence"]))).values()) / sum((Counter(lemmatize_split(_evidence["evidence"]))).values()) > 0.9
                                data["source"]["evidences"].append(evidence)
                                answer_words = Counter(lemmatize_split(answer))
                                if sum((Counter(lemmatize_split(evidence.selected_text)) & answer_words).values()) / sum((answer_words).values()) > 0.3:
                                    evidence.type = add_type(evidence.type, "source-of-model-answer-suggestion")
                                    self.decide_query_retrieved_evidence(evidence, True)
                                evidence_found = True
                                break
                        if not evidence_found: # not in self.evidences
                            context = self.clean_links(_evidence["context"])
                            evidence = Evidence('source-of-answer|source-of-model-answer-suggestion', context, _evidence["title"], _evidence["docid"], _evidence["evidence"])
                            evidence.from_query = self.find_from_query(evidence, play)
                            self.decide_query_retrieved_evidence(evidence, True)
                            data["source"]["evidences"].append(evidence)
                            self.evidences.append(evidence)

                    break
            assert answer_found
        else:
            raise NotImplementedError
        return data
    def proc_scrolling(self, vis_events, search_time = None):
        """
        vis_events: [
                        {"passage_id": "16145954", "time": 43, "is_visible": true}
                    ]
        """
        if search_time is not None: self.search_times.add(search_time- self.start_time)
        vis_passages = set()
        vis_on_answer = set()
        vis_on_query = set() 
        passage_status = {}
        for event in vis_events:
            if event['is_visible']: vis_passages.add(event['passage_id'])
            pid = event['passage_id']
            if pid in passage_status:
                if event['is_visible']:
                    if not passage_status[pid]['visible']:
                        passage_status[pid]['visible'] = True
                        passage_status[pid]['last_start'] = event['time']
                elif passage_status[pid]['visible']:
                    passage_status[pid]['visible'] = False
                    passage_status[pid]['total_vis'] += \
                                    event['time'] - passage_status[pid]['last_start']

                    if self.last_answer_time is not None and passage_status[pid]['last_start'] <= self.last_answer_time <= event['time']:
                        vis_on_answer.add(pid)

                    for search_time in self.search_times:
                        if passage_status[pid]['last_start'] <= search_time <= event['time']:
                            vis_on_query.add(pid)

            elif event['is_visible']:
                passage_status[pid] = {'visible': True,'last_start': event['time'], 'total_vis':0}

        #all visible
        for pid in vis_passages:
            if pid not in self.selected_docs and pid not in self.passages_visible:
                text_title_pid = passage_retriver.get_text_title_pid(pid)
                if text_title_pid is not None:
                    if len(self.queries) == 0:
                        debug("ERROR: no queries recorded")
                        return "error"
                    self.evidences_append_nonrepeat(Evidence('visible-passage', *text_title_pid, from_query = [self.queries[-1]]))
                    self.passages_visible.add(pid)
        
        #most visible (can be same as selected)
        most_time = 0
        most_vis_psg = None
        for pid, data in passage_status.items():
            if data['total_vis'] > most_time:
                most_vis_psg = pid
                most_time = data['total_vis']

        if most_vis_psg is not None and most_vis_psg not in self.passages_most_visible:
            text_title_pid = passage_retriver.get_text_title_pid(most_vis_psg)
            if text_title_pid is not None:
                self.evidences_append_nonrepeat(Evidence('most-visible-passage', *text_title_pid, from_query = [self.queries[-1]]))
                self.passages_most_visible.add(most_vis_psg)

        #visible at answering
        for pid in vis_on_answer:
            text_title_pid = passage_retriver.get_text_title_pid(pid)
            if text_title_pid is not None:
                self.evidences_append_nonrepeat(Evidence('visible-on-answering', *text_title_pid, from_query = [self.queries[-1]]))


        #visible at querying
        for pid in vis_on_query:
            if pid not in self.passages_onquery:
                text_title_pid = passage_retriver.get_text_title_pid(pid)
                if text_title_pid is not None:
                    self.evidences_append_nonrepeat(Evidence('visible-on-query', *text_title_pid, from_query = [self.queries[-1]]))
                    self.passages_onquery.add(pid)

    def evidences_append_nonrepeat(self, evidence:Evidence):
        evidence_exists = False
        for _evidence in self.evidences:
            if evidence.pid == _evidence.pid:
                if evidence.type not in _evidence.type:
                    _evidence.type = _evidence.type + '|' + evidence.type
                if evidence.selected_text != "" and _evidence.selected_text == "":
                    _evidence.selected_text = evidence.selected_text
                if evidence.from_query[0] not in _evidence.from_query:
                    _evidence.from_query.extend(evidence.from_query)
                evidence_exists = True
                break
        if not evidence_exists:
            self.decide_query_retrieved_evidence(evidence)
            self.evidences.append(evidence)


    def finish(self):
        if self.last_answer is None:
            print('ERROR: no answer recorded')
            return "error"
        else:
            self._add_action('answer', *self.last_answer)

def extract_one_play(play):
    if play['player_answer'] == "": return None # consider as skipped
    example = Example(play['packet_number'], play['question_id'], play['player_answer'],
                        play['buzz_sentence_number'], play['start_datetime'])
    scrolling = []
    this_pid = None
    # extract actions
    for action_i, action in enumerate(sorted(play['actions'], key=lambda action: action['time'])): # actions in the order of time
        if action['name'] == 'next_sentence':
            example.proc_scrolling(scrolling)
            scrolling = []
            example.proc_next_sent(action['data']['sentence_index'])
        elif action['name'] == 'search_documents':
            example.proc_scrolling(scrolling, search_time = action['time'])
            scrolling = []
            example.proc_search(action['data']['query'], action['time'], action['data']['origin'], action['data']['passage_id'], play)
        elif action['name'] == 'select_document':
            if len(example.queries) == 0:
                debug("ERROR: no queries recorded")
                return None # error
            example.proc_sel_document(action['data']['passage_id'])
            this_pid = action['data']['passage_id']
        elif action['name'] == 'record_evidence':
            if len(example.queries) == 0:
                debug("ERROR: no queries recorded")
                return None # error
            if 'data' not in action:
                print('ERROR: Record evidence without data',action)
            else:
                example.proc_record_evidence(action['data'], play["reasoning_path"])
        elif action['name'] == 'answer':
            example.proc_scrolling(scrolling)
            scrolling = []            
            example.proc_answer(action['data']['answer'], action['time'], action['data']['origin'], action['data']['passage_id'], play)
        elif action['name'] == 'document_actions':
            if action_i == 0:
                debug("ERROR: first action being document_actions")
                return None # error
            if 'intersectionEvents' in  action:#['intersectionEvents']: #action['data']:
                scrolling.extend(action['intersectionEvents'])
            elif 'intersectionEvents' in action['data']:
                scrolling.extend(action['data']['intersectionEvents'])
            elif 'intersectionEvents' in action['data']['documentActions']:
                scrolling.extend(action['data']['documentActions']['intersectionEvents'])
            else:
                raise Exception('ERROR: document_actions without intersectionEvents')
        else:
            # debug(action=action)
            assert action['name'] in ['document_actions', 'advance_keyword_match'], action['name']

    ret = example.proc_scrolling(scrolling)
    if ret == "error":
        return None
    ret = example.finish()
    if ret == "error":
        return None

    # analyze suggested queries and answers
    tmp_interaction = defaultdict(int)
    for query in play["suggested_query"]:
        if len(play["suggested_query"][query]) == 3:
            reasoning_path_id, liked, model = play["suggested_query"][query]
        else:
            reasoning_path_id, liked = play["suggested_query"][query]
            model = "IRRR"
        example.ai_interaction[f"suggested_query_{model}"] += 1
        if liked:
            tmp_interaction[f"liked_query_{model}"] += 1
    for answer in play["suggested_answer"]:
        if len(play["suggested_answer"][answer]) == 3:
            reasoning_path_id, liked, model = play["suggested_answer"][answer]
        else:
            reasoning_path_id, liked = play["suggested_answer"][answer]
            model = "IRRR"
        example.ai_interaction[f"suggested_answer_{model}"] += 1
        if liked:
            tmp_interaction[f"liked_answer_{model}"] += 1
    if not( tmp_interaction[f"liked_query_IRRR"] == example.ai_interaction[f"liked_query_IRRR"] and tmp_interaction[f"liked_query_golden"] == example.ai_interaction[f"liked_query_golden"] and tmp_interaction[f"liked_answer_IRRR"] == example.ai_interaction[f"liked_answer_IRRR"] and tmp_interaction[f"liked_answer_golden"] == example.ai_interaction[f"liked_answer_golden"]):
        return None

    # analyze others
    wiki_pages = set()
    example.important_evidence_num = 0
    example.important_evidence_query_origin = defaultdict(int)
    for evidence in example.evidences:
        wiki_pages.add(evidence.title)
        if "source-of" in evidence.type or "player-recorded" in evidence.type:
            example.important_evidence_num += 1
            for query in evidence.from_query:
                example.important_evidence_query_origin[query[1]] += 1
    example.viewed_wiki_page_num = len(wiki_pages)
    if example.important_evidence_num == 0:
        debug("important_evidence_num=0", example=example)
    
    example.search_engine_usage = defaultdict(int)
    for query in play["tfidf_search_map"]["query_results_map"]:
        search_results = play["tfidf_search_map"]["query_results_map"][query]
        search_engines = set()
        for search_result in search_results:
            if type(search_result) == list:
                if len(search_result) == 3:
                    search_engines.add(search_result[-1])
                else:
                    search_engines.add("unk")
            elif type(search_result) == dict:
                search_engines.add(search_result["engine"])
        if len(search_engines) == 1:
            example.search_engine_usage[list(search_engines)[0]] += 1
        else:
            example.search_engine_usage["multi"] += 1
    return example



def evidences_to_str(evidences):
    output = ''
    for ev in evidences:
        output += 'type:{}-texts:{}'.format(ev['evidence-type'], ev['text'])
    return output

def aggregate_actions(action_name, action_data, all_query_origin, all_answer_origin):
    origin = action_data['origin']
    overlap_scores = action_data["overlap_score"] if "overlap_score" in action_data else None
    # for i, origin in enumerate(origins):
        # overlap_score = overlap_scores[i] if overlap_scores is not None else None
    if action_name == 'query':
        all_query_origin[origin] += 1
        if overlap_scores is not None:
            if f"{origin}-overlap_scores" not in all_query_origin:
                all_query_origin[f"{origin}-overlap_scores"] = []
            all_query_origin[f"{origin}-overlap_scores"].extend(overlap_scores)
    elif action_name == 'answer':
        all_answer_origin[origin] += 1
        if overlap_scores is not None:
            if f"{origin}-overlap_scores" not in all_answer_origin:
                all_answer_origin[f"{origin}-overlap_scores"] = []
            all_answer_origin[f"{origin}-overlap_scores"].extend(overlap_scores)

def merge_counter(main_counter, new_counter):
    for key, value in new_counter.items():
        if type(value) == int or type(value) == float:
            main_counter[key] += value
        elif key in main_counter:
            merge_counter(main_counter[key], value)
        else:
            main_counter[key] = value
    """ 
    ai_interaction defaultdict {...} with default 0 8 keys ['liked_answer_IRRR', 'liked_answer_golden', 'liked_query_IRRR', 'liked_query_golden', 'query_origin', 'suggested_answer_IRRR', 'suggested_query_IRRR', 'used_query_IRRR']
        liked_answer_IRRR num val: 0
        liked_answer_golden num val: 0
        liked_query_IRRR num val: 1
        liked_query_golden num val: 0
        query_origin defaultdict {.} with default 0 1 keys ['suggested-IRRR']
            suggested-IRRR num val: 1
        suggested_answer_IRRR num val: 2
        suggested_query_IRRR num val: 2
        used_query_IRRR num val: 1
    """
if __name__ == '__main__':

    passage_retriver = Passage()
    qanta_questions, hotpotqa_questions = Questions("qanta"), Questions("hotpotqa")
    
    discard_users = {f"{i}@{i}.com" for i in range(100)}
    discard_users.update({"hwr19@mails.tsinghua.edu.cn", "1@qq.com"})

    added_actions = set()
    qanta_gold_sessions, hotpotqa_gold_sessions = [], []

    qanta_ai_interaction, hotpotqa_ai_interaction = defaultdict(int), defaultdict(int)
    qanta_query_origin, hotpotqa_query_origin = defaultdict(int), defaultdict(int)
    qanta_answer_origin, hotpotqa_answer_origin = defaultdict(int), defaultdict(int)

    qanta_viewed_wiki_page_nums, hotpotqa_viewed_wiki_page_nums = [], []
    qanta_correct_important_evidence_nums, hotpotqa_correct_important_evidence_nums = [], []
    qanta_important_evidence_query_origin, hotpotqa_important_evidence_query_origin = defaultdict(int), defaultdict(int)
    qanta_search_engine_usage, hotpotqa_search_engine_usage = defaultdict(int), defaultdict(int)
    query_words_length = []
    for db in [qanta_db, hotpotqa_db]:
    # for dataset in ["hotpotqa", "qanta"]:

        # db.clear_tmp_data()
        play_logs = db.extract_plays()
        if DEBUG:
            play_logs = play_logs[:10]


        for play_i, play in enumerate(tqdm(play_logs)):
            # filter out invalid data
            if play["username"] in discard_users:
                continue
            if play_i > 0 and play["player_answer"] == play_logs[play_i -1]["player_answer"]:
                continue
            if "override_decision" in play and play["override_decision"] == True:
                continue

            qid = play['question_id']
            try:
                int(qid) # qanta_id is an integer
                dataset, questions, gold_sessions, all_ai_interaction, all_query_origin, all_answer_origin, viewed_wiki_page_nums, correct_important_evidence_nums, all_important_evidence_query_origin, all_search_engine_usage = "qanta", qanta_questions, qanta_gold_sessions, qanta_ai_interaction, qanta_query_origin, qanta_answer_origin, qanta_viewed_wiki_page_nums, qanta_correct_important_evidence_nums, qanta_important_evidence_query_origin, qanta_search_engine_usage
            except:
                dataset, questions, gold_sessions, all_ai_interaction, all_query_origin, all_answer_origin, viewed_wiki_page_nums, correct_important_evidence_nums, all_important_evidence_query_origin, all_search_engine_usage = "hotpotqa", hotpotqa_questions, hotpotqa_gold_sessions, hotpotqa_ai_interaction, hotpotqa_query_origin, hotpotqa_answer_origin, hotpotqa_viewed_wiki_page_nums, hotpotqa_correct_important_evidence_nums, hotpotqa_important_evidence_query_origin, hotpotqa_search_engine_usage

            tr_example = extract_one_play(play)
            if tr_example is None or (not tr_example.gold_actions[-1][2].startswith("answer:")):
                continue

            merge_counter(all_ai_interaction, tr_example.ai_interaction)
            merge_counter(all_important_evidence_query_origin, tr_example.important_evidence_query_origin)
            merge_counter(all_search_engine_usage , tr_example.search_engine_usage)
            viewed_wiki_page_nums.append(tr_example.viewed_wiki_page_num)
            if play['answer_correct'] == True:
                correct_important_evidence_nums.append(tr_example.important_evidence_num)
            num_actions_session = len(tr_example.gold_actions)
            for query in tr_example.queries:
                query_words_length.append(len(query[0].split()))

            # num_sentences, num_queries = 0, 0
            # for gold in tr_example.gold_actions:
            #     action_name = gold[2].split(':')[0]
            #     if action_name == 'query':
            #         num_queries += 1
            #     elif action_name == 'next-sent':
            #         num_sentences += 1
            
            # construct action chains
            cur_query, cur_sentence = 0, 0
            gold_actions = []
            for action_num,gold in enumerate(tr_example.gold_actions): # action is one of query, next-sent, answer
                question = questions.get_sents(qid, gold[0]-1)
                # question = questions.get_sent(qid, gold[0]-1)

                evidences = evidences_to_json(gold[1])
                action = gold[2]
                action_name = gold[2].split(':')[0]
                action_data = gold[3]
                if action_data is not None:
                    aggregate_actions(action_name, action_data, all_query_origin, all_answer_origin)
                    if "evidences" in action_data["source"] and action_data["source"]["evidences"] == [None]:
                        action_data["source"]["evidences"] = []
                    action_data["source"] = evidences_to_json(action_data["source"])
                key = 'question||{}-action||{}-evidence||{}'.format(question,
                                                            action, evidences_to_str(evidences))

                if key not in added_actions:
                    gold_actions.append({
                        'question_id': qid,
                        'question': question,
                        'answer': questions.get_answer(qid),
                        'action': action,
                        'action_data': action_data,
                        'evidences': evidences, # evidence is the paragraphs that the user have seen (including the evidences recorded and not recorded by the user)

                        'num_actions': num_actions_session,
                        'answer_correct': play['answer_correct'],
                        # 'num_actions_until_answer': num_actions_session-action_num,
                        # 'num_queries_until_answer': num_queries-cur_query,
                        # 'num_sentences_until_answer': num_sentences-cur_sentence
                        })

                    added_actions.add(key)

            if gold_actions: gold_sessions.append(gold_actions)

        
    qanta_correct_sessions = [session for session in qanta_gold_sessions if session[0]['answer_correct']]
    hotpotqa_correct_sessions = [session for session in hotpotqa_gold_sessions if session[0]['answer_correct']]
    debug(avg_query_words_length = sum(query_words_length)/len(query_words_length), query_words_length=Counter(query_words_length))
    # with open('backend/data/previous_collected/gold-sessions-4.json', 'w') as oh: json.dump(gold_sessions, oh, indent=4)
    with open(f'backend/data/20220604/sessions-qanta.json', 'w') as oh: json.dump(qanta_gold_sessions, oh, indent=4)
    with open(f'backend/data/20220604/correct-sessions-qanta.json', 'w') as oh: json.dump(qanta_correct_sessions, oh, indent=4)
    debug('qanta total: {}, correct: {}'.format(len(qanta_gold_sessions), len(qanta_correct_sessions)))
    debug(qanta_ai_interaction=qanta_ai_interaction, qanta_query_origin=qanta_query_origin, qanta_answer_origin=qanta_answer_origin)
    debug(avg_qanta_viewed_wiki_page_num = sum(qanta_viewed_wiki_page_nums) / len(qanta_viewed_wiki_page_nums), qanta_viewed_wiki_page_nums=Counter(qanta_viewed_wiki_page_nums))
    debug(avg_qanta_important_evidence_num = sum(qanta_correct_important_evidence_nums) / len(qanta_correct_important_evidence_nums), qanta_important_evidence_nums=Counter(qanta_correct_important_evidence_nums))
    debug(qanta_important_evidence_query_origin=qanta_important_evidence_query_origin)
    debug(qanta_search_engine_usage=qanta_search_engine_usage)
    with open(f'backend/data/20220604/sessions-hotpotqa.json', 'w') as oh: json.dump(hotpotqa_gold_sessions, oh, indent=4)
    with open(f'backend/data/20220604/correct-sessions-hotpotqa.json', 'w') as oh: json.dump(hotpotqa_correct_sessions, oh, indent=4)
    debug('hotpotqa total: {}, correct: {}'.format(len(hotpotqa_gold_sessions), len(hotpotqa_correct_sessions)))
    debug(hotpotqa_ai_interaction=hotpotqa_ai_interaction, hotpotqa_query_origin=hotpotqa_query_origin, hotpotqa_answer_origin=hotpotqa_answer_origin)
    debug(avg_hotpotqa_viewed_wiki_page_num = sum(hotpotqa_viewed_wiki_page_nums) / len(hotpotqa_viewed_wiki_page_nums), hotpotqa_viewed_wiki_page_nums=Counter(hotpotqa_viewed_wiki_page_nums))
    debug(avg_hotpotqa_important_evidence_num = sum(hotpotqa_correct_important_evidence_nums) / len(hotpotqa_correct_important_evidence_nums), hotpotqa_important_evidence_nums=Counter(hotpotqa_correct_important_evidence_nums))
    debug(hotpotqa_important_evidence_query_origin=hotpotqa_important_evidence_query_origin)
    debug(hotpotqa_search_engine_usage=hotpotqa_search_engine_usage)
