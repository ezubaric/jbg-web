# python -m data_analysis.award_prizes
#%%
from collections import defaultdict
import json
import sqlite3
from copy import deepcopy
import time
import datetime
from tqdm import tqdm
from superdebug import debug
import sys
sys.path.append('../')
from backend.database import Database, qanta_db, hotpotqa_db

all_user_ids = qanta_db.get_all_users()
#%%
all_user_data = defaultdict(dict)
for _user_id in all_user_ids:
    user_id = _user_id[0]
    user_state = qanta_db.get_user_state(user_id)
    if len(user_state) > 0:
        all_user_data[user_id]["total_score"] = user_state["score"]
        all_user_data[user_id]["answered_questions_num"] = 0
        all_user_data[user_id]["correct_answers_num"] = 0
#%%
all_answers_num, all_correct_answers_num = 0, 0
for dataset in ["qanta", "hotpotqa"]:
    if dataset == "qanta":
        db = qanta_db
    elif dataset == "hotpotqa":
        db = hotpotqa_db
    play_logs = db.extract_plays()
    for play_i, play in enumerate(play_logs):
        user_id = play["username"]
        if play_i > 0 and play["player_answer"] == play_logs[play_i - 1]["player_answer"]:
            continue
        if user_id in all_user_data:
            all_user_data[user_id]["answered_questions_num"] += 1
            if play["answer_correct"]:
                all_user_data[user_id]["correct_answers_num"] += 1
                all_correct_answers_num += 1
            all_answers_num += 1
        else:
            print(f"{user_id} not in all_user_data")
#%% filter and sort
for user_id in list(all_user_data.keys()):
    if all_user_data[user_id]["correct_answers_num"] <=1 or all_user_data[user_id]["total_score"] == 0:
        del all_user_data[user_id]
all_user_data = list(all_user_data.items())
all_user_data.sort(key=lambda x: x[1]["total_score"], reverse=True)
#%%
from prettytable import PrettyTable
x = PrettyTable()
x.field_names = ["Username", "Total Score", "Number of answered questions"] #, "Number of correct answers"]
for user_data in all_user_data:
    x.add_row([user_data[0], user_data[1]["total_score"], user_data[1]["answered_questions_num"]]) #, user_data[1]["correct_answers_num"]])
debug(all_correct_answers_num=all_correct_answers_num, all_answers_num=all_answers_num)
print("🌟 Today's Leaderboard 🌟")
print(x)
print(f"Congratulations to {all_user_data[0][0]} for the highest score!")

raffle_players = [user_data[0] for user_data in all_user_data if user_data[1]["answered_questions_num"] >= 40]
print("We will raffle among the players who have answered 40+ questions, including:", ", ".join(raffle_players))
print("To be eligible for your prize, don't forget to complete the feedback form! For those that have previously completed the form, please double-check it and update your prior response because we have modified a few options and added a few questions. We appreciate everything you've done!")

# %%
