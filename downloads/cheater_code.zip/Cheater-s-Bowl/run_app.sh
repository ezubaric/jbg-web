poetry shell
caddy run &
uvicorn backend.server:app --port 4006  --reload
# uvicorn backend.search_document_server:app --port 5006  --reload &
uvicorn backend.DPR.dense_retriever_cli:app --port 5006
sh launch_elasticsearch_6.7.sh

cd frontend
yarn start &

ngrok http 3006