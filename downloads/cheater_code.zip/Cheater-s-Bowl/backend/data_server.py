import json
from fastapi import APIRouter
# import time
# from pydantic import BaseModel
import sqlite3
import marshal
from superdebug import debug

# HOTPOTQA_NUM_ROWS = 90447 # train set, contains almost all the training samples (of all difficulties) in HotpotQA
HOTPOTQA_NUM_ROWS = 7405 # dev set
hotpotqa_table_name = 'hotpotqa'
hotpotqa_db_path = '../golden-retriever/hotpotqa.db'

nq_table_name = 'nq'
nq_db_path = '../retrieval-based-baselines/nq.db'

router = APIRouter()


@router.get("/hotpotqa/get_row_by_id/{row_id}")
def get_hotpotqa_row_by_id(row_id: str):
    conn = sqlite3.connect(hotpotqa_db_path)
    c = conn.cursor()

    query_str = f'''select * from {hotpotqa_table_name} where _id=?'''
    # debug(row_id = row_id)
    c.execute(query_str, (row_id,))
    doc = c.fetchone()
    # debug(hotpotqa_row = doc)
    viewed_users = doc[7]
    try:
        viewed_users = json.loads(viewed_users)
    except:
        viewed_users = []
    if doc == None: return None
    else: return {'id':doc[0], 'question':doc[1], 'answer':doc[2], "viewed_users":viewed_users, "GPT3_difficulty": doc[8]}

@router.get("/hotpotqa/get_random_row")
def get_hotpotqa_random_row():
    conn = sqlite3.connect(hotpotqa_db_path)
    c = conn.cursor()

    query_str = f'''SELECT * FROM {hotpotqa_table_name} ORDER BY RANDOM() LIMIT 1;'''
    c.execute(query_str)

    doc = c.fetchone()
    print('hotpotqa row: ', doc)
    viewed_users = doc[7]
    try:
        viewed_users = json.loads(viewed_users)
    except:
        viewed_users = []
    return {'id':doc[0], 'question':doc[1], 'answer':doc[2], "viewed_users":viewed_users, "GPT3_difficulty": doc[8]}


@router.get("/nq/get_row_by_question/{question}")
def get_row_by_id(question: str):
    conn = sqlite3.connect(nq_db_path)
    c = conn.cursor()

    query_str = f'''select * from {nq_table_name} where question=?'''
    c.execute(query_str, (question,))
    doc = c.fetchone()
    print('nq row: ', doc)

    if doc == None: return None
    else: return {'id':doc[0], 'question':doc[1], 'answer':marshal.loads(doc[2])}

@router.get("/nq/get_random_row")
def get_nq_random_row():
    conn = sqlite3.connect(nq_db_path)
    c = conn.cursor()

    query_str = f'''SELECT * FROM {nq_table_name} ORDER BY RANDOM() LIMIT 1;'''
    c.execute(query_str)

    doc = c.fetchone()
    print('nq row: ', doc)

    return {'id':doc[0], 'question':doc[1], 'answer':marshal.loads(doc[2])}


