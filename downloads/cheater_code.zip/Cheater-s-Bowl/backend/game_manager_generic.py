import os
from datetime import datetime
import csv

import wikipedia
import wikipediaapi

import json
import requests
import random
  
from typing import Optional
import copy
from backend.utils import *
from backend.config import CONFIG
from backend.database import get_question_by_id, get_random_question, qanta_db, hotpotqa_db
if "IRRR" in CONFIG["suggestion_models"]:
    from backend.call_irrr import *
if "golden" in CONFIG["suggestion_models"]:
    from backend.call_golden import *
from superdebug import debug
TEST = False
SKIP_RECORD_ON_SKIP = True
debug(CONFIG=CONFIG)

wiki_wiki = wikipediaapi.Wikipedia('en')
wiki_html = wikipediaapi.Wikipedia(
        language='en',
        extract_format=wikipediaapi.ExtractFormat.WIKI
)

# Helper functions

# create html string, nested section dictionary
def parse_sections(sections, level=1):
    html = ""
    parsed_sections = []

    for s in sections:
        html += """<h{} id=\"{}\">{}</h{}>
        <p>{}</p>
        """.format(level,s.title,s.title,level,s.text)
#             print("%s: %s - %s" % ("*" * (level + 1), s.title, s.text[0:40]))
        inner_html, inner_parsed_sections = parse_sections(s.sections, level + 1)
        html += inner_html
        parsed_sections.append({'title':s.title, 'sections':inner_parsed_sections})
    return html, parsed_sections

def parse_html_string(html_text):
    return html_text, []


if not TEST and "IRRR" in CONFIG["suggestion_models"]:
    FLAGS = get_flags()
    irrr = IRRR(FLAGS)

## Game manager: # manages the game, records data
class GameManager:
    def __init__(self):
        '''
        different GameManager object for different users
        dataset:
        - qanta
        - qanta_2: first 2 sentences of qanta
        - nq: natural questions
        - hotpotqa

        multiple_answers: when answer is a list of valid answers, used for NQ
        randomize: whether to give random questions
        '''
        self.config = CONFIG

        # if CONFIG["hotpotqa_proportion"] > 0:
        #     self.hotpotqa_num_questions = len(hotpotqa_db._all_question_ids) # self.config['num_questions']
        #     self.hotpotqa_question_ids = hotpotqa_db._all_question_ids
        # if CONFIG["hotpotqa_proportion"] < 1:
        #     self.qanta_num_questions = len(qanta_db._all_question_ids) # self.config['num_questions']
        #     self.qanta_question_ids = qanta_db._all_question_ids
        
        self._num_questions = 99999999999
        self._randomize = self.config['randomize']
        # if self.config['hard_questions']:
        #     self._hard_question_ids = list(json.load(open(self.config['hard_questions_path'])).keys())
        # self._file_name = "backend/data/recorded_game_{}.jsonl".format(str(datetime.today().date()))

        self.state = {} # game state
        self.state['dataset'] = 'qanta'
        self.db = qanta_db

        # initialize game state
        self.reset()
        # get questions, packet scores
        if self.config['qanta_dataset'] == 'spring_novice':
            # self.state['packet_scores'] = [0] * len(self.config['packet_nums'])
            self.state['packet_scores'] = {}
            self.state['packets'] = self.config['packet_nums']
        self.golden_url = self.config["suggestion_models"]["golden"]["url"]
        



    def load(self, state):
        self.reset()
        for key in state:
            self.state[key] = state[key]

    # resets, then starts a new game
    def start_game(self, username: str, mode: str):
        debug("starting new game...")

        self.reset()
        # self._file_name = "backend/data/recorded_game_{}.jsonl".format(str(datetime.today().date()))

        self.state['username'] = username
        self.state['mode'] = mode
        self.state['dataset'] = 'qanta'

        # get questions, packet scores
        if self.state['dataset'] == 'qanta' and self.config['qanta_dataset'] == 'spring_novice':
            for packet_num in self.config['packet_nums']:
                self.qanta_question_ids = qanta_db.get_packet_questions(packet_num)
                self.state['packet_scores'][packet_num] = 0
            # self.state['packet_scores'] = [0] * len(self.config['packet_nums'])
            self.qanta_num_questions = len(self.qanta_question_ids)
        
        # else:
        #     # self.question_ids = self.config["question_ids"]
        #     if self.state['dataset'] == 'qanta':
        #         self.qanta_question_ids = qanta_db._all_question_ids
        #     elif self.state['dataset'] == 'hotpotqa':
        #         self.hotpotqa_question_ids = hotpotqa_db._all_question_ids
        
        # if mode == "sentence":
        #     self.question_ids = self.config["qids_1"]
        # elif mode == "incremental":
        #     self.question_ids = self.config["qids_2"]
        # elif mode == "static":
        #     self.question_ids = self.config["qids_3"]


        return self.advance_question()

    def save_play(self, state):
        # with open(self._file_name, mode='a+') as outfile:
        #     json.dump(self.state, outfile)
        #     outfile.write('\n')
        # print("saved state to {}".format(self._file_name))
        if state["dataset"] == "hotpotqa":
            self.db.insert_question_play(state)
        elif state["dataset"] == "qanta":
            self.db.insert_question_play(state)
        debug(f'saved state to {state["dataset"]} db')

    def reset(self):
        debug("resetting...")

        # state is organized per question, corresponds to rows
        self.state = {
            'username': None,
            'mode': None,
            'start_datetime': str(datetime.utcnow()),
            'question_ids': [],
            'packet_number': self.config['packet_nums'][0],
            'packets': self.config['packet_nums'],
            'question_number': 0, 
            'question_id': '', 
            'cur_question_text': '', 
            'question_data': {},
            'skipped': False,

            'queries': [], 
            # 'query_results_map': {}, # map of query to doc search results
            'cur_doc_selected': '',
            # 'keyword_searches': {}, # map of doc to searches
            'evidence': [], # list of highlighted spans
            'reasoning_path': [],
            'current_reasoning_path_map': {},
            'suggested_query': {},
            'suggested_answer': {},

            'tfidf_search_map': {
                'queries': [], 
                'query_results_map': {}, # map of query to doc search results
                'documents_selected': [],
                'keyword_searches': {}, # map of doc to searches
            },

            'buzz_word_index': -1,
            'buzz_sentence_number': -1,
            'player_answer': '', 
            'answer': '',
            'answer_correct': None, 
            'score': 0,
            'evidence_score': 0,
            'evidence_num': 0,
            'game_over': False,
            'override_decision': None, # if player challenges decision

            'actions': [],

            'packet_scores': {},
            'viewed_questions': {},
            # 'total_score': 0
        }
        return True

    def record_action(self, action_name: str, data=None):
        action = {'time': int(datetime.utcnow().timestamp()), 'name': action_name}
        if data:
            action['data'] = data
        debug(action=action)
        self.state['actions'].append(action)
        if action_name == "next_sentence":
            self.state['question_data']['sentence_index'] = data['sentence_index']
            # debug(data, self.state['question_data']['sentence_index'])
        return True

    def like_suggested_query(self, query, like):
        #  # record reasoning path info and whether user like it
        self.state['suggested_query'][query] = (self.state['suggested_query'][query][0], like, self.state['suggested_query'][query][2])
        # self.state['suggested_query'][query]: (input_id, like, suggestion_model)

        debug(updated_suggested_query = self.state['suggested_query'])

    def like_suggested_answer(self, answer, like):
        #  # record reasoning path info and whether user like it
        self.state['suggested_answer'][answer] = (self.state['suggested_answer'][answer][0], like, self.state['suggested_answer'][answer][2])
        
    # get next question, advance state
    def advance_question(self, override_decision=None, skip=False):
        debug("Advancing question")
        # save current play
        if override_decision != None: #
            self.state['override_decision'] = override_decision

        if self.state['question_number'] > 0: # record the current state
            keys = {'username','start_datetime','packet_number','question_number','question_id','skipped','evidence','reasoning_path','current_reasoning_path_map', 'suggested_query', 'suggested_answer', 'tfidf_search_map',
                    'buzz_sentence_number',
                    'player_answer',
                    'answer',
                    'answer_correct',
                    'score', # current total score
                    'question_score',
                    # 'evidence_score', # it is just 10 * evidence_num
                    'evidence_num'
                    'override_decision',
                    'actions',
                    'dataset'
                }
            play = {k:self.state[k] for k in keys if k in self.state}

            if skip:
                self.state['skipped'] = True
                debug('skipping record...')
            else:
                # save play, extract keys
                debug('saving play...')
                assert "actions" in play and len(play["actions"]) > 0
                self.save_play(play)
        cur_question_number = self.state['question_number'] + 1
        debug(cur_question_number = self.state['question_number'] + 1)
        # debug(question_ids = self.question_ids)

        # game over
        if cur_question_number > self._num_questions:
            debug('game finished')
            self.state['game_over'] = True
            return self.state

        # get next question
        if random.random() < self.config['hotpotqa_proportion']:
            self.state['dataset'] = 'hotpotqa'
            self.db = hotpotqa_db
        else:
            self.state['dataset'] = 'qanta'
            self.db = qanta_db
        self._num_questions = len(self.db._all_question_ids)
        debug(f"Question from {self.state['dataset']}")

        if self.config['qanta_dataset'] == 'qanta_hard':
            cur_question_id = random.choice(self._hard_question_ids)
            cur_question = get_question_by_id(cur_question_id, 'qanta')
        
        elif self.config['randomize']: # we are here
            cur_question = get_random_question(self.state['dataset'])
            if "viewed_questions" not in self.state:
                self.state["viewed_questions"] = {}
            # only get questions that have a page field, and not previously viewed, and not viewed by more than 4 users, and not too easy to answer
            while (not cur_question['answer']) or cur_question['id'] in self.state["viewed_questions"] or len(cur_question["viewed_users"]) >= self.config["max_viewed_user_num"] or cur_question["GPT3_difficulty"] == 1:
                cur_question = get_random_question(self.state['dataset'])
            cur_question_id = cur_question['id']
            viewed_users = cur_question['viewed_users']
        else:
            # everybody answer the same set of questions
            cur_question_id = self.question_ids[cur_question_number - 1]
            cur_question = get_question_by_id(cur_question_id, self.state['dataset'])
            viewed_users = cur_question['viewed_users']
        
        # if packet changed, update user data
        if self.config['qanta_dataset'] == 'spring_novice':
            if cur_question['packet_num'] != self.state['packet_number']:
                old_packet = self.state['packet_number']
                # self.state['packet_scores'].append(self.state['score'])
                # self.state['packet_scores'][old_packet] = self.state['score']
                self.state['packet_number'] = cur_question['packet_num']
                self.state['packet_finished'] = True
                # db.insert_user_game_data(self.state['username'], json.dumps(self.state))

        # update state
        self.state['question_number'] = cur_question_number
        self.state['question_id'] = cur_question_id
        self.state['cur_question_text'] = cur_question['question'] # only question text
        self.state['question_data'] = cur_question
        self.state["viewed_questions"][cur_question_id] = None # use dict as set (since set is not supported in json)
        self.state['viewed_users'] = viewed_users
        debug(ground_truth = self.state['question_data']['answer'], question_data=self.state['question_data'])

        # self.state['queries'] = []
        # self.state['query_results_map'] = {}
        self.state['cur_doc_selected'] = ''
        # self.state['keyword_searches'] = {}

        self.state['buzz_word_index'] = -1
        self.state['buzz_sentence_number'] = -1

        self.state['evidence'] = []
        self.state['evidence_num'] = 0
        self.state['reasoning_path'] = []
        self.state['current_reasoning_path_map'] = {}
        self.state['suggested_query'] = {}
        self.state['suggested_answer'] = {}
        self.state['tfidf_search_map'] = {
                'queries': [], 
                'query_results_map': {},
                'documents_selected': [],
                'keyword_searches': {},
            }

        self.state['override_decision'] = None
        self.state['actions'] = []
            

        # save state for loading (save to qanta db by default)
        qanta_db.insert_user_game_data(self.state['username'], json.dumps(self.state))

        return self.state


    def get_suggested_query(self, suggestion_model, task):
        # debug(self.state['question_data'])
        # get currently showed question text
        showed_question_text = self.state['cur_question_text']
        if 'tokenizations' in self.state['question_data']:
            end_pos = self.state['question_data']['tokenizations'][self.state['question_data']['sentence_index']][1]
            showed_question_text = showed_question_text[:end_pos]
            debug(showed_question_text=showed_question_text)
        if suggestion_model == "IRRR": # IRRR
            # try to retrieve cached suggestions
            cached_model_suggestion = None
            ### No need caching anymore!
            # if len(self.state['reasoning_path']) == 0:
            #     if CONFIG["dataset"] == "qanta":
            #         mode = CONFIG["qanta_mode"]
            #     elif CONFIG["dataset"] == "hotpotqa":
            #         mode = "sent"
            #     question_id = self.state["question_id"]
            #     sentence_index = self.state['question_data']['sentence_index']
            #     cached_model_suggestion = db.get_cached_model_suggestion(question_id, suggestion_model, mode, sentence_index)
            #     if cached_model_suggestion is not None:
            #         suggested_query, suggested_answer = cached_model_suggestion
            #         input_id = get_IRRR_hopn_input(showed_question_text, self.state['reasoning_path'], input_id_only = True)
            #         self.state['current_reasoning_path_map'][input_id] = (showed_question_text, len(self.state['reasoning_path'])) # as long as we have self.state['current_reasoning_path_map'][input_id] (number of used evidences) and latest self.state['reasoning_path'], we can recover the input that corresponds to input_id using get_IRRR_hopn_input
            if cached_model_suggestion is None: # predict now
                input_id, answer_predictions, answer_nbest_predictions, null_odds, predictions_titles, query_predictions, query_predictions_best, query_predictions_best_prob = irrr.predict([(showed_question_text, self.state['reasoning_path'])])
                self.state['current_reasoning_path_map'][input_id] = (showed_question_text, len(self.state['reasoning_path'])) # as long as we have self.state['current_reasoning_path_map'][input_id] (number of used evidences) and latest self.state['reasoning_path'], we can recover the input that corresponds to input_id using get_IRRR_hopn_input
                if len(query_predictions_best) > 0:
                    suggested_query = list(query_predictions_best.values())[0][0] # only one query suggestion given input # [input_id][0]
                else:
                    suggested_query = None
                    debug("query_predictions_best is empty")
                if len(answer_predictions) > 0:
                    suggested_answer = list(answer_predictions.values())[0] # only one query suggestion given input # [input_id][0]
                else:
                    suggested_answer = None
                    debug("suggested_answer is empty")
                # if len(self.state['reasoning_path']) == 0 and suggested_query is not None and suggested_answer is not None: ### No need caching anymore!
                #     model_suggestions = {question_id: {f"IRRR_v{CONFIG['IRRR_version']}_{mode}_{sentence_index}": [suggested_query, suggested_answer]}}
                #     debug(model_suggestions=model_suggestions)
                #     db.insert_model_suggestions(model_suggestions)
            if input_id in self.state['current_reasoning_path_map']: # check that user haven't advanced question
                if suggested_query is not None and suggested_query not in self.state['suggested_query']:
                    self.state['suggested_query'][suggested_query] = (input_id, False, suggestion_model) # record reasoning path info and whether user like it
                if suggested_answer is not None and suggested_answer not in self.state['suggested_answer']:
                    self.state['suggested_answer'][suggested_answer] = (input_id, False, suggestion_model) # record reasoning path info and whether user like it
        if suggestion_model == "golden": # GoldEn Retriever
            if task == "query":
                golden_input, input_ids = get_golden_hopn_input(showed_question_text, self.state['reasoning_path'])
                debug(input_ids=input_ids, golden_input=golden_input)
                input_id = input_ids[0]
                self.state['current_reasoning_path_map'][input_id] = (showed_question_text, len(self.state['reasoning_path'])) # as long as we have self.state['current_reasoning_path_map'][input_id] (number of used evidences) and latest self.state['reasoning_path'], we can recover the input that corresponds to input_id using get_golden_hopn_input
                if len(self.state['reasoning_path']) == 0:
                    # predictions = predictor_hop1.predict_batch(golden_input, top_n=golden_args.top_n)
                    response = requests.post(f'{self.golden_url}/predict_hop1_query', headers={'accept': 'application/json'}, json=golden_input)
                    
                else:
                    # predictions = predictor_hop2.predict_batch(golden_input, top_n=golden_args.top_n)
                    response = requests.post(f'{self.golden_url}/predict_hop2_query', headers={'accept': 'application/json'}, json=golden_input)
                # suggested_query = predictions[0][0][0]
                suggested_query = response.json() # only suggests one query given input
                if input_id in self.state['current_reasoning_path_map'] and suggested_query is not None and (suggested_query not in self.state['suggested_query']): # check that user haven't advanced question
                    self.state['suggested_query'][suggested_query] = (input_id, False, suggestion_model) # record reasoning path info and whether user like it
            elif task == "answer":
                pass
        return self.state

    def buzz(self, word_index):
        self.state['buzz_word_index'] = word_index
        return True

    def process_answer(self, player_answer, sentence_number, timeOut, time):
        # TODO: move save play here
        question_id = self.state['question_id']
        ground_truth = self.state['question_data']['answer']
        # if type(ground_truth) == list: # self.config['multiple_answers']:
        #     answer_matches = [answer_match(player_answer, cand_ans) for cand_ans in ground_truth]
        #     answer_correct = (True in answer_matches)
        # else:
        #     answer_correct = answer_match(player_answer, ground_truth)
        answer_correct = answer_matches(player_answer, ground_truth)
        self.state['answer_correct'] = answer_correct
        self.state['player_answer'] = player_answer
        self.state['answer'] = ground_truth
        if 'tokenizations' in self.state['question_data']:
            num_sentences = len(self.state['question_data']['tokenizations'])
        else:
            num_sentences = 1
        print(f'sentence number: {sentence_number}, num sentences: {num_sentences}')
        self.state['buzz_sentence_number'] = sentence_number
        points = 0
        if answer_correct:
            if timeOut:
                points += 50
            else:
                points += 100
            # points += 10
            # points += 10 * (num_sentences - sentence_number)
            points -= max(0, sentence_number - 1) * 10 
            points += self.state["evidence_num"] * 5
            answer_times, answer_scores = self.db.update_answer_time_score(question_id, time, points)
            self.db.update_viewed_users(question_id, self.state["username"])
            self.state['question_answer_times'] = answer_times
            self.state['question_answer_scores'] = answer_scores
        else:
            self.db.update_answer_time_score(question_id, time, 0) # record time even when users give wrong answers 
            self.db.update_viewed_users(question_id, self.state["username"])

        print(f'points awarded: {points}')
        self.state['score'] += points
        self.state['question_score'] = points

        if self.config['qanta_dataset'] == 'spring_novice':
            packet = self.state['packet_number']
            self.state['packet_scores'][packet] += points


        return self.state

    
    # def search_document_titles(self, query: str):
    #     print('searching documents...')
    #     results = wikipedia.search(query)
    #     self.state['queries'].append(query)
    #     self.state['query_results_map'][query] = results

    #     self.record_action('search_documents', query)

    #     return self.state


    def get_wiki_document_html(self, page_title: str):
        page = wiki_html.page(page_title)
        html, sections = parse_html_string(page.text)
        
        # html = page.summary + html
        page_dict = {"title": page.title, "html":html, "sections":sections}
        self.state['tfidf_search_map']['documents_selected'].append(page_title)
        self.state['cur_doc_selected'] = page_dict

        self.record_action('select_document', page.title)

        return self.state

    # def get_wiki_document_text(self, page_title: str):
    #     page = wiki_wiki.page(page_title)
        
    #     page_dict = {"title": page.title, "text": page.text}
    #     return page_dict

    def record_keyword_search(self, keywords, search_box: str):
        # cur_doc = self.state['cur_doc_selected']
        if search_box == 'full':
            self.state['keyword_searches'] = keywords
        elif search_box == 'passage':
            self.state['tfidf_search_map']['keyword_searches'] = keywords
        return True

    def record_evidence(self, splited_evidence: list, start_passage_id: str, end_passage_id: str):
        cur_doc = self.state['cur_doc_selected']
        debug(evidence=splited_evidence, start_passage_id=start_passage_id, end_passage_id=end_passage_id)
        start_i = 0
        for start_i, paragraph in enumerate(cur_doc):
            if paragraph['id'] == start_passage_id:
                break
        if start_passage_id == end_passage_id:
            assert len(splited_evidence) == 1
            evidence_paragraph = cur_doc[start_i]
            context = re.sub('<a href=".*?">', "", evidence_paragraph['text'])
            self.state['reasoning_path'].append({"title": evidence_paragraph['page'], "evidence": splited_evidence[0], "context": context, "docid":evidence_paragraph['id'], "query": self.state['tfidf_search_map']['queries'][-1]}) # NOTE: evidence will be used as paragraphs in the reasoning path, the query is the latest query that is used to retrieve this evidence
        else:
            debug(start_passage_id=start_passage_id, docids = [evidence_paragraph['id'] for evidence_paragraph in cur_doc])
            assert start_passage_id == cur_doc[start_i]['id'], f"start_passage_id: {start_passage_id}, start_i: {start_i}, cur_doc start id: {cur_doc[start_i]['id']}"
            for i, evidence in enumerate(splited_evidence):
                evidence_paragraph = cur_doc[start_i + i]
                context = re.sub('<a href=".*?">', "", evidence_paragraph['text'])
                self.state['reasoning_path'].append({"title": evidence_paragraph['page'], "evidence": evidence, "context": context, "docid":evidence_paragraph['id'], "query": self.state['tfidf_search_map']['queries'][-1]})
                # if i == len(splited_evidence) - 1:
                #     assert end_passage_id == evidence_paragraph['id']
        self.state['evidence'].append("\n".join(splited_evidence))
        self.state['evidence_score'] += 10
        self.state['evidence_num'] += 1
        self.record_action('record_evidence', splited_evidence)

        return self.state
    
    # old
    def search_documents(self, query: str):

        results = wikipedia.search(query)
        pages = []
        for title in results:
            page = wiki_html.page(title)
            html, sections = parse_html_string(page.text)
            
            # html = page.summary + html
            page_dict = {"title": page.title, "html":html, "sections":sections}
            pages.append(page_dict)

        return pages

if __name__ == '__main__':
    # game_manager = GameManager()
    match = answer_match('romania', "Romanian language")
    debug(match=match)
    match = answer_match('Treaty of Campo', "Treaty of Campo Formio")
    debug(match=match)
    match = answer_match('Treaty of France', "Treaty of Campo Formio")
    debug(match=match)
    match = answer_match('Treaty of France', "Treaty of Campo")
    debug(match=match)