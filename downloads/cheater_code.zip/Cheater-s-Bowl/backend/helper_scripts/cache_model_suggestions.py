import os, sys
from superdebug import debug
from tqdm import tqdm
from backend.database import Database, CONFIG
from backend.call_irrr import *
from backend.game_manager_generic import get_question_by_id, GameManager
# python -m backend.helper_scripts.cache_model_suggestions

dataset = CONFIG["dataset"]
query_suggestion_model = "IRRR_v1"
game_object = GameManager()
db = Database()

if "IRRR" in query_suggestion_model:
    FLAGS = get_flags()
    bert_config, hvd, run_config, tokenizer = prepare(FLAGS)

    # If running eval on the TPU, you will need to specify the number of
    # steps.
    model_fn = model_fn_builder(
        FLAGS, 
        bert_config=bert_config,
        init_checkpoint=FLAGS.init_checkpoint,
        learning_rate=FLAGS.learning_rate,
        num_train_steps=0,
        num_warmup_steps=0,
        use_one_hot_embeddings=False,
        hvd=None)
        
    estimator = tf.estimator.Estimator(
        model_fn=model_fn,
        config=run_config)

def get_IRRR_bulk_predictions(prepared_questions):
    input_ids, IRRR_input = get_IRRR_bulk_hop0_input(prepared_questions) # list
    eval_examples = read_qg_reader_examples(input_file=IRRR_input, is_training=False)
    answer_predictions, answer_nbest_predictions, null_odds, predictions_titles, query_predictions, query_predictions_best, query_predictions_best_prob = predict_query_gen_and_reader(FLAGS, estimator, eval_examples, tokenizer)
    return input_ids, query_predictions_best, answer_predictions

def predict_and_cache_batch_questions(prepared_questions, prepared_info):
    model_suggestions = {}
    if "IRRR" in query_suggestion_model:
        input_ids, query_predictions_best, answer_predictions = get_IRRR_bulk_predictions(prepared_questions)
        for prediction_i, input_id in enumerate(input_ids):
            suggested_query = query_predictions_best[input_id][0]
            suggested_answer = answer_predictions[input_id]
            question_id, model_question_info = prepared_info[prediction_i] # model_question_info: f"{query_suggestion_model}_{mode}_{sentence_index}"
            if question_id not in model_suggestions:
                model_suggestions[question_id] = {}
            model_suggestions[question_id][model_question_info] = [suggested_query, suggested_answer]
    debug(model_suggestions=model_suggestions)
    db.insert_model_suggestions(model_suggestions)
    
if __name__ == "__main__":
    start_question_num = 6594
    prepared_questions, prepared_info = [], []
    FLAGS = get_flags()
    FLAGS.predict_batch_size = 16
    debug()
    for question_num, question_id in enumerate(tqdm(db.get_all_question_ids()[start_question_num:])):
        question_data = get_question_by_id(question_id, dataset)
        if dataset == "qanta":
            for sentence_index, (start_id, end_id) in enumerate(question_data["tokenizations"]):
                question_text_level_i = question_data["question"][:end_id]
                question_text_sentence_i = question_data["question"][start_id:end_id]
                if sentence_index < 2:
                    prepared_questions.append(question_text_level_i)
                    prepared_info.append((question_id, f"{query_suggestion_model}_level_{sentence_index}"))
                prepared_questions.append(question_text_sentence_i)
                prepared_info.append((question_id, f"{query_suggestion_model}_sent_{sentence_index}"))
                if len(prepared_questions) >= FLAGS.predict_batch_size - 1:
                    predict_and_cache_batch_questions(prepared_questions, prepared_info)
                    prepared_questions, prepared_info = [], []
        elif dataset == "hotpotqa":
            question_text_sentence_i = question_data["question"]
            prepared_questions.append(question_text_sentence_i)
            prepared_info.append((question_id, f"{query_suggestion_model}_sent_{sentence_index}"))
            if len(prepared_questions) >= FLAGS.predict_batch_size - 1:
                predict_and_cache_batch_questions(prepared_questions, prepared_info)
                prepared_questions, prepared_info = [], []
        # debug(question_num=question_num, question_id = question_id, prompt=prompt, answer_prediction=answer_prediction, ground_truth = question_data["answer"],GPT3_difficulty=GPT3_difficulty)


