"""
cd  && python3 backend/helper_scripts/convert_collected_data.py
"""
import argparse
from collections import defaultdict
import json
import random
from superdebug import debug
from html import unescape
from tqdm import tqdm
from unidecode import unidecode
import os
import shutil
import copy
import sys
sys.path.append("cheaters_quizbowl")
from data_analysis.extract_sessions import Questions

question_id_map = {}

def convert_to_hop0_squad_input(input_file, output_file):
    input_data = json.load(open(input_file, "r"))
    output_data = []
    id_answer_correctness_map = defaultdict(list)

    for question_actions in tqdm(input_data):
        if len(question_actions) == 0:
            continue
        final_action = question_actions[-1]
        qid = final_action["question_id"]
        question = final_action["question"].strip()
        answer_correct = final_action["answer_correct"]
        for sent_index in range(0, 20):
            if final_action["question"] == questions.get_sents(qid, sent_index):
                id = str(qid) + f"-{sent_index}" # id is question_id with suffix to show level
                break
        id_answer_correctness_map[id].append(answer_correct)
        if question not in question_id_map:
            question_id_map[question] = id
            answers = [questions.get_answer(qid)]
            output_data.append({
                "id": id,
                "src": "qanta",
                "answers": answers,
                "question": question,
                "context": []
            })

    id_answer_correct_rate = {id: id_answer_correctness_map[id].count(True) / len(id_answer_correctness_map[id]) for id in id_answer_correctness_map}
    id_have_correct_human_answer_rate = 100 * sum([id_answer_correct_rate[id] > 0 for id in id_answer_correct_rate]) / len(id_answer_correct_rate)
    print("id_have_correct_human_answer_rate:", id_have_correct_human_answer_rate)
    print("unique_question_num:", len(id_answer_correctness_map))
    with open(output_file, "w") as f:
        f.write(json.dumps({
            "version": "1.0",
            "split": "dev",
            "data": output_data,
            "human_correct_rate": id_answer_correct_rate
        }))
    print("Hop0 squad input saved in", output_file)
    

def build_input_data_piece(id, question, gt_answer, prev_query = None, retrieved_context = None):
    question = question.strip()
    if prev_query is None and retrieved_context is None: # hop 0
        input_data_piece = {
            "title": "",
            "paragraphs": [
                {
                    "context": question,
                    "current_hop": 0,
                    "qas": [
                        {
                            "question": question,
                            "id": id,
                            "answers": [
                                {
                                    "answer_start": 0,
                                    "text": ""
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    else:
        input_data_piece = {
            "title": "",
            "paragraphs": [
                {
                    "context": ' [SEP] '.join([f"{x['title']} [et] {''.join(x['context'])}" for x in retrieved_context]),
                    "expand": True,
                    "query": "",
                    "query_short": "",
                    "prev_query": prev_query,  # "Elon Mask CEO", haven't been used for retrieval
                    "retrieved_context": copy.deepcopy(retrieved_context), # user evidences for searching prev_query
                    "current_hop": len(retrieved_context),
                    "qas": [
                        {
                            "question": question, # "Elon Mask is the CEO of which company?",
                            "answers": [
                                {
                                    "text": "",
                                    "answer_start": -1
                                }
                            ],
                            "is_impossible": False,
                            "is_last_non_gt": True,
                            "is_alternative": False,
                            "id": id
                        }
                    ]
                }
            ]
        }
    correspond_qa_data = {
            "id": id,
            "src": "qanta",
            "answers": [
                gt_answer
            ],
            "question": question,
            "context": []
        }
    return input_data_piece, correspond_qa_data


def score_evidence(evidence):
    score = 0
    if "visible-passage" in evidence["evidence-type"]:
        score = 1
    if "selected-passage" in evidence["evidence-type"]:
        score = 2
    if "visible-on-answering" in evidence["evidence-type"]:
        score = 3
    if "most-visible-passage" in evidence["evidence-type"]:
        score = 4
    if "player-recorded" in evidence["evidence-type"]:
        score = 6
    if "source-of" in evidence["evidence-type"]:
        score = 7
    if "-answer|" in evidence["evidence-type"] or evidence["evidence-type"].endswith("-answer"):
        score = 8
    return score

def add_to_output_hop_data(output_hop_data, correspond_hop_qa_data, input_data_piece, correspond_qa_data):
    hop = input_data_piece["paragraphs"][0]["current_hop"]
    id = input_data_piece["paragraphs"][0]["qas"][0]["id"]
    output_hop_data[hop][id] = input_data_piece
    correspond_hop_qa_data[hop].append(correspond_qa_data)

def convert_to_init_hopn_input(input_file, output_dir, end_to):
    input_data = json.load(open(input_file, "r"))
    output_hop_data = defaultdict(dict)
    correspond_hop_qa_data = defaultdict(list)
    for question_actions in tqdm(input_data):
        if len(question_actions) == 0 or (not question_actions[0]["answer_correct"]) or len(question_actions[0]["evidences"]) > 0 or (not question_actions[-1]["action"].startswith("answer:")): # filter out invalid questions
            continue

        # start a new QANTA question with multiple sentences
        question_id = question_actions[0]["question_id"]
        gt_answer = question_actions[0]["answer"]
        possible_answers = [gt_answer]
        id_suffix = "-rand" + str(random.randint(0, 99999999))

        retrieved_context = []; prev_query = ""
    
        final_action = question_actions[-1]

        question = final_action["question"].strip()
        this_id = question_id_map[question] + id_suffix

        sent_index = int(this_id.split("-")[1])
        question = questions.get_sents(question_id, sent_index).strip()
        
        if len(retrieved_context) == 0: # hop 0 without any retrieved_context 
            add_to_output_hop_data(output_hop_data, correspond_hop_qa_data, *build_input_data_piece(this_id, question, gt_answer))
        
        for action_i, action in enumerate(question_actions):
            if action["action"].startswith("query"):
                if action["action_data"]["retrieved_evidence"] == False:
                    continue
                next_action_evidences = question_actions[action_i + 1]["evidences"]
                if len(next_action_evidences) == len(action["evidences"]):
                    continue

                # there are evidences retrieved by this query
                prev_query = action["action"][6:]
                best_evidence = None
                best_evidence_score = -1
                for evidence in next_action_evidences[len(action["evidences"]):]:
                    if prev_query in [_[0] for _ in evidence["from_query"]]:
                        evidence_score = score_evidence(evidence)
                        if evidence_score > best_evidence_score:
                            best_evidence_score = evidence_score
                            best_evidence = evidence
                if best_evidence is None:
                    continue
                context = best_evidence["text"].split(". ")
                for i in range(len(context) - 1):
                    context[i] += ". "
                pid = best_evidence["pid"] if "pid" in best_evidence else ""
                if len(retrieved_context) == 0 or pid != retrieved_context[-1]["docid"]:
                    retrieved_context.append({
                            "title": best_evidence["title"] if "title" in best_evidence else "",
                            "context": context,
                            "docid": pid,
                            "fron_query": best_evidence["from_query"]
                    })
                    add_to_output_hop_data(output_hop_data, correspond_hop_qa_data, *build_input_data_piece(this_id, question, gt_answer, prev_query, retrieved_context))
            if action["action"].startswith("answer"):
                possible_answers.append(action["action"][7:])


    if os.path.exists(output_dir):
        remove_output_dir = input(f"Remove {output_dir}? y/n\n")
        if remove_output_dir == "y":
            shutil.rmtree(output_dir, ignore_errors=True)

    if end_to == "evidence":
        dump_init_hopn_input_end_to_evidence(output_hop_data, correspond_hop_qa_data, output_dir)
    elif end_to == "query":
        dump_init_hopn_input_end_to_query(output_hop_data, correspond_hop_qa_data, output_dir)
    
    

def dump_init_hopn_input_end_to_evidence(output_hop_data, correspond_hop_qa_data, output_dir):
    for hop in output_hop_data:
        if hop != 0:
            os.makedirs(os.path.join(output_dir, f"init_{hop}hop", f"hop{hop}"), exist_ok=True)
            init_hopn_input_path = os.path.join(output_dir, f"init_{hop}hop", f"hop{hop}", "input.json")
            correspond_hopn_qa_path = os.path.join(output_dir, f"init_{hop}hop", f"question_file.json")
            with open(init_hopn_input_path, "w") as f:
                f.write(json.dumps({"data": list(output_hop_data[hop].values())}, indent=4))
            with open(correspond_hopn_qa_path, "w") as f:
                f.write(json.dumps({"data": correspond_hop_qa_data[hop]}, indent=4))

    output_hop_data_count = {key: len(output_hop_data[key]) for key in output_hop_data}
    debug(output_hop_data_count=output_hop_data_count)

def dump_init_hopn_input_end_to_query(output_hop_data, correspond_hop_qa_data, output_dir):
    for hop in output_hop_data:
        if hop != max(output_hop_data.keys()):
            # build query_predictions_best and query_predictions
            query_predictions_best = {}; query_predictions = {}
            for this_id in output_hop_data[hop]:
                if this_id in output_hop_data[hop+1]:
                    if "retrieved_context" in output_hop_data[hop][this_id]["paragraphs"][0]:
                        doc_title = output_hop_data[hop][this_id]["paragraphs"][0]["retrieved_context"][-1]["title"]
                    else: # hop 0
                        doc_title = ""
                    query = output_hop_data[hop+1][this_id]["paragraphs"][0]["prev_query"]
                    query_predictions_best[this_id] = [
                        query,
                        [
                            doc_title
                        ]
                    ]
                    query_predictions[this_id] = [
                        query,
                        1,
                        doc_title
                    ]

            os.makedirs(os.path.join(output_dir, f"init_{hop}hop", f"hop{hop}"), exist_ok=True)
            os.makedirs(os.path.join(output_dir, f"init_{hop}hop", f"hop{hop+1}"), exist_ok=True)
            init_hopn_input_path = os.path.join(output_dir, f"init_{hop}hop", f"hop{hop}", "input.json")
            query_predictions_best_path = os.path.join(output_dir, f"init_{hop}hop", f"hop{hop}", "query_predictions_best.json")
            query_predictions_path = os.path.join(output_dir, f"init_{hop}hop", f"hop{hop}", "query_predictions.json")
            correspond_hopn_qa_path = os.path.join(output_dir, f"init_{hop}hop", f"question_file.json")
            with open(init_hopn_input_path, "w") as f:
                f.write(json.dumps({"data": list(output_hop_data[hop].values())}, indent=4))
            with open(query_predictions_best_path, "w") as f:
                f.write(json.dumps(query_predictions_best, indent=4))
            with open(query_predictions_path, "w") as f:
                f.write(json.dumps(query_predictions, indent=4))
            with open(correspond_hopn_qa_path, "w") as f:
                f.write(json.dumps({"data": correspond_hop_qa_data[hop]}, indent=4))
    output_hop_data_count = {key: len(output_hop_data[key]) for key in output_hop_data}
    debug(output_hop_data_count=output_hop_data_count)

    output_dir = output_dir.replace('backend/irrr_v2/', '')
    for hop in output_hop_data:
        if hop != max(output_hop_data.keys()):
            init_hopn_input_path = os.path.join(output_dir, f"init_{hop}hop", f"hop{hop}", "input.json")
            query_predictions_best_path = os.path.join(output_dir, f"init_{hop}hop", f"hop{hop}", "query_predictions_best.json")
            query_predictions_path = os.path.join(output_dir, f"init_{hop}hop", f"hop{hop}", "query_predictions.json")
            correspond_hopn_qa_path = os.path.join(output_dir, f"init_{hop}hop", f"question_file.json")
            script = f"cd backend/irrr_v2 && python -m scripts.e_to_e_helpers.merge_with_es {query_predictions_best_path} {query_predictions_path} {correspond_hopn_qa_path} {init_hopn_input_path} {os.path.join(output_dir, f'init_{hop}hop', f'hop{hop+1}', 'input_orig.json')} {os.path.join(output_dir, f'init_{hop}hop', f'hop{hop}', 'recall_metrics.txt')} {os.path.join(output_dir, f'init_{hop}hop', f'hop{hop}', 'retrieved_titles.txt')} --top_n=10 --index beerqa_wiki_doc_para --include_prev --prev_titles {os.path.join(output_dir, f'init_{hop}hop', f'hop{hop-1}', 'retrieved_titles.txt')}"
            debug(script)
            os.system(script)
            script = f"cd backend/irrr_v2 && python -m scripts.e_to_e_helpers.convert_to_irrr_input {correspond_hopn_qa_path} {os.path.join(output_dir, f'init_{hop}hop', f'hop{hop+1}', 'input_orig.json')} {os.path.join(output_dir, f'init_{hop}hop', f'hop{hop+1}', 'input.json')} --keep_all"
            debug(script)
            os.system(script)
    # end to query: 
    # generate os.path.join(output_dir, f"init_{hop}hop", f"hop{hop}", "input.json") ... starts from hop 0
        # output/prediction_one/hop0/query_predictions_best.json
            # doc title are from input.json, query can be found in the prev_query of next hop
        # output/prediction_one/hop0/query_predictions.json
            # use the same data as query_predictions_best.json
        # data/beerqa/beerqa_dev_v1.0_custom_wrong.json
        # output/prediction_one/hop0/input.json
    # call python -m scripts.e_to_e_helpers.merge_with_es output/prediction_one/hop0/query_predictions_best.json output/prediction_one/hop0/query_predictions.json data/beerqa/beerqa_dev_v1.0_custom_wrong.json output/prediction_one/hop0/input.json output/prediction_one/hop1/input_orig.json output/prediction_one/hop0/recall_metrics.txt output/prediction_one/hop0/retrieved_titles.json --top_n=10 --index beerqa_wiki_doc_para --include_prev --prev_titles output/prediction_one/hop-1/retrieved_titles.json
    # then we get hop1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Convert collected data to IRRR input format and more.')
    parser.add_argument('--input_file', type=str, default="backend/data/20220604/sessions-qanta.json")
    parser.add_argument('--goal', type=list, default=["hop0_squad", "init_hopn_input", ])
    parser.add_argument('--hop0_squad_file', type=str, default="backend/irrr_v2/data/qanta/squadified_qanta_test_from_collected.json")
    parser.add_argument('--init_hopn_input_dir', type=str, default="backend/irrr_v2/data/qanta/test_init_hop_collected")
    parser.add_argument('--end_to', type=str, default="evidence", choices = ["evidence", "query"], help = "For evidence, we will directly construct hop1, hop2, ... from human data. For query, we will construct the query for hop0, hop1, ... from human data (instead of calling run_irrr.py), and queries and evidences before it, and call merge_with_es.py to construct hop1, hop2, ...")
    args = parser.parse_args()
    args.dataset = args.input_file.split('/')[-1][:-5].split('-')[-1]
    args.init_hopn_input_dir += "_" + args.dataset + "_" + args.end_to

    if "hop0_squad" in args.goal:
        questions = Questions(args.dataset)
        convert_to_hop0_squad_input(args.input_file, args.hop0_squad_file)
    if "init_hopn_input" in args.goal:
        with open(args.hop0_squad_file, "r") as f:
            squad_data = json.load(f)["data"]
            for qa_data in squad_data:
                question_id_map[qa_data["question"]] = qa_data["id"]
        convert_to_init_hopn_input(args.input_file, args.init_hopn_input_dir, args.end_to) # will delete previously constructed content


