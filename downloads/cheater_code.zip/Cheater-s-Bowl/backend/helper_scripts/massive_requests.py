# python -m backend.helper_scripts.massive_requests      
import random

from tqdm import tqdm
from backend.config import CONFIG
import requests
from superdebug import debug
import json
import multiprocessing

PARAMS = [i for i in range(1,100)]
SINGLE_DEBUG = False
BACKEND_URL = 'http://localhost:4006'
IRRR_ONLY = False
RANDOM = True

def get_access_token(user_id):
    try:
        r = requests.post(f'{BACKEND_URL}/token/register?email={user_id}@{user_id}.com', data={"username": f"{user_id}@{user_id}.com", "password": f"{user_id}"})
        debug(f"Successfully registered for {user_id}@{user_id}.com {user_id}")
    except:
        pass
    r = requests.post(f'{BACKEND_URL}/token', data={"username": f"{user_id}@{user_id}.com", "password": f"{user_id}"})
    access_token = r.json()["access_token"]
    return access_token
def advance_question(headers):
    r = requests.post(f'{BACKEND_URL}/advance_question?skip=True', headers=headers)
    if r.status_code != 200:
        raise Exception(f"Error advancing question: {r.reason}")
    else:
        debug("advanced question")
def get_suggested_query(headers):
    r = requests.get(f'{BACKEND_URL}/get_suggested_query?suggestion_model=IRRR&task=query_and_answer', headers=headers)
    if r.status_code != 200:
        raise Exception(f"Error getting suggested query: {r.reason}")
    else:
        debug("Get suggested query")
    res = r.json()
    query = list(res['suggested_query'].keys())[0]
    return query
        
def search_query_get_title(headers, query):
    r = requests.post(f'{BACKEND_URL}/record_action?name=search_documents', headers=headers, data=json.dumps({"data":{"query": query, "origin": "IRRR", "passage_id": -1}}))
    if r.status_code != 200:
        raise Exception(f"Error recording actions: {r.reason}")
    else:
        debug("Actions recorded")
    r = requests.get(f'{CONFIG["search_engine"]["DPR"]}/search_passages?query={query}&n_docs=30')
    if r.status_code != 200:
        raise Exception(f"Error searching")
    else:
        passages = r.json()
        title_docid_map = {passage["page"]: "-".join(passage['id'].split("-")[:2]) for passage in passages}
        r = requests.post(f'{BACKEND_URL}/record_search_results?query={query}', headers=headers, data=json.dumps({"passages": passages, "title_docid_map": title_docid_map}))
        if r.status_code != 200:
            raise Exception(f"Error recording search results: {r.reason}")
        else:
            debug("Search results recorded")
        return random.choice(passages)["page"]

def get_document_passages_one_passage(headers, page_title):
    r = requests.get(f'{BACKEND_URL}/get_document_passages/{page_title}', headers=headers)
    document_passages = r.json()
    if r.status_code != 200:
        raise Exception(f"Error getting document passages: {r.reason}")
    else:
        debug("Get document passages")
    passage = random.choice(document_passages)
    debug(passage=passage)
    return passage

def get_headers(access_token):
    return {"Authorization": f"Bearer {access_token}", 'Content-Type': 'application/json'}

def record_evidence(headers, passage_id, text):
    r = requests.post(f'{BACKEND_URL}/record_evidence?start_passage_id={passage_id}&end_passage_id={passage_id}', headers=headers, data=json.dumps({"data": [text]}))
    if r.status_code != 200:
        raise Exception(f"Error recording evidence")
    else:
        debug("recorded evidence")

def answer(headers):
    r = requests.post(f'{BACKEND_URL}/answer?answer=none', headers=headers)
    if r.status_code != 200:
        raise Exception(f"Error answering question")
    else:
        debug("Question answered")

def actions_sequence(access_token):
    headers = get_headers(access_token)
    advance_question(headers)
    query = get_suggested_query(headers)
    if not IRRR_ONLY:
        page_title = search_query_get_title(headers, query)
        passage = get_document_passages_one_passage(headers, page_title)
        record_evidence(headers, passage["id"], passage["text"])
        answer(headers)
        if RANDOM:
            for _ in range(10):
                action = random.randint(0, 4)
                if action == 0:
                    page_title = search_query_get_title(headers, query)
                elif action == 1:
                    passage = get_document_passages_one_passage(headers, page_title)
                elif action == 2:
                    record_evidence(headers, passage["id"], passage["text"])
                elif action == 3:
                    answer(headers)


if SINGLE_DEBUG:
    access_token = get_access_token(1)
    debug(access_token=access_token)
    actions_sequence(access_token)
else:
    cores = multiprocessing.cpu_count()
    pool = multiprocessing.Pool(processes=cores)
    access_tokens = pool.map(get_access_token, PARAMS)
    debug(access_tokens=access_tokens)

    pbar = tqdm(total=len(PARAMS))
    def update(_):
        pbar.update(1)
    for access_token in access_tokens:
        pool.apply_async(actions_sequence, [access_token], error_callback=debug, callback=update)
    pool.close()
    pool.join()
    # access_tokens
        # ['eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxQDEuY29tIiwiZXhwIjoxNjUyMTQyMTUxfQ.1ccUYv9kIU0Lwa3-f9pgKgQobr1UEgd19n8z_IoqIGo', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyQDIuY29tIiwiZXhwIjoxNjUyMTQyMTUwfQ.OJT98Nwd85vMOYL9dOj6Loc06tMCcSWdpi7abvJVWHU', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIzQDMuY29tIiwiZXhwIjoxNjUyMTQyMTU0fQ.7A1SHeJOmXC_oaS0L6Je_liF6sD-E0p1qyNsJAXhPgA', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI0QDQuY29tIiwiZXhwIjoxNjUyMTQyMTU4fQ.6fHYplnzeZ8tnZvywEjm9NpT9DOQE5d_kOfozGUjszE', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI1QDUuY29tIiwiZXhwIjoxNjUyMTQyMTU1fQ.MXDT278CUwmtk9M5jnBWDoEV_fabVQNo_HkMpdMHR7o', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI2QDYuY29tIiwiZXhwIjoxNjUyMTQyMTQ5fQ.ouaMsOLi1igkCUWizVOk2MbiOy8GRBNas_0Hs-LgE_A', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI3QDcuY29tIiwiZXhwIjoxNjUyMTQyMTU4fQ.U41KRb1YfsxXEzLteVZ7VHm4vhMYwcdPxAUbe_y0R4M', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4QDguY29tIiwiZXhwIjoxNjUyMTQyMTYyfQ.YdNwe895dEygI55sDcS28p80HL4qEoRuzvG_oBC_mFA', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI5QDkuY29tIiwiZXhwIjoxNjUyMTQyMTUyfQ.IE0CZDy3Jr8tThSbKXTZ3nue1ONkCJGxGiKxQC3sEhA', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMEAxMC5jb20iLCJleHAiOjE2NTIxNDIxNTd9.CGez61LPBLIY86aFSIES26_Nj2QMIlg1lZNDR5FD4io', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMUAxMS5jb20iLCJleHAiOjE2NTIxNDIxNTJ9.LTjfI51nuqbwDJtCTya4nyr16ApvqKD5m6SPqdG92RY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMkAxMi5jb20iLCJleHAiOjE2NTIxNDIxNTN9.UbbUoTgrinsUB70I9oGmvCn9OY8WSgQPtK79x4B6YL8', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxM0AxMy5jb20iLCJleHAiOjE2NTIxNDIxNTB9.dauCaUOsVlrR0N-IJHPofSxy1MuwPhyOCoZ9Mg1lI78', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNEAxNC5jb20iLCJleHAiOjE2NTIxNDIxNTZ9._clXeeKQBGQNpjiL74sUpGbsKNc_MJgAbQ6srN5mn3E', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNUAxNS5jb20iLCJleHAiOjE2NTIxNDIxNTF9.AkzuURsL4cy8NiyLlFfYVtk9bhEM2cBAQxvTIm7dMJw', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNkAxNi5jb20iLCJleHAiOjE2NTIxNDIxNTV9.2gDZOpD-Q_h9sHp2qpUcelovwEIKRw3AShwFsjXkAE4', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxN0AxNy5jb20iLCJleHAiOjE2NTIxNDIxODF9.csLMybm6VO3gWPMHvT8YCWlW-y5fzFqJK0uPj8nWJV4', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxOEAxOC5jb20iLCJleHAiOjE2NTIxNDIxODB9.SgX-dYSNCyP7anJ64drgUZMhG4WVcS6bxGiFM-kakm8', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxOUAxOS5jb20iLCJleHAiOjE2NTIxNDIxNzl9.O9j26ro63APLjiRSe-RvdUenHg5WmghWoJ3sxCDq7Mg', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyMEAyMC5jb20iLCJleHAiOjE2NTIxNDIxODF9.qDAZL4Wj2_0SgYIN6bLoqSsvlrUTpFHYp3F197c-BLU', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyMUAyMS5jb20iLCJleHAiOjE2NTIxNDIxODJ9.bIpX7GarODPGPiwczBceOBRBERNdhYCl2PhXAJLTEAM', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyMkAyMi5jb20iLCJleHAiOjE2NTIxNDIxODN9.PNzhPqonENsJ5d7Rrqv5C5fOQvRjbMStzPzDm40zwqE', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyM0AyMy5jb20iLCJleHAiOjE2NTIxNDIxODV9.R_vaInQlJ8PwBK1iwXjccTrDP3ijKmYUNkh1-z1lVqc', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyNEAyNC5jb20iLCJleHAiOjE2NTIxNDIxODN9.Udbj1I_HTbPNF3D_Gx2bITSumBDOskRzVWDv8K7eDv8', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyNUAyNS5jb20iLCJleHAiOjE2NTIxNDIxODR9.HObIdv_I3H_KLkn7eTqIolyhy_xs4EDKMyt0tbPNpBY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyNkAyNi5jb20iLCJleHAiOjE2NTIxNDIxODV9.6v3shqkuq4glNXpD17UnKl3Ux1hSYbQ0AorrOFqa754', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyN0AyNy5jb20iLCJleHAiOjE2NTIxNDIxODV9.UvIMBESk-LQPVCh-_QW6NooQbWS4Ow-9LAc-yLlzfrE', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyOEAyOC5jb20iLCJleHAiOjE2NTIxNDIxODZ9.gbKxYvtqOne74hkJpM0ZnRDJg5FDRKNrbF0CwYBLdfI', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIyOUAyOS5jb20iLCJleHAiOjE2NTIxNDIxODZ9.UbX9hvTAcxVQlVchDcCcouGm1qiw4AooIfPcm1RjW9U']
