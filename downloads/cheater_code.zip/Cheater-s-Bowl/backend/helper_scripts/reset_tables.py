from backend.database import Database

db = Database()
db.reset_all()
