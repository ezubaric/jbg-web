# python -m backend.helper_scripts.test_GPT3_difficulty                      
import os, sys
import openai
from superdebug import debug
# sys.path.append("backend")
from backend.database import Database, CONFIG, get_question_by_id, get_random_question
from backend.GPT3QA.gpr_qa import *
import backend.utils as utils
from collections import defaultdict

# engine = 'davinci'
# openai.api_key = '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'
# openai.Engine.retrieve(engine)

# engine = "gpt-j-6b"
engine = "gpt-neo-20b"
openai.api_key = 'sk-i7yhSMqohmbEpbwXTfArrAHxg5bVyUmqnTIT4hdQ4bDj2QEW' # GooseAI
openai.api_base = "https://api.goose.ai/v1"

dataset = CONFIG["dataset"]
db = Database()

def answer_match(answer_prediction, ground_truth):
    if type(ground_truth) == list:
        answer_matches = [utils.answer_match(answer_prediction, cand_ans) for cand_ans in ground_truth]
        answer_correct = (True in answer_matches)
    else:
        answer_correct = utils.answer_match(answer_prediction, ground_truth)
    return answer_correct

def get_qanta_answer_prompt(question_text:str):
    splited_question_text = question_text.lower().split()
    prompt = "The entity name from Wikipedia is"
    priority = 0
    for i, word in enumerate(splited_question_text):
        if priority < 3 and (word == "this" or word == "these"):
            priority = 3
            reference = splited_question_text[i+1].split('"')[0].split("'")[0]
            prompt = f"The entity name of {word} {reference} from Wikipedia is"
            return prompt
        elif priority < 2 and (word == "he" or word == "she" or word == "they" or word == "it" or word == "his" or word == "her" or word == "their" or word == "its"):
            priority = 2
            prompt = f"\"{word.capitalize()}\" refers to"
        elif priority < 1 and (word == "a" or word == "an" or word == "the"):
            priority = 1
            reference = splited_question_text[i+1].split('"')[0].split("'")[0]
            prompt = f"The entity name of the {reference} from Wikipedia is"
    return prompt
    
def get_GPT3_answer(propmt):
    response = openai.Completion.create(
        engine=engine,
        prompt= propmt,
        temperature=0.0,
        max_tokens=10,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0,
        logprobs=1,
        stop=["\"", ".", "\n"]
    )
    return response["choices"][0]["text"]

if __name__ == "__main__":
    prompt_mode = "retrieve" # "0shot" # "retrieve"
    start_question_num = 60
    max_num_demo = 8

    GPT3_difficulty_dist = defaultdict(int)
    
    if dataset == "qanta":
        QA_data = "QANTA"
    elif dataset == "hotpotqa":
        QA_data = "HotpotQA"

    if prompt_mode == "retrieve":
        guesstrain = os.path.join("backend/GPT3QA/DiverseQA", QA_data + "_train.json")
        guesstest = os.path.join("backend/GPT3QA/DiverseQA", QA_data + "_test.json")
        tfidf_guesser = TfidfGuesser()
        tfidf_guesser.load(QA_data)	
        train, test = load_data(guesstrain, guesstest)
    
    for question_num, question_id in enumerate(db.get_all_question_ids()[start_question_num:]):
        question_data = get_question_by_id(question_id, dataset)
        if question_data["answer"] is None: continue
        GPT3_difficulty = -1; answer_prediction = None # -1 for unable to answer, 1 for the simplist case (should be filter out)
        question = question_data["question"]

        if prompt_mode == "retrieve": # retrieve similar questions & answers
            top_q, top_a = tfidf_guesser.guess(question = question, max_n_guesses = max_num_demo)
            top_q = [q.split(". ") for q in top_q if q != question]

        if dataset == "qanta":
            for i, (start_id, end_id) in enumerate(question_data["tokenizations"]):
                question_text_level_i = question[:end_id]
                if prompt_mode == "0shot":
                    answer_prompt = get_qanta_answer_prompt(question_text_level_i)
                    prompt = f"Question: {question_text_level_i}\nAnswer: {answer_prompt} \""
                    answer_prediction = get_GPT3_answer(prompt)
                elif prompt_mode == "retrieve":
                    for num_demo in range(max_num_demo, 0, -1):
                        try:
                            prompt = retrieve_prompt(question_text_level_i, top_q, top_a, num_demo=num_demo, num_sent = i + 1)
                            answer_prediction = get_GPT3_answer(prompt)
                            break
                        except Exception as e:
                            print(e)
                            pass
                    
                if answer_match(answer_prediction, question_data["answer"]):
                    GPT3_difficulty = i + 1 # how many sentences do GPT3 needs to answer this question
                    break

        elif dataset == "hotpotqa":
            question_text_level_i = question_data["question"]
            if prompt_mode == "0shot":
                answer_prompt = "Answer: \""
                prompt = f"Question: {question_text_level_i}\nAnswer: {answer_prompt} \""
            elif prompt_mode == "retrieve":
                prompt = retrieve_prompt(question_text_level_i, top_q, top_a, num_demo=8, num_sent = i + 1)
            answer_prediction = get_GPT3_answer(prompt)
            if answer_match(answer_prediction, question_data["answer"]):
                GPT3_difficulty = 1

        db.insert_question_GPT3_difficulty(question_id, GPT3_difficulty)
        # debug(question_num=question_num, question_id = question_id, prompt=prompt, answer_prediction=answer_prediction, ground_truth = question_data["answer"],GPT3_difficulty=GPT3_difficulty)
        GPT3_difficulty_dist[GPT3_difficulty] += 1
        if question_num % 20 == 0:
            debug(question_num=question_num, GPT3_difficulty_dist = GPT3_difficulty_dist)

# 0shot:
    # -1 num val: 25
    # 1 num val: 6
    # 2 num val: 4
    # 3 num val: 5
    # 5 num val: 3
    # 6 num val: 8
    # 7 num val: 3
    # 8 num val: 1

# retrieve:
    # -1 num val: 12
    # 1 num val: 1
    # 2 num val: 4
    # 3 num val: 2
    # 4 num val: 10
    # 5 num val: 16
    # 6 num val: 8
    # 7 num val: 1
    # 8 num val: 1
