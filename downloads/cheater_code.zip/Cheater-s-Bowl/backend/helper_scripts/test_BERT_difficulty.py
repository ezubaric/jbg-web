# conda activate allennlp && python -m backend.helper_scripts.test_BERT_difficulty                      
import os, sys
from superdebug import debug
import toml
from tqdm import tqdm
# sys.path.append("backend")
sys.path.append("backend/qb_bert/")
from allennlp.models.archival import load_archive
from qb.predictor import QbPredictor
from backend.database import Database, CONFIG, get_question_by_id, get_random_question
import backend.utils as utils
from collections import defaultdict
from backend.qb_bert.qb.main import cli_evaluate_difficulty


dataset = CONFIG["dataset"]
db = Database()
model_config_path = "backend/qb_bert/config/my_config/my_config.toml"


def answer_match(answer_prediction, ground_truth):
    if type(ground_truth) == list:
        answer_matches = [utils.answer_match(answer_prediction, cand_ans) for cand_ans in ground_truth]
        answer_correct = (True in answer_matches)
    else:
        answer_correct = utils.answer_match(answer_prediction, ground_truth)
    return answer_correct

if __name__ == "__main__":
    # ! need to change config.json, e.g. BERT_difficulty: null
    all_qanta_ids = db.get_all_question_ids()
    # setting to default difficulty
    for question_num, question_id in enumerate(tqdm(all_qanta_ids)):
        BERT_difficulty = 9999
        db.insert_question_BERT_difficulty(question_id, BERT_difficulty)

    with open(model_config_path) as f:
        conf = toml.load(f)
    serialization_dir = conf["serialization_dir"]
    archive = load_archive(os.path.join(serialization_dir, "model.tar.gz"), cuda_device=0)
    predictor = QbPredictor.from_archive(archive, predictor_name="qb.predictor.QbPredictor",)

    for partition in ["guesstrain", "guessdev", "guesstest"]: # in backend/qb_bert/config/my_config, part_guesstrain is used for training
        BERT_difficulties = {}
        for sentences_num in range(1, 10):
            accs = cli_evaluate_difficulty(predictor, sentences_num, partition)
            debug(accs=accs)
            if sentences_num == 1:
                total_question_num = len(accs)
                qanta_ids = accs.keys()
            partition = set()
            for qanta_id in accs:
                if accs[qanta_id]:
                    BERT_difficulties[qanta_id] = sentences_num
                else:
                    partition.add(qanta_id)
        difficult_question_num = defaultdict(int)
        for qanta_id in BERT_difficulties:
            difficult_question_num[BERT_difficulties[qanta_id]] += 1
        difficult_question_num[-1] = total_question_num - len(BERT_difficulties)
        debug("Difficulties calculated!", difficult_question_num=difficult_question_num)
        for question_num, question_id in enumerate(tqdm(qanta_ids)):
            BERT_difficulty = -1
            if question_id in BERT_difficulties:
                BERT_difficulty = BERT_difficulties[question_id]

            db.insert_question_BERT_difficulty(question_id, BERT_difficulty)

