# deprecated
from backend.database import Database
# from database import Database

db = Database()
db.reset_all()