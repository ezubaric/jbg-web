import sys
sys.path.append("backend/GPT3QA/")
import os
import openai
import json
from tqdm import tqdm
from evaluate import * 
import numpy as np
from tfidf_retriever import *
import html

from superdebug import debug
np.random.seed(2021)

# engine = 'davinci'
# openai.api_key = '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'
# openai.Engine.retrieve(engine)

# engine = "gpt-j-6b"
engine = "gpt-neo-20b"
openai.api_key = 'sk-i7yhSMqohmbEpbwXTfArrAHxg5bVyUmqnTIT4hdQ4bDj2QEW' # GooseAI
openai.api_base = "https://api.goose.ai/v1"

SAVE_DIR = 'backend/GPT3QA/retriever_caches'
MODEL_PATH = 'tfidf.pickle'
INDEX_PATH = 'index.pickle'
QN_PATH = 'questions.pickle'
ANS_PATH = 'answers.pickle'

def load_data(train_path, test_path):
	'''
	load train and test data
	'''
	with open(train_path, 'r') as f:
		train = json.load(f)

	with open(test_path, 'r') as f:
		test = json.load(f)
	
	return train, test
	
def select_demo_random(data, num_demo=4):
	'''
	Select k demo examples from the training data.
	'''
	# random sample
	return np.random.choice(data, num_demo)




def qa_prompt(train, num_demo=4):
	'''
	Construct the prompt for QA task.
	'''
	selected_demos = select_demo_random(train, num_demo)
	prompt = ''
	for i in range(num_demo):
		prompt += selected_demos[i]["question"] + '\n'
		answer = selected_demos[i]["answer"][0]
		prompt += "The answer is " + answer + "\n"
	return prompt

def filter_answer(answer):
	def filter_single_answer(answer):
		answer = html.unescape(answer)
		answer = answer.replace("{", "").replace("}", "")
		return answer
	if type(answer) == list:
		return [filter_single_answer(ans) for ans in answer]
	return filter_single_answer(answer)

def retrieve_prompt(question, top_q, top_a, num_demo=8, num_sent=-1):
	'''
	Select k demo examples from the training data.
	data: 
	QA_data: specifies the dataset.
	'''
	prompt = ''
	for i in range(num_demo):
		if num_sent == -1:
			top_q_i_part = ". ".join(top_q[i])
		else:
			top_q_i_part = ". ".join(top_q[i][:num_sent])
			if not top_q_i_part.endswith("."):
				top_q_i_part = top_q_i_part + "."
		prompt += top_q_i_part + '\n'
		answer = filter_answer(top_a[i])
		prompt += "The answer is " + answer + "\n"
	
	input_prompt = prompt + question + '\n'
	input_prompt += "The answer is"
	return input_prompt


def predict(question, top_q, top_a, num_demo=8, num_sent = -1):
	input_prompt = retrieve_prompt(question, top_q, top_a, num_demo=num_demo, num_sent=num_sent)
	aa = openai.Completion.create(
		engine=engine,
		prompt=input_prompt,
		temperature=0.0,
		max_tokens=6,
		top_p=1.0,
		frequency_penalty=0.0,
		presence_penalty=0.0,
		logprobs=1,
		stop=['\n']
	)
	ans = aa['choices'][0]['text']
	confidence = sum(aa['choices'][0]["logprobs"]["token_logprobs"])
	## some simple cleaning
	ans = ans.split()
	ans_lst = []
	for a in ans:
		ans_lst.append(a)
		if a[-1] == '.':
			break
	ans = ' '.join(ans)

	return ans, confidence



if __name__ == "__main__":
	QA_data = "QANTA"
	max_num_demo = 8
	num_sent = 1
	guesstrain = os.path.join("backend/GPT3QA/DiverseQA", QA_data + "_train.json")
	guesstest = os.path.join("backend/GPT3QA/DiverseQA", QA_data + "_test.json")
    
	tfidf_guesser = TfidfGuesser()
	tfidf_guesser.load(QA_data)	
	train, test = load_data(guesstrain, guesstest)
	# for qd in test:
	# 	question = qd["question"]
	# 	prompt = retrieve_prompt(question, QA_data, num_demo=4)
	# 	print (question)
	# 	print (prompt)
	# 	break
    
	predictions = []
	em = 0
	match = 0
	for qd in tqdm(test):
		pred = {}
		question = qd["question"]
		pred["question"] = question
		qd["answer"] = filter_answer(qd["answer"])
		gold_ans = qd["answer"]
		debug(gold_ans=gold_ans)
		pred["gold_answer"] = gold_ans

		# retrieve similar questions & answers
		top_q, top_a = tfidf_guesser.guess(question = question, max_n_guesses = max_num_demo)
		top_q = [q.split(". ") for q in top_q if q != question]

		# get partial question
		question = question.split(". ")
		if num_sent == -1:
			question_part = ". ".join(question)
		else:
			question_part = ". ".join(question[:num_sent])
			if not question_part.endswith("."):
				question_part = question_part + "."

		# try to use more demos
		for num_demo in range(max_num_demo, 0, -1):
			try:
				pred_ans, conf = predict(question_part, top_q, top_a, num_demo=num_demo, num_sent = num_sent) # num_sent = -1 for all sentences
				break
			except:
				pass
		pred["prediction"] = pred_ans
		pred["confidence"] = conf
		predictions.append(pred)

		em_, match_ = get_exact_match(pred_ans, gold_ans)
		em += em_
		match += match_

	print ("EM: ", em / len(test), "Match: ", match / len(test)) 
	# GPT-J num_demo=8: EM:  0.47 Match:  0.47
	# max_num_demo=16: EM:  0.44 Match:  0.44
	# gpt-neo-20b max_num_demo = 8 full sentences: EM:  0.66 Match:  0.66, me count: 0.69
	# gpt-neo-20b max_num_demo = 8 1 sentence: EM:  0.06 Match:  0.06
	with open(os.path.join("backend/GPT3QA/predictions", QA_data+"_test_PromptRetrieve_preds.json"), "w") as f:
		json.dump(predictions, f)





