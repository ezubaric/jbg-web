import warnings
warnings.filterwarnings("ignore", message=r"Passing", category=FutureWarning)
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
# import pretty_errors
from backend.database import Database, qanta_db
# from backend import qanta
from backend import security
from backend.security import get_current_user
from backend import data_server

# from backend.game_manager_utils import GameManager 
from backend.game_manager_generic import GameManager 

import wikipedia
import wikipediaapi

from typing import Optional
import copy
import requests
from datetime import datetime
from backend.config import CONFIG
if "IRRR" in CONFIG["suggestion_models"]:
    if CONFIG["IRRR_version"] == 1:
        from backend.irrr_v1_deprecated.search.search import single_doc_query, single_text_query
        from backend.irrr_v1_deprecated.utils.constant import BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME
    elif CONFIG["IRRR_version"] == 2:
        from backend.irrr_v2.search.search import single_doc_query, single_text_query
        from backend.irrr_v2.utils.constant import BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME
from superdebug import debug, mark

RECOGNIZED_USER_IDS = ["ethanfeldman23@gmail.com", "profknowledge247@gmail.com", "jackson4ham@gmail.com", "dthomson01@gmail.com"]
DRQA_RETRIEVER_URL = 'http://127.0.0.1:5006' # all the requests that will finally go to search_document_server will first be processed in this server
# if "DPR" in CONFIG["search_engine"]:
#     from backend.DPR.dense_retriever_cli import get_dpr_config, DenseRetrieverInterface
#     cfg = get_dpr_config()
#     dense_retreiver = DenseRetrieverInterface(cfg)

class InitRequest(BaseModel):
    username: str
    session_token: Optional[str] = ''
    mode: Optional[str] = ''
    # data: Optional[dict] = None

class Keywords(BaseModel):
    keywords: dict
    passage_keywords_map: dict

class Evidence(BaseModel):
    evidence: list

class Answer(BaseModel):
    answer: str
    sentence_index: int

class ActionRecord(BaseModel):
    data: dict

class EvidenceRecord(BaseModel):
    data: list
class SearchResults(BaseModel):
    passages: list
    title_docid_map: dict


app = FastAPI()

origins = [
    "http://localhost:8000",
    "http://localhost:3000",
    "http://localhost:2020",
    "http://localhost:3006",
    "http://localhost:4006",
    "http://localhost:5006",
    "http://localhost:5006",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_origin_regex=".*\.ngrok\.io",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# app.include_router(qanta.router, prefix="/api/qanta/v1")
app.include_router(security.router, prefix="/token")
# app.include_router(qanta.router)
app.include_router(data_server.router)


# cache for storing game sessions.
game_sessions = dict()


def get_game_object(current_user: str, username=""):
    debug(current_user = current_user)
    if current_user not in game_sessions:
        game_object = GameManager()
        if username: 
            game_object.state['username'] = username
        game_sessions[current_user] = game_object

        # saved state from disk
        state = qanta_db.get_user_state(current_user)
        if state:
            debug('loading state from disk...')
            game_object.load(state)
            # debug('question number', game_object.state['question_number'])
    else:
        debug('loading state from cache...')
    if CONFIG["num_questions"] and int(game_sessions[current_user].state['question_number']) < CONFIG["num_questions"]:
        game_sessions[current_user].state["game_over"] = False
    return game_sessions[current_user]
    
for user_id in RECOGNIZED_USER_IDS:
    get_game_object(user_id)

# def get_game_object(current_user: str):
#     state = db.get_user_state(current_user)
#     if state:
#         return state
    # if current_user not in game_sessions:
    #     game_sessions[current_user] = GameManager()
    # game_object = game_sessions[current_user]
    # print('current user: ', current_user)
    # return game_sessions[current_user]



def destroy_game_object(current_user: str):
    del game_sessions[current_user]


# endpoints

@app.get("/")
def read_root():
    return {"Hello": "哈哈"}

# get player info from database
@app.get("/get_player_info")
def get_player_info(username: str, current_user: str = Depends(get_current_user)): # commented async 

    print(f'cur user: {current_user}')
    game_manager:GameManager = get_game_object(current_user, username)
    # get state of the game
    return game_manager.state
    # if game_manager.state['packet_finished'] = False:


# start a new game
@app.post("/start_new_game")
def start_new_game(request: InitRequest, current_user: str = Depends(get_current_user)): # commented async 

    print(f'cur user: {current_user}, mode: {request.mode}')
    game_manager:GameManager = get_game_object(current_user)
    # check if game is new or existing
    if game_manager.state['question_number'] == 0:
        game_manager.start_game(request.username, request.mode)
    else: # starting new packet
        debug("Game exists")
        game_manager.state['packet_finished'] = False
        
    return game_manager.state

@app.post("/buzz")
def buzz(word_index: int, current_user: str = Depends(get_current_user)):
    game_manager:GameManager = get_game_object(current_user)
    return game_manager.buzz(word_index)

# answer
@app.post("/answer")
def answer(answer: str, sentence_index: int = -1, timeOut: bool = False, time:int = 0, current_user: str = Depends(get_current_user)):
    print('answer', answer)
    game_manager:GameManager = get_game_object(current_user)
    state = game_manager.process_answer(answer, sentence_index, timeOut, time)
    return state
    
@app.post("/advance_question")
def advance_question(player_decision = None, skip: bool = False, current_user: str = Depends(get_current_user)):
    print(f'player_decision: {player_decision}, skipped: {skip}')
    game_manager:GameManager = get_game_object(current_user)
    game_manager.state["queries"] = []
    return game_manager.advance_question(player_decision, skip)

# get question ids
@app.get("/get_question_ids")
def get_question_list(current_user: str = Depends(get_current_user)):
    game_manager:GameManager = get_game_object(current_user)
    return game_manager.question_ids

# get document
@app.get("/get_document_text")
def get_document_text(title: str, current_user: str = Depends(get_current_user)):
    game_manager:GameManager = get_game_object(current_user)
    return game_manager.get_wiki_document_text(title)

# get document
@app.get("/get_document_html")
def get_document_html(title: str, current_user: str = Depends(get_current_user)):
    print("get doc endpoint")
    game_manager:GameManager = get_game_object(current_user)
    return game_manager.get_wiki_document_html(title)

@app.post("/record_keyword_search")
def record_keyword_search(keywords: Keywords, current_user: str = Depends(get_current_user)):
    print(keywords)
    game_manager:GameManager = get_game_object(current_user)
    game_manager.record_keyword_search(keywords.keywords, 'full')
    game_manager.record_keyword_search(keywords.passage_keywords_map, 'passage')
    return game_manager.state

@app.post("/record_evidence")
def record_evidence(start_passage_id: str, end_passage_id: str, evidence: EvidenceRecord, current_user: str = Depends(get_current_user)):
    print(evidence)
    game_manager:GameManager = get_game_object(current_user)
    game_manager.record_evidence(evidence.data, start_passage_id, end_passage_id)
    return game_manager.state


@app.post("/record_action")
def record_action(name: str, action: ActionRecord, current_user: str = Depends(get_current_user)):
    game_manager:GameManager = get_game_object(current_user)
    return game_manager.record_action(name, action.data)

# get suggested query and answers
@app.get("/get_suggested_query")
def get_suggested_query(suggestion_model: str, task: str, current_user: str = Depends(get_current_user)):
    game_manager:GameManager = get_game_object(current_user)
    game_state = game_manager.get_suggested_query(suggestion_model, task)
    return game_state

# deprecated. search wikipedia. get titles
@app.get("/search_wiki_titles")
def search_wikipedia_titles(query: str, limit=None, current_user: str = Depends(get_current_user)):
    game_manager:GameManager = get_game_object(current_user)
    return game_manager.search_document_titles(query)

# search wikipedia. get clean html
@app.get("/search_wiki")
def search_wikipedia_html(query: str, limit=None, current_user: str = Depends(get_current_user)):
    game_manager:GameManager = get_game_object(current_user)
    pages = game_manager.search_documents(query)
    return {'error': False, 'pages': pages}

title_docid_map = {} # there might be multiple paragraphs from same page, we only kept one of them
# TF-IDF index
@app.get("/search_tfidf")
def search_tfidf(query: str, search_engine: str, limit:int=30, nprobe:int=200, direct_return:bool=False, current_user: str = Depends(get_current_user)):
    global title_docid_map # content of DPR is kept since ES is generally slower than DPR, so there will be no overlap
    error = False
    if search_engine == "TFIDF":
        r = requests.get(f"{DRQA_RETRIEVER_URL}/search_pages?query={query}&n_docs={limit}")
        search_results = r.json()
            # id look like 261203
        if r.status_code != requests.codes.ok:
            print("Error in search")
            error = True
    elif search_engine == "DPR": # deprecated, frontend will directly request to DPR server
        title_docid_map = {}
        r = requests.get(f'{CONFIG["search_engine"]["DPR"]}/search_passages?query={query}&n_docs={limit}&nprobe={nprobe}')
        res = r.json()
        # res = dense_retreiver.retrieve(query, n_docs=limit, nprobe=nprobe) # nprobe = 200 has a very good performance, almost the same as nprobe = 2500
        search_results = []
        for r in res:
            if r['page'] not in title_docid_map:
                r["engine"] = "DPR"
                r["page"] = r["page"].encode("latin1").decode("utf-8")
                search_results.append(r)
                docid = "-".join(r['id'].split("-")[:2]) # id might look like wiki-2844938-2, then wiki-2844938 is the docid, and -2 is for paragraph
                title_docid_map[r['page']] = docid
    elif search_engine == "ES":
        res = single_text_query(query, index=BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME, topn = limit)
        if direct_return:
            return res
        search_results = []
        for r in res:
            if r['title'] not in title_docid_map:
                search_results.append({'id':r['id'], 'page':r['title'], "engine": "ES"}) # , 'text':r['text']
                docid = "-".join(r['id'].split("-")[:2]) # id might look like wiki-2844938-2, then wiki-2844938 is the docid, and -2 is for paragraph
                title_docid_map[r['title']] = docid
        # debug(search_results=search_results, title_docid_map=title_docid_map)
    game_manager:GameManager = get_game_object(current_user)
    if not error:
        if len(game_manager.state['queries']) == 0 or query != game_manager.state['queries'][-1]:
            game_manager.state['queries'].append(query)
            game_manager.state['tfidf_search_map']['queries'].append(query)
        if query not in game_manager.state['tfidf_search_map']['query_results_map']:
            game_manager.state['tfidf_search_map']['query_results_map'][query] = []
        game_manager.state['tfidf_search_map']['query_results_map'][query].extend([(r['id'], r['page']) for r in search_results])
        return search_results
        
@app.post("/record_search_results")
def record_search_results(query: str, search_results: SearchResults, current_user: str = Depends(get_current_user)):
    game_manager:GameManager = get_game_object(current_user)
    global title_docid_map
    title_docid_map = search_results.title_docid_map
    if len(game_manager.state['queries']) == 0 or query != game_manager.state['queries'][-1]:
        game_manager.state['queries'].append(query)
        game_manager.state['tfidf_search_map']['queries'].append(query)
    game_manager.state['tfidf_search_map']['query_results_map'][query] = search_results.passages
    return True
    
@app.get("/get_document_passages/{page_title}")
def get_document_passages(page_title: str, current_user: str = Depends(get_current_user)):
    game_manager:GameManager = get_game_object(current_user)
    # error = False
    # if CONFIG["search_engine"] == "TFIDF":
    #     result = requests.get(f"{DRQA_RETRIEVER_URL}/get_document_passages/{page_title}")
    #     if result.status_code != requests.codes.ok:
    #         print("Error in getting document")
    #         error = True
    #     else:
    #         result = result.json()
    # elif CONFIG["search_engine"] == "ES":
    if page_title in title_docid_map:
        docid = title_docid_map[page_title]
        result = single_text_query(index=BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME, docid=docid, topn = 200)
    if page_title not in title_docid_map or len(result) == 0:
        result = single_text_query(index=BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME, title = page_title, topn = 200)
    result = [{'id': passage['id'], 'text': passage['text'], 'page': passage['title']} for passage in result]
    # if not error:
    game_manager.state['tfidf_search_map']['documents_selected'].append(page_title)
    # print("getting doc: ", r.json()['id'])
    game_manager.state['cur_doc_selected'] = result
    return result

# name, score, questions answered
@app.get("/get_leaderboard")
def get_leaderboard():
    top_players = []
    for user, game_manager in game_sessions.items():
        player_state = game_manager.state
        if player_state['username']:
            # packet_scores = player_state['packet_scores'].values()
            packet_scores = player_state['packet_scores']
            # filled_scores = [0]*4
            # for i,k in enumerate(sorted(packet_scores.keys())):
            #     filled_scores[i] = packet_scores[k]
            average_score = player_state['score']/player_state['question_number'] if player_state['question_number'] else 0
            top_players.append({
                'id': player_state['username'],
                'username': player_state['username'], 
                'score': player_state['score'],
                'num_questions': player_state['question_number'],
                'average_score': average_score,
                # 'score1': filled_scores[0],
                # 'score2': filled_scores[1],
                # 'score3': filled_scores[2],
                # 'score4': filled_scores[3],
            })
    top_players.sort(key=lambda x:x['score'], reverse=True)
    try:
        top_players[0]["username"] = "🥇 " + top_players[0]["username"]
        top_players[1]["username"] = "🥈 " + top_players[1]["username"]
        top_players[2]["username"] = "🥉 " + top_players[2]["username"]
    except:
        pass
    return top_players

@app.get("/get_players")
def get_players():
    top_players = {}
    for user, game_manager in game_sessions.items():
        top_players[user] = game_manager.state
    return top_players

@app.get("/get_top_scores")
def get_top_scores():
    top_players = {}
    for user, game_manager in game_sessions.items():
        top_players[user] = game_manager.state['score']
    return top_players


# times
@app.get("/get_schedule_info")
def get_schedule_info():
    res = qanta_db.get_playing_times() # NOTE: useless, I have changed it to all the time are valid
    print('playing times', res)
    now = datetime.now()
    for interval in res:
        print('interval', interval)
        # datetime.strptime(date_time_str, '%Y-%m-%d %H:%M:%S.%f')
        if now >= datetime.strptime(interval['start_datetime'], '%Y-%m-%d %H:%M:%S') and now <= datetime.strptime(interval['end_datetime'], '%Y-%m-%d %H:%M:%S'):
            print('valid playing time!')
            return {'is_valid_playing_time': True, 'valid_times': res, 'next_end_datetime': interval['end_datetime']}
    return {'is_valid_playing_time': False, 'valid_times': res}



@app.post("/like_suggested_query")
def like_suggested_query(query: str, like: bool, current_user: str = Depends(get_current_user)):
    game_manager:GameManager = get_game_object(current_user)
    game_manager.like_suggested_query(query, like)
    return True

@app.post("/like_suggested_answer")
def like_suggested_answer(answer: str, like: bool, current_user: str = Depends(get_current_user)):
    game_manager:GameManager = get_game_object(current_user)
    game_manager.like_suggested_answer(answer, like)
    return True

# search wikipedia. create html from sections
# @app.get("/search_wiki_sections")
# def search_wikipedia_sections(query: str, limit: int=8):
    
#     # results = wikipedia.search(query, results = limit)
#     results = wikipedia.search(query)
#     print(results)
#     pages = []
#     for title in results:
#         try:
#             page = wiki_wiki.page(title)
#             # page = wikipedia.page(title)

#             html, sections = parse_sections(page.sections)
            
#             html = page.summary + html
#             page_dict = {"title": page.title, "html":html, "sections":sections}
#             pages.append(page_dict)

#         except wikipedia.exceptions.DisambiguationError as e:
#             print(title, "DisambiguationError")
#             print(e.options)
#             continue
#         except wikipedia.exceptions.PageError:
#             print(title, "PageError")
#             continue
#     return {'error': False, 'pages': pages}