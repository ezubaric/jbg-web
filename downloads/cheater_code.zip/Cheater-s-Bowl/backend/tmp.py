input_data_piece = {
            "title": "",
            "paragraphs": [
                {
                    "context": "Elizabeth Ann Seton [et] Elizabeth Ann Seton Elizabeth Ann Bayley Seton, SC, (August 28, 1774 - January 4, 1821) was the first native-born citizen of the United States to be canonized by the Roman Catholic Church (September 14, 1975). She established the first Catholic girls' school in the nation in Emmitsburg, Maryland, where she also founded the first American congregation of religious sisters, the Sisters of Charity. Elizabeth Ann Bayley was born on August 28, 1774, the second child of a socially prominent couple, a surgeon, Dr. Richard Bayley and Catherine Charlton of New York City. The Bayley and Charlton families were among the",
                    "expand": True,
                    "query": "",
                    "query_short": "",
                    "prev_query": "the mature age",
                    "retrieved_context": [
                        {
                            "title": "Elizabeth Ann Seton",
                            "context": [
                                "Elizabeth Ann Seton Elizabeth Ann Bayley Seton, SC, (August 28, 1774 - January 4, 1821) was the first native-born citizen of the United States to be canonized by the Roman Catholic Church (September 14, 1975). ",
                                "She established the first Catholic girls' school in the nation in Emmitsburg, Maryland, where she also founded the first American congregation of religious sisters, the Sisters of Charity. ",
                                "Elizabeth Ann Bayley was born on August 28, 1774, the second child of a socially prominent couple, a surgeon, Dr. ",
                                "Richard Bayley and Catherine Charlton of New York City. ",
                                "The Bayley and Charlton families were among the"
                            ],
                            "docid": "2072171"
                        },
                        {
                            "title": "Camille Claudel",
                            "context": [
                                "Camille Claudel Camille Claudel (; 8 December 1864 19 October 1943) was a French sculptor"
                            ],
                            "docid": 894086
                        }
                    ],
                    "qas": [
                        {
                            "question": "A sculptor from this country depicted a younger woman grasping at an older man who is being carried off by an older woman in her sculpture The Mature Age.",
                            "answers": [
                                {
                                    "text": "",
                                    "answer_start": -1
                                }
                            ],
                            "is_impossible": False,
                            "is_last_non_gt": True,
                            "is_alternative": False,
                            "id": "11-0-rand38298422"
                        }
                    ],
                    "current_hop": 1
                }
            ]
        }
hop = len(input_data_piece["paragraphs"][0]["retrieved_context"])
print(hop)