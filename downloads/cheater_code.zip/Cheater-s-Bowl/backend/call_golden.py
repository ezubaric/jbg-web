import hashlib

def get_golden_hop0_input(question):
    sha1_value = hashlib.sha1(question.encode('utf-8')).hexdigest()
    examples = [(question, question)]
    qids = [sha1_value]
    return examples, qids
    # sha1_value, [
    #         {
    #             'title': '',
    #             'paragraphs': [{
    #                 'context': question,
    #                 'qas': [{
    #                     'question': question,
    #                     'id': sha1_value,
    #                     'answers': [{'answer_start': 0, 'text': ''}]
    #                 }]
    #             }]
    #         }
    #     ]
def get_golden_hopn_input(question, reasoning_path):
    # golden only support hop2 officially
    # in the original input.json of hop n, a reasoning path consists of n paragraphs, each data item has the first (n-1) paragraphs and prev_query in common, but have different n th paragraph (which is newly retreived using prev_query)
    # reference: get_examples in backend/golden_retriever/DrQA/scripts/reader/predict.py
    if len(reasoning_path) == 0:
        return get_golden_hop0_input(question)

    context = "".join([f" <t> {paragraph['title']} </t> {paragraph['context']}" for paragraph in reasoning_path])
    context = question + context # Were Scott Derrickson and Ed Wood of the same nationality? <t> Scott Derrickson </t> Scott Derrickson (born July 16, 1966) is an American director, ... <t> Sinister 2 </t> Sinister 2 is a 2015 American supernatural horror film ...
    sha1_value = hashlib.sha1((context).encode('utf-8')).hexdigest()
    examples = [(context, question)]
    qids = [sha1_value]
    return examples, qids
