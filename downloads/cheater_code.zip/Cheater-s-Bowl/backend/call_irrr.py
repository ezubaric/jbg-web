# originally generate_query.py
import hashlib
import re
# import sys
try:
    from backend.irrr_v2.model.run_irrr_predict import *
    from backend.irrr_v2.model.irrr_data_qg_reader import read_qg_reader_examples
    from backend.irrr_v2.model.irrr_data import *
    from backend.irrr_v2.model.irrr_model import *
except:
    from irrr_v2.model.run_irrr_predict import *
    from irrr_v2.model.irrr_data_qg_reader import read_qg_reader_examples
    from irrr_v2.model.irrr_data import *
    from irrr_v2.model.irrr_model import *
try:
    from backend.config import CONFIG
except:
    from database import CONFIG


def get_flags():
    from irrr_flags import FLAGS
    FLAGS.vocab_file = f"backend/irrr_v2/irrr_model/vocab.txt"
    FLAGS.bert_config_file = f"backend/irrr_v2/irrr_model/vocab.txt"
    FLAGS.vocab_file = f"backend/irrr_v2/irrr_model/vocab.txt" 
    FLAGS.bert_config_file = f"backend/irrr_v2/irrr_model/bert_config.json" 
    FLAGS.init_checkpoint = CONFIG["pretrained_model_path"]["IRRR"]
    FLAGS.do_train=False
    FLAGS.do_predict=True
    FLAGS.predict_batch_size=1 # originally 16
    FLAGS.ranking_candidates=1
    FLAGS.output_dir = f"backend/irrr_v2/output/tmp" 
    FLAGS.qg_reader_predict_file = None
    FLAGS.advantage = 3 
    FLAGS.use_fp16=False
    FLAGS.ranking_candidates=1
    FLAGS.verbose_logging=False
    FLAGS.do_lower_case=True
    FLAGS.debug=False
    FLAGS.model_scope="electra"
    FLAGS.gpu = CONFIG["suggestion_models"]["IRRR"]["gpu"]
    return FLAGS

if __name__ == "__main__": #  and False
    FLAGS = get_flags()
    irrr = IRRR(FLAGS)
    raise Exception

    input_id, answer_predictions, answer_nbest_predictions, null_odds, predictions_titles, query_predictions, query_predictions_best, query_predictions_best_prob = irrr.predict([("Elon Mask is the CEO of which company?", [])])
    input_id, answer_predictions, answer_nbest_predictions, null_odds, predictions_titles, query_predictions, query_predictions_best, query_predictions_best_prob = irrr.predict([("Elon Mask is the CEO of which company?", [])])
    input_id, answer_predictions, answer_nbest_predictions, null_odds, predictions_titles, query_predictions, query_predictions_best, query_predictions_best_prob = irrr.predict([("Elon Mask is the CEO of which company?", [])])
    debug(input_id=input_id, answer_predictions = answer_predictions, 
        answer_nbest_predictions = answer_nbest_predictions, 
        null_odds = null_odds, 
        predictions_titles = predictions_titles, 
        query_predictions = query_predictions, 
        query_predictions_best = query_predictions_best, 
        query_predictions_best_prob = query_predictions_best_prob)
    irrr.close()



# DEBUG: 7 vars: ['answer_predictions', 'answer_nbest_predictions', 'null_odds', 'predictions_titles', 'query_predictions', 'query_predictions_best', 'query_predictions_best_prob'], at backend/call_irrr_debug.py:163 <module>
# 0 / 2.  answer_predictions OrderedDict {.} with keys ['8ac5e7a61e9484b0be68a94f7f62ddb128464336']

# 1 / 3.  answer_nbest_predictions OrderedDict {.} with keys ['8ac5e7a61e9484b0be68a94f7f62ddb128464336']
#     8ac5e7a61e9484b0be68a94f7f62ddb128464336 list size: 40 [...]
#        item 0:  OrderedDict {...} with keys ['text', 'probability', 'start_logit', 'end_logit', 'ans', 'na', 'yes', 'no']

#           probability num val: 0.1008191900206406
#           start_logit num val: -11.878891468048096
#           end_logit num val: -13.039451599121094
#           ans num val: -0.49375948309898376
#           na num val: 8.719340324401855
#           yes num val: -5.214606285095215
#           no num val: -5.1278395652771
#        item 1:  OrderedDict {...} with keys ['text', 'probability', 'start_logit', 'end_logit', 'ans', 'na', 'yes', 'no']
#           text str len 52: Elon Mask is the CEO of which company?
#           probability num val: 0.07538265867335682
#           start_logit num val: -11.878891468048096
#           end_logit num val: -13.33020305633545
#           ans num val: -0.49375948309898376
#           na num val: 8.719340324401855
#           yes num val: -5.214606285095215
#           no num val: -5.1278395652771
#        38 extra items
# 2 / 4.  null_odds OrderedDict {.} with keys ['8ac5e7a61e9484b0be68a94f7f62ddb128464336']
#     8ac5e7a61e9484b0be68a94f7f62ddb128464336 num val: 21.672271341085434
# 3 / 5.  predictions_titles OrderedDict {.} with keys ['8ac5e7a61e9484b0be68a94f7f62ddb128464336']
#     8ac5e7a61e9484b0be68a94f7f62ddb128464336 list size: 0 []
# 4 / 6.  query_predictions dict {.} with keys ['8ac5e7a61e9484b0be68a94f7f62ddb128464336']
#     8ac5e7a61e9484b0be68a94f7f62ddb128464336 list size: 3 [...]
#        item 0:  str len 34: Elon Mask CEO company
#        item 1:  num val: -5.0255961418151855
#        item 2:  str len 0: 
# 5 / 7.  query_predictions_best dict {.} with keys ['8ac5e7a61e9484b0be68a94f7f62ddb128464336']
#     8ac5e7a61e9484b0be68a94f7f62ddb128464336 list size: 2 [..]
#        item 0:  str len 34: Elon Mask CEO company
#        item 1:  list size: 1 val: ['']
# 6 / 8.  query_predictions_best_prob dict {.} with keys ['8ac5e7a61e9484b0be68a94f7f62ddb128464336']
#     8ac5e7a61e9484b0be68a94f7f62ddb128464336 list size: 4 [...]
#        item 0:  str len 34: Elon Mask CEO company
#        item 1:  list size: 1 val: ['']
#        item 2:  num val: -5.0255961418151855
#        item 3:  numpy.float64 with val:  1.0
