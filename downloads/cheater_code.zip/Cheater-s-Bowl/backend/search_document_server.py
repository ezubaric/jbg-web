from typing import Optional

from fastapi import FastAPI, Depends

app = FastAPI()

import os
import sys

import argparse
import csv
import json
import numpy as np

import time
from . import drqa_retriever as retriever
import sqlite3
from superdebug import debug, mark

sys.path.append("DPR")

# from dense_retriever import parse_qa_csv_file, load_passages, validate, save_results
# from dpr.options import add_encoder_params, setup_args_gpu, print_args, set_encoder_params_from_state, \
#             add_tokenizer_params, add_cuda_params, add_training_params, add_reader_preprocessing_params


base_dir = "retrieval-based-baselines"

# args = Object()
# args.qa_file = "../../qanta_data_all_sent.jsonl"
# args.retrieval_type="tfidf"
# tfidf_path = os.path.join(base_dir, "/fs/clip-scratch/amao/indexes/tfidf/nq/subset.npz")
# tfidf_path = os.path.join(base_dir, '/fs/clip-scratch/amao/indexes/tfidf/nq/full.npz')
tfidf_path = os.path.join(base_dir, 'data/indexes/tfidf/nq/full.npz')

db_path = os.path.join(base_dir, 'wiki_passages.db')


print("loading index...")
start = time.time()
ranker = retriever.get_class('tfidf')(tfidf_path=tfidf_path)
print(f"finished loading index in {time.time() - start} s")


def get_document_single(psg_id: str):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()

    query_str = f'''select * from wiki_passages where id={psg_id}'''
    c.execute(query_str)

    doc = c.fetchone()

    return {'id':doc[0], 'text':doc[1], 'page':doc[2]}

def get_documents(psg_ids: list, unique=False):
    # get paragraphs in page
    conn = sqlite3.connect(db_path)
    c = conn.cursor()

    query_params = ' or id='.join([str(doc_id) for doc_id in psg_ids])
    query_str = f'''select * from wiki_passages where id={query_params}'''
    c.execute(query_str)

    docs = c.fetchall()

    # return a list of dicts
    res = []
    if unique:
        pages = set()
        for doc in docs:
            page = doc[2]
            if page not in pages:
                res.append({'id':doc[0], 'text':doc[1], 'page':doc[2]})
                pages.add(page)
    else:
        for doc in docs:
            res.append({'id':doc[0], 'text':doc[1], 'page':doc[2]})

    print(f'retrieved {len(res)} documents')
    return res

# def get_document_passages(page_title: str):
#     conn = sqlite3.connect(db_path)
#     c = conn.cursor()
#     query_str = f'''select * from wiki_passages where title=?'''
#     c.execute(query_str,(page_title,))
#     passages = c.fetchall()

#     return [{'id':doc[0], 'text':doc[1], 'page':doc[2]} for doc in passages]

@app.get("/")
def read_root():
    return {"Hello": "World"}


@app.get("/get_document_by_id/{doc_id}")
def get_document_by_id(doc_id: str):
    return get_document_single(doc_id)


@app.get("/search_passages")
def search_passages(query: str, n_docs:int=10):

    psg_ids, scores = ranker.closest_docs(query, n_docs)
    # print(psg_ids, scores)    
    return get_documents(psg_ids)

@app.get("/search_pages")
def search_pages(query: str, n_docs:int=20):
    psg_ids, scores = ranker.closest_docs(query, n_docs)
    print(psg_ids, scores)   
    # ['17475491', '17475494', '17475492', '11669684', '261203', '18166688', '17860448', '4972432', '20203940', '20203938', '16316993', '17656653', '90166', '17656650', '17427586', '10682475', '10682474', '261179', '17504455', '6199401'] 
    # [305.88237165 281.74556748 273.71417    268.72829353 261.29354359
        # 259.42630943 259.42630943 246.74897155 245.5190541  241.97088437
        # 240.46298004 233.0282301  233.0282301  233.0282301  228.98490564
        # 223.53973212 223.53973212 223.53973212 223.53973212 223.53973212] 
    psgs = get_documents(psg_ids, unique=True) # there might be multiple psg_ids from same page, but only return each page once (unique=True)
    # psgs contains the paragraphs in the pages that will be highlighted
    # list size: 14 
    # item 0:  dict with keys ['id', 'text', 'page']
    #    id num val: 90166
    #    text str len 678: the development of history of human society." To the CCP, Marxism–Leninism provides a "vision of the contradictions in capitalist society and of the inevitability of a future socialist and communist s ... 's formal commitment
    #    page str len 24: Communist Party of China
    # item 1:  dict with keys ['id', 'text', 'page']
    #    id num val: 261179
     Square to visitors in his home town of central Hunan Province to mark the 115th anni ... nts of the twentieth
    
    # 12 extra items
    return psgs

# get all passages (paragraphs) of a single document 
@app.get("/get_document_passages/{page_title}")
def get_document_passages(page_title: str):
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    query_str = f'''select * from wiki_passages where title=?'''
    c.execute(query_str,(page_title,))
    passages = c.fetchall()
    debug(passages)

    return [{'id':passage[0], 'text':passage[1], 'page':passage[2]} for passage in passages] 


