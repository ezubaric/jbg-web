import json
with open('frontend/src/config.json', 'r') as config_file:
   CONFIG = json.load(config_file)