#%%
import json
from collections import defaultdict
from superdebug import debug
qanta_mapped = json.load(open("backend/data/data/qanta/qanta.mapped.2018.04.18.json", "r"))
qanta = json.load(open("backend/data/data/qanta/qanta.train.2018.04.18.json", "r"))
questions_mapped = qanta_mapped["questions"]
questions = qanta["questions"]

#%%
answers_mapped = defaultdict(dict)
for q in questions_mapped:
    answers_mapped[q["fold"]][q["qanta_id"]] = q["answer"]
ids_mapped = {fold: set(answers_mapped[fold].keys()) for fold in answers_mapped}
debug(ids_mapped=ids_mapped)

#%%
answers = defaultdict(dict)
for q in questions:
    answers[q["fold"]][q["qanta_id"]] = q["answer"]
ids = {fold: set(answers[fold].keys()) for fold in answers}

ids_min_mapped = {fold: ids[fold] - ids_mapped[fold] for fold in ids if fold in ids_mapped}
debug(ids_min_mapped=ids_min_mapped)
mapped_min_ids = {fold: ids_mapped[fold] - ids[fold] for fold in ids_mapped if fold in ids}
debug(mapped_min_ids=mapped_min_ids)

# %% re-partition guesstrain, make a smaller guesstrain set
import random
for q in qanta_mapped["questions"]:
    if q["fold"] == "guesstrain":
        if random.random() < 0.5:
            q["fold"] = "part_guesstrain"
with open("backend/data/data/qanta/qanta.part_mapped.2018.04.18.json", "w") as f:
    json.dump(qanta_mapped, f)
