# #!/usr/bin/env bash
# export MODEL_CONFIG_FILE="$2"
# cd $1
# pwd
# python qb/main.py train $2

cd backend/qb_bert
conda activate allennlp && python -m qb.main train 'config/my_config/my_config.toml'
conda activate allennlp && python -m qb.main evaluate_difficulty 'config/my_config/my_config.toml'
