GENERATION_FOLDS = ["guessdev", "guesstest", "buzztrain", "buzzdev", "buzztest"]
REPORT_FOLDS = ["guessdev", "guesstest"]
