from typing import Dict, List, Any
import json
import time
import random
from contextlib import contextmanager
import html
from pydantic import Json

from sqlalchemy import (
    Column,
    Integer,
    String,
    Boolean,
    Float,
    # Binary,
    create_engine,
    MetaData,
    Table,
    Column,
    ForeignKey,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session, relationship
from sqlalchemy.orm.scoping import ScopedSession
from sqlalchemy.pool import SingletonThreadPool
from superdebug import debug
import json
from backend.config import CONFIG
from tqdm import tqdm
from backend import data_server

try:
    from backend.log import get_logger
except:
    from log import get_logger
PLAYS_TABLE_NAME = 'plays_dev'
# PLAYS_TABLE_NAME = 'plays_prod'

log = get_logger(__name__)

Base = declarative_base()  # pylint: disable=invalid-name



class Database:
    def __init__(self, dataset: str):
        self.dataset = dataset
        global CONFIG
        if "qanta" in self.dataset:
            self._engine = create_engine(
                # Separate name to avoid confusing it with the unmodified qanta db
                "sqlite:///backend/data/qanta.2018.04.18.sqlite3",connect_args={'timeout': 15, "check_same_thread": False}, poolclass=SingletonThreadPool
            )  # pylint: disable=invalid-name
            # e = create_engine(
            #     "sqlite:///file:path/to/database?"
            #     "check_same_thread=false&timeout=10&mode=ro&nolock=1&uri=true"
            # )
        elif "hotpotqa" in self.dataset:
            self._engine = create_engine(
                # Separate name to avoid confusing it with the unmodified qanta db
                "sqlite:///../golden-retriever/hotpotqa.db", connect_args={'timeout': 15, "check_same_thread": False}, poolclass=SingletonThreadPool
            )
        Base.metadata.bind = self._engine

        # gets ids, lets us get random question
        if len(CONFIG["question_ids"]) > 0:
            self._all_question_ids = CONFIG["question_ids"]
        else:
            with self._session_scope as session:
                if "qanta" in self.dataset:
                    if not CONFIG["BERT_difficulty"]:
                        self._all_question_ids = [r[0] for r in session.query(Question.qanta_id).all()]
                    else: # only use the questions with specified difficulty level
                        self._all_question_ids = [r[0] for r in session.query(Question.qanta_id).filter(Question.BERT_difficulty == CONFIG["BERT_difficulty"]).all()]
                elif "hotpotqa" in self.dataset:
                    self._all_question_ids = [r[0] for r in session.query(HotpotQA._id).all()]

            if CONFIG["num_questions"] and CONFIG["num_questions"] > 0:
                self._all_question_ids = self._all_question_ids[:CONFIG["num_questions"]]

        debug(num_qanta_questions = len(self._all_question_ids))

        meta = MetaData()
        self.plays = Table(
            PLAYS_TABLE_NAME, meta, 
            Column('username', String, primary_key = True), 
            Column('question_id', String, primary_key = True),
            Column('start_datetime', String, primary_key = True), 
            Column('data', String),
        )
        self.playing_times = Table(
            'playing_times', meta, 
            Column('start_datetime', String), 
            Column('end_datetime', String),
        )

        # spring novice tournament
        # self.spring_novice_data = Table(
        #     'spring_novice_data', meta, 
        #     Column('id', Integer, primary_key = True), 
        #     Column('question', String),
        #     Column('answer', String), 
        #     Column('sentence_tokenizations', String),
        #     Column('packet_num', Integer),
        #     Column('question_num', Integer),
        #     Column('other_data', String),
        # )

        # with self._session_scope as session:
        #     self._spring_novice_ids = [
        #         r[0] for r in session.query(self.spring_novice_data.c.id).all()
        #     ]
    
    def get_playing_times(self):
        s = self.playing_times.select()
        conn = self._engine.connect()
        res = conn.execute(s)
        return [time for time in res]

    def create_all(self):
        Base.metadata.create_all(self._engine, checkfirst=True)

    def drop_all(self):
        Base.metadata.drop_all(self._engine)

    def reset_all(self):
        self.drop_all()
        self.create_all()

    @property
    @contextmanager
    def _session_scope(self) -> ScopedSession:
        session = scoped_session(sessionmaker(bind=self._engine))
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    ### questions ###
    def get_all_question_ids(self):
        return self._all_question_ids

    def get_random_question(self):
        with self._session_scope as session:
            qanta_id = random.choice(self._all_question_ids)
            question = session.query(Question).filter_by(qanta_id=qanta_id).first()
            return question.to_dict()

    def get_question_by_id(self, qanta_id: int):
        with self._session_scope as session:
            question = session.query(Question).filter_by(qanta_id=qanta_id).first()
            return question.to_dict()

    def get_question_by_id_custom(self, q_id: int):
        s = self.spring_novice_data.select().where(self.spring_novice_data.c.id==q_id)
        conn = self._engine.connect()
        result = conn.execute(s)
        row = list(result)[0]
        return row

    def get_table_ids(self):
        s = self.spring_novice_data.select()
        conn = self._engine.connect()
        result = conn.execute(s)
        return [res[0] for res in result]
    
    def get_packet_questions(self, packet):
        s = self.spring_novice_data.select().where(self.spring_novice_data.c.packet_num == packet)
        conn = self._engine.connect()
        result = conn.execute(s)
        result = [res[0] for res in result]
        return result
    def get_cached_model_suggestion(self, question_id, suggestion_model, mode, sentence_index):
        with self._session_scope as session:
            if "qanta" in self.dataset:
                res = session.query(Question).filter(Question.qanta_id == question_id).first()
            elif "hotpotqa" in self.dataset:
                res = session.query(HotpotQA).filter(HotpotQA._id == question_id).first()
            if (not res.model_suggestions) or res.model_suggestions == "":
                debug("no model suggestions available")
                return None
            else:
                cached_model_suggestions = json.loads(res.model_suggestions)
                debug(cached_model_suggestions=cached_model_suggestions)
                if suggestion_model == "IRRR":
                    suggestion_model = f"IRRR_v{CONFIG['IRRR_version']}"
                if f"{suggestion_model}_{mode}_{sentence_index}" in cached_model_suggestions:
                    return cached_model_suggestions[f"{suggestion_model}_{mode}_{sentence_index}"]
                else:
                    return None
                
            

    def update_answer_time_score(self, question_id, time, points):
        print(question_id, time, points)
        with self._session_scope as session:
            if "qanta" in self.dataset:
                res = session.query(Question).filter(Question.qanta_id == question_id).first()
            elif "hotpotqa" in self.dataset:
                res = session.query(HotpotQA).filter(HotpotQA._id == question_id).first()
            if not res.time:
                answer_times = []
            else:
                answer_times = json.loads(res.time)
            if not res.points:
                answer_scores = []
            else:
                answer_scores = json.loads(res.points)
            if time is not None:
                if "qanta" in self.dataset:
                    session.query(Question).filter(Question.qanta_id == int(question_id)).update({Question.time: json.dumps(answer_times + [time])})
                elif "hotpotqa" in self.dataset:
                    session.query(HotpotQA).filter(HotpotQA._id == question_id).update({HotpotQA.time: json.dumps(answer_times + [time])})
            if points is not None:
                if "qanta" in self.dataset:
                    session.query(Question).filter(Question.qanta_id == int(question_id)).update({Question.points: json.dumps(answer_scores + [points])})
                elif "hotpotqa" in self.dataset:
                    session.query(HotpotQA).filter(HotpotQA._id == question_id).update({HotpotQA.points: json.dumps(answer_scores + [points])})
            return answer_times, answer_scores

    def update_viewed_users(self, question_id, username):
        with self._session_scope as session:
            if "qanta" in self.dataset:
                res = session.query(Question).filter(Question.qanta_id == question_id).first()
            elif "hotpotqa" in self.dataset:
                res = session.query(HotpotQA).filter(HotpotQA._id == question_id).first()
            if not res.viewed_users:
                viewed_users = []
            else:
                viewed_users = json.loads(res.viewed_users)
            viewed_users.append(username)
            if "qanta" in self.dataset:
                session.query(Question).filter(Question.qanta_id == int(question_id)).update({Question.viewed_users: json.dumps(viewed_users)})
            elif "hotpotqa" in self.dataset:
                session.query(HotpotQA).filter(HotpotQA._id == question_id).update({HotpotQA.viewed_users: json.dumps(viewed_users)})
    
    def insert_question_GPT3_difficulty(self, question_id, GPT3_difficulty):
        with self._session_scope as session:
            if "qanta" in self.dataset:
                session.query(Question).filter(Question.qanta_id == int(question_id)).update({Question.GPT3_difficulty: GPT3_difficulty})
            elif "hotpotqa" in self.dataset:
                session.query(HotpotQA).filter(HotpotQA._id == question_id).update({HotpotQA.GPT3_difficulty: GPT3_difficulty})

    def insert_question_BERT_difficulty(self, question_id, BERT_difficulty):
        with self._session_scope as session:
            if "qanta" in self.dataset:
                session.query(Question).filter(Question.qanta_id == int(question_id)).update({Question.BERT_difficulty: BERT_difficulty})
            elif "hotpotqa" in self.dataset:
                session.query(HotpotQA).filter(HotpotQA._id == question_id).update({HotpotQA.BERT_difficulty: BERT_difficulty})

    # def get_question_GPT3_difficulty(self, question_id):
    #     with self._session_scope as session:
    #         if "qanta" in self.dataset:
    #             res = session.query(Question).filter(Question.qanta_id == int(question_id)).first()
    #         elif "hotpotqa" in self.dataset:
    #             res = session.query(HotpotQA).filter(HotpotQA._id == question_id).first()
    #         return res.GPT3_difficulty


    def insert_model_suggestions(self, model_suggestions):
        def merge_dict(main_dict, new_dict):
            for key, value in new_dict.items():
                if isinstance(value, dict):
                    if key not in main_dict:
                        main_dict[key] = {}
                    merge_dict(main_dict[key], value)
                else:
                    main_dict[key] = value
            return main_dict
        with self._session_scope as session:
            for question_id, model_suggestion in model_suggestions.items(): # model_suggestion is a dict
                if "qanta" in self.dataset:
                    res = session.query(Question).filter(Question.qanta_id == question_id).first()
                elif "hotpotqa" in self.dataset:
                    res = session.query(HotpotQA).filter(HotpotQA._id == question_id).first()
                if not res.model_suggestions:
                    prev_model_suggestions = {}
                else:
                    prev_model_suggestions = json.loads(res.model_suggestions)
                new_model_suggestions = json.dumps(merge_dict(prev_model_suggestions, model_suggestion))
                if "qanta" in self.dataset:
                    session.query(Question).filter(Question.qanta_id == int(question_id)).update({Question.model_suggestions: new_model_suggestions})
                elif "hotpotqa" in self.dataset:
                    session.query(HotpotQA).filter(HotpotQA._id == question_id).update({HotpotQA.model_suggestions: new_model_suggestions})

    def insert_question_play(self, question_play: dict): # TODO: change to sqlalchemy

        try:
            serialized = json.dumps(question_play)
            insert_params = {
                'username': question_play['username'], 
                'question_id': question_play['question_id'], 
                'start_datetime': question_play['start_datetime'],
                'data': serialized
            }

            # ins = self.plays.insert()
            ins = self.plays.insert().values(**insert_params)
            conn = self._engine.connect()
            result = conn.execute(ins)
        
        except Exception as e:
            print(f'error while writing question play: {e}')
            
    def extract_plays(self):
        play_logs = []
        with self._session_scope as session:
            res = session.query(Plays).all()
            for row in res:
                play_logs.append(json.loads(row.data))
        return play_logs
    # def write_questions(self, questions: Dict[str, Any]):
    #     start = time.time()

    #     with self._session_scope as session:
    #         question_list = []
    #         for question in questions:
    #             question["tokenizations"] = str(question["tokenizations"])
    #             question["tokens"] = json.dumps(question["tokens"])
    #             question_list.append(question)
    #         session.bulk_insert_mappings(Question, question_list)
    #     log.info("Took %s time to write questions", time.time() - start)

    def write_answer_data(self, answer_data):
        print(answer_data)
        # print(answer_data['session_id'])
        with self._session_scope as session:
            session.bulk_insert_mappings(
                Record, [answer_data]
            )
            return True
 
    ### user ###
    def insert_user_game_data(self, user_id, game_data):
        with self._session_scope as session:
            session.query(User).filter(User.user_id == user_id).update({User.game_data: game_data}, synchronize_session = False)

    def get_all_users(self):
        with self._session_scope as session:
            return session.query(User.user_id).all()
            
    def get_user_state(self, user_id):
        with self._session_scope as session:
            res = session.query(User).filter(User.user_id == user_id).first()
            session.commit()
            data = res.game_data
            if not data: return {}
            # data = list(res).game_data
            return json.loads(data)

    ### authentication ###

    def get_password(self, user_id):
        with self._session_scope as session:
            results = session.query(User).filter(User.user_id == user_id).first()
            if results:
                return results.password
            return None

    # registration
    def insert_user_email_password(self, username, password, email):
        with self._session_scope as session:
            if not session.query(User).filter(User.user_id == username).first():
                session.bulk_insert_mappings(
                    User, [{"user_id": username, "email": username, "password": password}]
                )
                return True
            return False

    # easy registration
    def insert_user_password(self, user_id, password):
        with self._session_scope as session:
            if not session.query(User).filter(User.user_id == user_id).first():
                session.bulk_insert_mappings(
                    User, [{"user_id": user_id, "password": password}]
                )
                return True
            return False

    def insert_session(self, user_id, session_id):
        with self._session_scope as session:
            # if not session.query(User).filter(User.user_id == user_id).first():
            session.bulk_insert_mappings(
                Session, [{"user_id": user_id, "session_id": session_id}]
            )
            return True

    def reset_users(self):
        with self._session_scope as session:
            session.query(User).filter(User.password != "").delete()
    
    # clear current poluted user data
    def clear_all_data(self):
        user_input = input("Delete all data? input any content to continue\n")
        if user_input:
            with self._session_scope as session:

                if "hotpotqa" in self.dataset:
                    session.query(HotpotQA).update({HotpotQA.points: "[]", HotpotQA.time: "[]", HotpotQA.viewed_users: "[]"})
                elif "qanta" in self.dataset:
                    session.query(Question).update({Question.points: "[]", Question.time: "[]", Question.viewed_users: "[]"})
                session.query(User).delete()
                session.query(Session).delete()
            delete = self.plays.delete()
            conn = self._engine.connect()
            result = conn.execute(delete)
            print("All user data are deleted")
    def clear_tmp_data(self):
        user_input = input("Delete tmp data (with username x@x.com)? input any content to continue\n")
        if user_input:
            tmp_usernames = {str(i) for i in range(500)}
            tmp_usernames.update({chr(chr_id) for chr_id in range(65, 91)})
            tmp_usernames.update({chr(chr_id) for chr_id in range(97, 123)})
            tmp_user_ids = {f"{_}@{_}.com" for _ in tmp_usernames}
            with self._session_scope as session:
                if "hotpotqa" in self.dataset:
                    question_list = session.query(HotpotQA).all() # update({HotpotQA.points: "[]", HotpotQA.time: "[]", HotpotQA.viewed_users: "[]"})
                elif "qanta" in self.dataset:
                    question_list = session.query(Question).all() # update({Question.points: "[]", Question.time: "[]", Question.viewed_users: "[]"})
                for question  in tqdm(question_list):
                    question:Question
                    if question.viewed_users is None:
                        continue
                    old_viewed_users = json.loads(question.viewed_users) if question.viewed_users is not None else []
                    old_points = json.loads(question.points) if question.points is not None else []
                    old_time = json.loads(question.time) if question.time is not None else []
                    new_viewed_users = []
                    new_points = []
                    new_time = []
                    for user_i, viewed_user in enumerate(old_viewed_users):
                        if not (viewed_user in tmp_user_ids):
                            new_viewed_users.append(viewed_user)
                            new_points.append(old_points[user_i])
                            new_time.append(old_time[user_i])
                    if "hotpotqa" in self.dataset:
                        session.query(HotpotQA).filter(HotpotQA._id == question._id).update({HotpotQA.points: json.dumps(new_points), HotpotQA.time: json.dumps(new_time), HotpotQA.viewed_users: json.dumps(new_viewed_users)})
                    elif "qanta" in self.dataset:
                        session.query(Question).filter(Question.qanta_id == question.qanta_id).update({Question.points: json.dumps(new_points), Question.time: json.dumps(new_time), Question.viewed_users: json.dumps(new_viewed_users)})
                session.query(User).filter(User.user_id.in_(tmp_user_ids)).delete()
                session.query(Session).filter(Session.user_id.in_(tmp_user_ids)).delete()
                session.query(Plays).filter(Plays.username.in_(tmp_user_ids)).delete()
            print("All tmp data are deleted")
class Question(Base):
    __tablename__ = "questions"
    qanta_id = Column(Integer, primary_key=True)
    text = Column(String)
    first_sentence = Column(String)
    tokenizations = Column(String)
    answer = Column(String)
    time = Column(String)
    points = Column(String)
    page = Column(String)
    fold = Column(String)
    gameplay = Column(Boolean)
    category = Column(String)
    subcategory = Column(String)
    tournament = Column(String)
    difficulty = Column(String)
    GPT3_difficulty = Column(Integer)
    BERT_difficulty = Column(Integer)
    year = Column(Integer)
    proto_id = Column(Integer)
    qdb_id = Column(Integer)
    dataset = Column(String)
    viewed_users = Column(String)
    model_suggestions = Column(String)
    # tokens = Column(String)
    

    def from_dict(self, d):
        for k in d:
            setattr(self, k, d[k])

    def to_dict(self):
        if not self.time:
            time = []
        else:
            time = json.loads(self.time)
        if not self.points:
            points = []
        else:
            points = json.loads(self.points)
        if not self.viewed_users:
            viewed_users = []
        else:
            viewed_users = json.loads(self.viewed_users)
        if not self.model_suggestions:
            model_suggestions = {}
        else:
            model_suggestions = json.loads(self.model_suggestions)
        return {
            "qanta_id": self.qanta_id,
            "text": self.text,
            "tokenizations": json.loads(self.tokenizations),
            "answer": self.answer,
            "time": time,
            "points": points,
            "page": self.page,
            "fold": self.fold,
            "gameplay": self.gameplay,
            "category": self.category,
            "subcategory": self.subcategory,
            "tournament": self.tournament,
            "difficulty": self.difficulty,
            "GPT3_difficulty": self.GPT3_difficulty,
            "BERT_difficulty": self.BERT_difficulty,
            "year": self.year,
            "proto_id": self.proto_id,
            "qdb_id": self.proto_id,
            "dataset": self.dataset,
            "viewed_users": viewed_users,
            "model_suggestions": model_suggestions,
            # "tokens": json.loads(self.tokens),
        }

class HotpotQA(Base):
    __tablename__ = "hotpotqa"
    _id = Column(Integer, primary_key=True)
    question = Column(String)
    answer = Column(String)
    time = Column(String)
    points = Column(String)
    # context = Column(Binary)    
    # supporting_facts = Column(Binary)  
    viewed_users = Column(String)
    GPT3_difficulty = Column(Integer)
    BERT_difficulty = Column(Integer)
    model_suggestions = Column(String)

    def from_dict(self, d):
        for k in d:
            setattr(self, k, d[k])

    def to_dict(self):
        if not self.time:
            time = []
        else:
            time = json.loads(self.time)
        if not self.points:
            points = []
        else:
            points = json.loads(self.points)
        if not self.viewed_users:
            viewed_users = []
        else:
            viewed_users = json.loads(self.viewed_users)
        if not self.model_suggestions:
            model_suggestions = {}
        else:
            model_suggestions = json.loads(self.model_suggestions)
        return {
            "_id": self._id,
            "question": self.question,
            "answer": self.answer,
            "time": time,
            "points": points,
            "viewed_users": viewed_users,
            "GPT3_difficulty": self.GPT3_difficulty,
            "BERT_difficulty": self.GPT3_difficulty,
            "model_suggestions": model_suggestions
        }

class User(Base):
    __tablename__ = "users"
    user_id = Column(String, primary_key=True)
    email = Column(String, primary_key=True)
    password = Column(String)
    sessions = relationship('Session')
    # score = Column(Integer)
    game_data = Column(String)

    def __str__(self):
        return self.user_id

class Session(Base): # data on a single session
    __tablename__ = "sessions"

    session_id = Column(String, primary_key=True)
    user_id = Column(String,ForeignKey('users.user_id'))
    records = relationship('Record')

class Record(Base): # a single question attempt during a session
    __tablename__ = "records"
    
    record_id = Column(Integer, primary_key=True)
    # user_id = Column(Integer,ForeignKey('users.user_id'))
    session_id = Column(String, ForeignKey('sessions.session_id'))
    # question_id = relationship('Question', secondary=record_question_table)
    question_id = Column(Integer, ForeignKey('questions.qanta_id'))
    answer = Column(String)
    query = Column(String)
    evidence = Column(String)
    stop_position = Column(Integer)
class Plays(Base):
    __tablename__ = PLAYS_TABLE_NAME
    username = Column(String, primary_key = True)
    question_id = Column(String, primary_key = True)
    start_datetime = Column(String, primary_key = True)
    data = Column(String)

qanta_db = Database("qanta")
if CONFIG["hotpotqa_proportion"] > 0:
    hotpotqa_db = Database("hotpotqa")

# get question API
def get_question_by_id(question_id: str, dataset_name: str):

    if 'qanta' in dataset_name:
        qanta_row = qanta_db.get_question_by_id(question_id)
        if dataset_name == 'qanta_2':
            sentence_tokenizations = qanta_row["tokenizations"]
            qanta_row["text"] = qanta_row["text"][:sentence_tokenizations[1][1]]
        qanta_row["text"] = qanta_row["text"].replace(chr(160), " ")
        try:
            viewed_users = json.loads(viewed_users)
        except:
            viewed_users = []
        question_dict = {'id': qanta_row['qanta_id'], 
                        'question': qanta_row['text'], 
                        'answer': qanta_row['page'], 
                        'tokenizations': qanta_row["tokenizations"],
                        'viewed_users': qanta_row['viewed_users'],
                        'sentence_index': 0,
                        'GPT3_difficulty': qanta_row['GPT3_difficulty'],
                        }
            # id num val:112291
            # question str len 558: One poem by this author begins by describing the ideal location to construct an apiary. In another poem by this author, he describes an age in which all snakes die, and goats need not worry about lions. One character in a work by this man is enraged when he sees the belt (*) of Pallas. Horace writes a poem in which he throws a party with this man, who wrote an epic in which the hero abandons the Carthaginian Dido. This author's most famous work chronicles the journey of the son of Anchises. For 10 points name this  ... gics and the Aeneid.                                       
            # answer str len 6: Virgil
            # tokenizations list size: 6 [...]
                # item 0:  list size: 2 val: [0, 87]
                # item 1:  list size: 2 val: [88, 202]
                # 4 extra items
            # viewed_users list size: 0 []
    elif dataset_name == 'hotpotqa':
        # r = requests.get(f"http://127.0.0.1:4006/hotpotqa/get_row_by_id/{question_id}")
        # if r.status_code != requests.codes.ok:
        #     print("Error")
        # hotpotqa_row = r.json()
        hotpotqa_row = data_server.get_hotpotqa_row_by_id(question_id)
        print('hotpotqa_row', hotpotqa_row)
        question_dict = hotpotqa_row
    elif dataset_name == 'spring_novice':
        row = qanta_db.get_question_by_id_custom(question_id)
        return {'id': row[0], 
            'question': row[1], 
            'answer': row[2], 
            'tokenizations': json.loads(row[3]), 
            'packet_num': row[4],
            'question_num': row[5],
            'other_data': row[6]
            }
    return question_dict


def get_random_question(dataset_name: str):
    if dataset_name == 'qanta' or dataset_name == 'qanta_2':
        # qanta_id = random.choice(db._all_question_ids)
        # qanta_row = db.get_question_by_id(qanta_id)
        qanta_row = qanta_db.get_random_question()
        # if dataset_name == 'qanta_2': # only first two sentences
        #     sentence_tokenizations = qanta_row["tokenizations"]
        #     qanta_row["text"] = qanta_row["text"][:sentence_tokenizations[1][1]]
        
        qanta_row["text"] = qanta_row["text"].replace(chr(160), " ")
        viewed_users = qanta_row['viewed_users']
        try:
            viewed_users = json.loads(viewed_users)
        except:
            viewed_users = []
        if CONFIG["qanta_mode"] == "level":
            question_dict = {'id': qanta_row['qanta_id'], 
                        'question': qanta_row['text'], 
                        'answer': qanta_row['page'], # use wiki title as answer
                        'tokenizations': qanta_row["tokenizations"],
                        'viewed_users': qanta_row['viewed_users'],
                        'GPT3_difficulty': qanta_row['GPT3_difficulty'],
                        'sentence_index': 0
                        }
        elif CONFIG["qanta_mode"] == "sent":
            sentence_index = random.randint(0, len(qanta_row["tokenizations"]))
            start_pos, end_pos = qanta_row["tokenizations"][sentence_index]
            question_text = qanta_row['text'][start_pos: end_pos]
            question_dict = {'id': qanta_row['qanta_id'], 
                        'question': question_text, 
                        'answer': qanta_row['page'], 
                        'viewed_users': qanta_row['viewed_users'],
                        'GPT3_difficulty': qanta_row['GPT3_difficulty'],
                        'sentence_index': sentence_index
                        }
        if question_dict['answer'] == "":
            question_dict['answer'] = qanta_row['answer']

    elif 'hotpotqa' in dataset_name:
        # hotpotqa_row = data_server.get_hotpotqa_random_row()
        question_id = random.choice(hotpotqa_db._all_question_ids)
        hotpotqa_row = data_server.get_hotpotqa_row_by_id(question_id)
        
        question_dict = hotpotqa_row
    elif dataset_name == 'nq':
        # r = requests.get(f"http://127.0.0.1:4006/nq/get_random_row")
        # if r.status_code != requests.codes.ok:
        #     print("Error")
        row = data_server.get_nq_random_row()
        question_dict = row
    # debug(dataset_name, question_dict)
    return question_dict

# run this file, then clear all user data: python -m backend.database                               
if __name__ == "__main__":
    qanta_db.clear_tmp_data()
    hotpotqa_db.clear_tmp_data()

