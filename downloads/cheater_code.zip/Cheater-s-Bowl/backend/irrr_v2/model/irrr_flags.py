
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import collections
import json
import math
import os
import random
import modeling
import optimization
import tokenization
import six
import numpy as np
import sys
import glob
import shutil
from tokenization import _normalize
from superdebug import debug

import argparse
def str2bool(v): return v.lower() in ('true')
def get_args(require_tmp = False):
    parser = argparse.ArgumentParser()
    ## Required parameters
    # if require_tmp:
    parser.add_argument("tmp", type = str, default = "")

    parser.add_argument("--bert_config_file", type = str, default = None, help =
        "The config json file corresponding to the pre-trained BERT model. "
        "This specifies the model architecture.")
        
    parser.add_argument("--vocab_file", type = str, default = None, help =
        "The vocabulary file that the BERT model was trained on.")

    parser.add_argument("--output_dir", type = str, default = None, help =
        "The output directory where the model checkpoints will be written.")

    parser.add_argument("--model_scope", type = str, default = None, help =
        "Scope name of the BERT model E.g. bert or electra")
        
    parser.add_argument("--qg_reader_train_file", type = str, default = None, help =
        "Hotpot Reader training data files")
        
    parser.add_argument("--squad_reader_train_file", type = str, default = None, help =
        "SQuAD reader training data files")
        
    parser.add_argument("--qg_reader_predict_file", type = str, default = None, help =
        "Query generation prediction file")
        
    parser.add_argument("--init_checkpoint", type = str, default = None, help =
        "Initial checkpoint (usually from a pre-trained BERT model).")

    parser.add_argument("--do_lower_case", type=str2bool, default = False, help =
        "Whether to lower case the input text. Should be True for uncased "
        "models and False for cased models.")

    parser.add_argument("--debug", type=str2bool, default = False, help =
        "")
        
    parser.add_argument("--max_seq_length", type = int, default = 512, help =
        "The maximum total input sequence length after WordPiece tokenization. "
        "Sequences longer than this will be truncated, and sequences shorter "
        "than this will be padded.")
        
    parser.add_argument("--doc_stride", type = int, default = 384, help =
        "When splitting up a long document into chunks, how much stride to "
        "take between chunks.")

    parser.add_argument("--max_query_length", type = int, default = 64, help =
        "The maximum number of tokens for the question. Questions longer than "
        "this will be truncated to this length.")

    parser.add_argument("--do_train", type=str2bool, default = False, help = 
        "Whether to run training.")
        
    parser.add_argument("--do_predict", type=str2bool, default = False, help = 
        "Whether to run eval on the dev set.")

    parser.add_argument("--train_batch_size", type = int, default = 32, help = 
        "Total batch size for training.")
        
    parser.add_argument("--predict_batch_size", type = int, default = 32, help =
        "Total batch size for predictions.")

    parser.add_argument("--learning_rate", type = float, default = 5e-5, help = 
        "The initial learning rate for Adam.")

    parser.add_argument("--warmup_proportion", type = float, default = 0.1, help = 
        "Proportion of training to perform linear learning rate warmup for. "
        "E.g., 0.1 = 10% of training.")
        
    parser.add_argument("--n_best_size", type = int, default = 40, help =
        "The total number of n-best predictions to generate in the "
        "nbest_predictions.json output file.")

    parser.add_argument("--max_answer_length", type = int, default = 20, help =
        "The maximum length of an answer that can be generated. This is needed "
        "because the start and end predictions are not conditioned on one another.")
        
    parser.add_argument("--null_score_diff_threshold", type = float, default = 10000.0, help =
        "If null_score - best_non_null is greater than the threshold predict null.")
        

    parser.add_argument("--verbose_logging", type=str2bool, default = False, help = 
        "If true, all of the warnings related to data processing will be printed. "
        "A number of warnings are expected for a normal SQuAD evaluation.")
        
    parser.add_argument("--save_checkpoints_steps", type = int, default = 1000, help = 
        "How often to save the model checkpoint.")
        
    parser.add_argument("--iterations_per_loop", type = int, default = 1000, help = 
        "How many steps to make in each estimator call.")
        
    parser.add_argument("--choice_size", type = int, default = 1, help = 
        "Max number of reasoning path choice at each hop")
        
    parser.add_argument("--ranking_candidates", type = int, default = 5, help = 
        "The number of cadidates for reasoning path.")
            
    parser.add_argument("--num_iteration", type = int, default = 100000, help = "Num of iteration")
        
    parser.add_argument("--num_accumulation", type = int, default = 1, help ="Num of gradient acculuation steps")
        
    parser.add_argument("--random_seed", type = int, default = 10000, help = 
        "Random seed.")

    parser.add_argument("--no_empty_query_loss", type=str2bool, default = False, help = 
        "Whether to minimize loss of query generation for impossible cases.")

    parser.add_argument("--merge_queries", type=str2bool, default = False, help = 
        "Whether to merge queries from multiple reasoning path ")

    parser.add_argument("--short", type=str2bool, default = True, help = 
        "Whether to use short oracle queries")

    parser.add_argument("--rank_network", type=str2bool, default = False, help = 
        "Whether to use additional transformer network for reranking")     
    
    parser.add_argument("--horovod", type=str2bool, default = False, help = 
        "Whether to use Horovod for multi-gpu runs")

    parser.add_argument("--advantage", type = float, default = 2.0, help = 
        "Amount of boosting of positive log probs for query generation")

    parser.add_argument("--prev_query", type=str2bool, default = False, help = 
        "Whether to use a previous query embedding for query generation model") 

    parser.add_argument("--soft_target", type=str2bool, default = True, help = 
        "Whether to use 1/10 target for non-gold paragraph with connection to the gold ") 

    parser.add_argument("--use_distant", type=str2bool, default = True, help = 
        "Whether to use distant supervision of reader model (non-gold paragraph with answer)") 

    parser.add_argument("--use_xla", type=str2bool, default = True, help = 
        "Whether to enable XLA JIT compilation.")

    parser.add_argument("--use_fp16", type=str2bool, default = True, help = 
        "Whether to use fp32 or fp16 arithmetic on GPU.")
                        
    parser.add_argument("--split_count", type = int, default = 1, help = 
        "Max number of reasoning path choice at each hop")

    parser.add_argument("--port", type = int, default = 4006, help = "Uvicorn port")
        
    parser.add_argument("--reload", default = True, action = "store_true", help = 
        "Whether to auto reload")

    parser.add_argument("--log_step_count_steps", type = int, default = 100, help =
        "Log loss and accuracy every log_step_count_steps")
    args = parser.parse_args()
    return args

debug()
FLAGS = get_args()


def validate_flags_or_throw(bert_config):
  """Validate the input FLAGS or throw an exception."""
  if not FLAGS.do_train and not FLAGS.do_predict:
    raise ValueError("--At least one of `do_train` or `do_predict` must be True.")

  if FLAGS.do_predict:
    if not FLAGS.qg_reader_predict_file:
      raise ValueError(
          "If `do_predict` is True, then `predict_file` must be specified.")

  if FLAGS.max_seq_length > bert_config.max_position_embeddings:
    raise ValueError(
        "Cannot use sequence length %d because the BERT model "
        "was only trained up to sequence length %d" %
        (FLAGS.max_seq_length, bert_config.max_position_embeddings))

  if FLAGS.max_seq_length <= FLAGS.max_query_length + 3:
    raise ValueError(
        "The max_seq_length (%d) must be greater than max_query_length "
        "(%d) + 3" % (FLAGS.max_seq_length, FLAGS.max_query_length))
