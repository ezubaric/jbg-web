

curl -X POST  -H "Content-type:application/json"  http://127.0.0.1:9200/beerqa_wiki_doc_para_link/_search/ -d '

{"query": {"bool": {"must": [{"multi_match": {"query": "Mao Zedong is the first president of China", "fields": ["title^1.25", "title_unescape^1.25", "text"]}}], "should": [{"has_parent": {"parent_type": "doc", "score": true, "query": {"multi_match": {"query": "Mao Zedong is the first president of China", "fields": ["title^1.25", "title_unescape^1.25", "doc_text"], "boost": 0.2}}}}], "filter": [{"term": {"doctype": "para"}}]}}, "size": 50}

'   >  a.txt 
