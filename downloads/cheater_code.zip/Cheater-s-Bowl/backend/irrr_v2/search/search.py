# python -m backend.irrr_v1.search.search
from elasticsearch import Elasticsearch
import json
import re
# from utils.constant import WIKIPEDIA_DOC_PARA_INDEX_NAME
WIKIPEDIA_DOC_PARA_INDEX_NAME='*wikipedia_doc_para'
BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME='beerqa_wiki_doc_para_link'
BEERQA_WIKIPEDIA_DOC_PARA_INDEX_NAME='beerqa_wiki_doc_para'
from superdebug import debug, mark
import sys
sys.path.append("")
from backend.config import CONFIG
es = Elasticsearch(timeout=300, hosts = CONFIG["search_engine"]["ES"])
if CONFIG["search_engine"]["ES"] == "https://localhost:9200" or CONFIG["search_engine"]["ES"] == "https://localhost:9200/":
    es = Elasticsearch(timeout=300)

core_title_matcher = re.compile('([^()]+[^\s()])(?:\s*\(.+\))?')
core_title_filter = lambda x: core_title_matcher.match(x).group(1) if core_title_matcher.match(x) else x

def _extract_one(item, lazy=False):
    res = {k: item['_source'][k] if k != 'text' else item['_source'].get(k, item['_source'].get('doc_text', None)) for k in ['id', 'url', 'title', 'text', 'title_unescape', 'docid']}
    res['_score'] = item['_score']
    res['data_object'] = item['_source']['original_json'] if lazy else json.loads(item['_source']['original_json'])

    return res

def _single_query_constructor(query, topn=50, exclude_title=False):
    fields = ["text"] if exclude_title else ["title^1.25", "title_unescape^1.25", "text"]
    return {
            "query": {
                "bool": {
                    "must": [
                        {"multi_match": {
                            "query": query,
                            "fields": fields,
                        }},
                    ],
                    "should": [
                        { "has_parent": {
                            "parent_type": "doc",
                            "score": True,
                            "query": {
                                "multi_match": {
                                    "query": query,
                                    "fields": [x if x != 'text' else 'doc_text' for x in fields],
                                    "boost": 0.2
                                },
                            }
                        }}
                    ],
                    "filter": [
                        {"term": {
                            "doctype": "para"
                        }}
                    ],
                }
            },
            "size": topn
        }

def single_doc_query(query="", topn=10, lazy=False, index=WIKIPEDIA_DOC_PARA_INDEX_NAME, title=None, match_phrase=False, title_only=True, docid=None):
    query_type = 'match_phrase' if match_phrase else 'match'
    query_field = 'title_unescape' if title_only else 'doc_text'
    body = {"query": 
                { "bool": 
                    { 
                        "must": [
                            {query_type: {query_field: query}}
                        ], 
                        "filter":[
                            {"term": {"doctype":"doc"}}
                        ]
                    }
                }, 
            "size": topn}
    if title is not None:
        body['query']['bool']['must'] = [{'match_phrase': {'title_unescape': title}}]
    if docid is not None:
        body['query']['bool']['must'] = [{"term": {"docid": docid}}]
    debug(body=body)
    res = es.search(index=index, doc_type='doc', body=json.dumps(body))
    res = [_extract_one(x, lazy=lazy) for x in res['hits']['hits']]
    res = rerank_with_query(query, res)[:topn]
    debug(res) # dict with keys ['id', 'url', 'title', 'text', 'title_unescape', 'docid', '_score', 'data_object']
    return res

def single_text_query(query="", topn=10, lazy=False, rerank_topn=50, index=WIKIPEDIA_DOC_PARA_INDEX_NAME, title=None, docid=None):
    body = _single_query_constructor(query, topn=max(topn, rerank_topn))
    if title is not None:
        body['query']['bool']['must'] = [{'match_phrase': {'title_unescape': title}}]
        del body['query']['bool']['should']
    if docid is not None:
        body['query']['bool']['filter'].append({
            "regexp": { "docid": docid + "-.*"  }
        })
        del body['query']['bool']['should']
        del body['query']['bool']['must']
    res = es.search(index=index, doc_type='doc', body=json.dumps(body))
    res = [_extract_one(x, lazy=lazy) for x in res['hits']['hits']]
    if title is not None or docid is not None:
        if title is not None:
            res = [x for x in res if x['title_unescape'] == title]
        res.sort(key = lambda x:int(x["id"].split("-")[-1]))
    else:
        res = rerank_with_query(query, res)[:topn] # finally return topn results
    return res

def single_docid_query(docid, index=BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME):
    body = {
            "query": {
                "bool": {
                    "filter": [
                        {"term": {
                            "doctype": "para"
                        }},
                        {
                            "term": { "docid": docid}
                        }
                        
                    ],
                }
            },
            "size": 5
        }
    res = es.search(index=index, doc_type='doc', body=json.dumps(body))
    res = [_extract_one(x, lazy=False) for x in res['hits']['hits']]
    return res

def single_docid_regex_query(docid, index=BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME):
    body = {
            "query": {
                "bool": {
                    "filter": [
                        {"term": {
                            "doctype": "para"
                        }},
                        {
                            "regexp": { "docid": docid}
                        }
                        
                    ],
                }
            },
            "size": 9999
        }
    res = es.search(index=index, doc_type='doc', body=json.dumps(body))
    res = [_extract_one(x, lazy=False) for x in res['hits']['hits']]
    return res

def single_match_sequence_query(text, index=BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME):
    body = {
            "query": {
                "bool": {
                    "must": [
                        {"multi_match": { # match_phrase
                            "query": text,
                            # "fields": ["text"],
                        }},
                    ],
                    "filter": [
                        {"term": {
                            "doctype": "para"
                        }}
                    ],
                }
            },
            "size": 5
        }
    res = es.search(index=index, doc_type='doc', body=json.dumps(body))
    res = [_extract_one(x, lazy=False) for x in res['hits']['hits']]
    return res

def bulk_text_query(queries, topn=10, lazy=False, rerank_topn=50, index=WIKIPEDIA_DOC_PARA_INDEX_NAME):
    body = ["{}\n" + json.dumps(_single_query_constructor(query, topn=max(topn, rerank_topn))) for query in queries]
    res = es.msearch(index=index, doc_type='doc', body='\n'.join(body))

    res = [[_extract_one(x, lazy=lazy) for x in r['hits']['hits']] for r in res['responses']]
    res = [rerank_with_query(query, results)[:topn] for query, results in zip(queries, res)]

    return res
def _single_query_for_context_constructor(question, answer, topn = 2):
    return {
            "query": {
                "bool": {
                    "must": [
                        # {"multi_match": {
                        #     "query": answer,
                        #     "fields": ["title", "title_unescape"],
                        #     "boost": 10
                        # }},
                        {"multi_match": {
                            "query": question,
                            "fields": ["text"],
                        }}
                    ],
                    "should": [
                        { "has_parent": {
                            "parent_type": "doc",
                            "score": True,
                            "query": {
                                "multi_match": {
                                    "query": question + " " + answer,
                                    "fields": ["title^1.25", "title_unescape^1.25", "doc_text"],
                                    "boost": 0.2
                                },
                            }
                        }}
                    ],
                    "filter": [
                        {"multi_match": {
                            "query": answer,
                            "fields": ["text"],
                        }},
                        {"term": {
                            "doctype": "para"
                        }}
                    ],
                }
            },
            "size": topn
        }
def single_query_for_context(question, answer, topn = 2, index=BEERQA_WIKIPEDIA_DOC_PARA_INDEX_NAME):
    body = _single_query_for_context_constructor(question, answer, topn)
    res = es.search(index=index, doc_type='doc', body=json.dumps(body))
    res = [_extract_one(x, lazy=False) for x in res['hits']['hits']]
    return res
def bulk_query_for_context(qas, topn = 2, index=BEERQA_WIKIPEDIA_DOC_PARA_INDEX_NAME):
    body = ["{}\n" + json.dumps(_single_query_for_context_constructor(question, answer, topn)) for question, answer in qas]
    res = es.search(index=index, doc_type='doc', body='\n'.join(body))
    res = [_extract_one(x) for x in res['hits']['hits']]
    return res

def rerank_with_query(query, results):
    def score_boost(item, query):
        score = item['_score']
        core_title = core_title_filter(item['title_unescape'])
        if query.startswith('The ') or query.startswith('the '):
            query1 = query[4:]
        else:
            query1 = query
        if query == item['title_unescape'] or query1 == item['title_unescape']:
            score *= 1.5
        elif query.lower() == item['title_unescape'].lower() or query1.lower() == item['title_unescape'].lower():
            score *= 1.2
        elif item['title'].lower() in query:
            score *= 1.1
        elif query == core_title or query1 == core_title:
            score *= 1.2
        elif query.lower() == core_title.lower() or query1.lower() == core_title.lower():
            score *= 1.1
        elif core_title.lower() in query.lower():
            score *= 1.05

        item['_score'] = score
        return item

    return list(sorted([score_boost(item, query) for item in results], key=lambda item: -item['_score']))

if __name__ == "__main__":
    while True:
        title = input("Enter title: \n") # "Communism"
        debug(single_text_query(index=BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME, topn = 200, title = title))
        query = input("Enter query: \n")
        topn = int(input("Enter topn: \n"))
        debug(single_text_query(query, index=BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME, topn = topn))
        # print([[y['title'] for y in x] for x in bulk_text_query(["Elon Mask"], index=BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME)])
        # debug(single_doc_query(index=BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME, docid="wiki-2844938")) # find exact document using docid
        # debug([res["docid"] for res in single_text_query(index=BEERQA_WIKIPEDIA_DOC_PARA_LINK_INDEX_NAME, docid="wiki-2844938", topn = 10000)]) # find paragraphs in exact document using docid
