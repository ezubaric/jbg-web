# change the hosts when running
from argparse import ArgumentParser
import bz2
from glob import glob
import html
import json
from multiprocessing import Pool
import re
from tqdm import tqdm
from urllib.parse import unquote

from utils.constant import WIKIPEDIA_DOC_PARA_INDEX_NAME, SQUAD_WIKIPEDIA_DOC_PARA_INDEX_NAME, HOTPOT_WIKIPEDIA_DOC_PARA_INDEX_NAME, SQUAD_WIKITITLE_MAPPING, BEERQA_WIKIPEDIA_DOC_PARA_INDEX_NAME
from utils.corenlp import get_sentence_list, bulk_tokenize
from utils.general import chunks
from superdebug import debug, mark

import pandas as pd

# stop words copied from DrQA
STOPWORDS = [
    'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your',
    'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she',
    'her', 'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their',
    'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that',
    'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an',
    'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of',
    'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through',
    'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down',
    'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then',
    'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any',
    'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor',
    'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't', 'can',
    'will', 'just', 'don', 'should', 'now', 'd', 'll', 'm', 'o', 're', 've',
    'y', 'ain', 'aren', 'couldn', 'didn', 'doesn', 'hadn', 'hasn', 'haven',
    'isn', 'ma', 'mightn', 'mustn', 'needn', 'shan', 'shouldn', 'wasn', 'weren',
    'won', 'wouldn', "'ll", "'re", "'ve", "n't", "'s", "'d", "'m", "''", "``"
]


def process_line(line):
    data = json.loads(line)
    docid = f"hotpot_wiki-{data['id']}"
    data['docid'] = docid
    item = {'id': data['id'],
            'url': data['url'],
            'title': data['title'],
            'title_unescape': html.unescape(data['title']),
            'doc_text': ''.join(data['text']),
            'original_json': json.dumps(data),
            'docid': docid,
            'doctype': 'doc',
            }
    # tell elasticsearch we're indexing documents
    body = ["{}\n{}".format(json.dumps({ 'index': { '_id': docid, '_routing': docid } }), json.dumps(item))]

    item['doctype'] = { 'name': 'para', 'parent': docid }
    item['text'] = item['doc_text']
    del item['doc_text']
    paraid = f"{docid}-0"
    item['docid'] = paraid
    data['docid'] = paraid
    item['original_json'] = json.dumps(data)
    body.append("{}\n{}".format(json.dumps({ 'index': { '_id': paraid, '_routing': docid } }), json.dumps(item)))

    return ('\n'.join(body))

def generate_hotpot_indexing_queries_from_bz2(bz2file):
    with bz2.open(bz2file, 'rt') as f:
        yield from (process_line(line) for line in f)

def process_line_beerqa_bz2(line, with_link=False): # TODO: text -> text_with_links
    data = json.loads(line)
    docid = f"wiki-{data['id']}"
    if with_link:
        raw_text = data['text_with_links']
        text = []
        for sentence in raw_text:
            if sentence == "" or "|" in sentence or re.search('[^f]="', sentence) or sentence == "\n\n!":
                continue
            sentence_pieces = []
            splited_sentence = sentence.split('href="')
            for piece in splited_sentence:
                splited_pieces = piece.split('">')
                if len(splited_pieces) == 1:
                    sentence_pieces.append(splited_pieces[0])
                else:
                    sentence_pieces.append(unquote(splited_pieces[0]))
                    sentence_pieces.append('">')
                    sentence_pieces.append(splited_pieces[1])
                sentence_pieces.append('href="')


            text.append("".join(sentence_pieces[:-1]))
    else:
        text = data['text']
    doc_text = ''.join(text)

    # only yield paragraphs
    # item = {'id': data['id'],
    #         'url': data['url'],
    #         'title': data['title'],
    #         'title_unescape': html.unescape(data['title']),
    #         'doc_text': doc_text,
    #         'original_json': json.dumps({'id': data['id'], 'url': data['url'], 'title': data['title'], 'text': text, 'docidid': docid}), #line,
    #         'docid': docid,
    #         'doctype': 'doc',
    #         }
    # # tell elasticsearch we're indexing documents
    # yield "{}\n{}".format(json.dumps({ 'index': { '_id': docid, '_routing': docid } }), json.dumps(item))

    for para_id, para in enumerate(doc_text.split('\n')):
        if len(para.strip()) == 0 or len(para.split()) <= 10:
            # skip empty paragraphs, section titles, and the page title
            continue

        paraid = f"{docid}-{para_id}"
        obj = {'title': data['title'] , 'text': get_sentence_list(para), 'docid': paraid}
        item = {'id': paraid,
                'url': 'no_url',
                'doctype': { 'name': 'para', 'parent': docid },
                'title': data['title'],
                'title_unescape': html.unescape(data['title']),
                'text': para,
                'original_json': json.dumps(obj),
                'docid': paraid
                }

        yield item

def generate_indexing_queries_from_beerqa_bz2(bz2file, with_link = False):
    with bz2.open(bz2file, 'rt') as f:
        for line in f:
            yield from process_line_beerqa_bz2(line, with_link=with_link)




def query_generator(index_type):
    if index_type == "beerqa" or index_type == "beerqa_link":
        filelist = glob('data/enwiki-20200801-pages-articles-tokenized/*/wiki_*.bz2')
        # filelist = glob('/john10/scr1/pengqi/enwiki-20200801-pages-articles-tokenized/*/wiki_*.bz2')
        # debug(filelist)
        for f in tqdm(filelist, position=1):
            # mark()
            yield from generate_indexing_queries_from_beerqa_bz2(f, with_link = index_type.endswith("beerqa_link"))
            if args.debug:
                return
class Process:
    def __init__(self, args):
        print("Adding to dataframe...")
        self.df = pd.DataFrame()
        self.pbar = tqdm(total=-1, position=0)
        
        pool = Pool()
        chunksize = 8192
        for i, chunk in enumerate(chunks(query_generator(args.type), chunksize)):
            self.update(self.add_to_dataframe(chunk))
            # pool.apply_async(self.add_to_dataframe, [chunk], error_callback=print, callback=self.update)

        pool.close()
        pool.join()

        debug(df=len(self.df))
        self.df.to_csv('backend/DPR/dpr/downloads/data/wikipedia_split/psgs_20200801.tsv', sep="\t", index=False)
    def update(self, *a):
        self.pbar.update(a[0])
    def add_to_dataframe(self, chunk):
        df_items = []
        for item in chunk:
            df_items.append({"id": item['id'], "text": item["text"], "title": item["title_unescape"]})
        self.df = pd.concat([self.df, pd.DataFrame.from_records(df_items)])
        return len(chunk)


if __name__ == '__main__':
    parser = ArgumentParser()

    parser.add_argument('--type', choices=['squad', 'hotpot', 'beerqa', "beerqa_link"], default='beerqa') # we don't need with link in order to search in DPR
    parser.add_argument('--debug', default = False, action='store_true', help="Debug run")

    args = parser.parse_args()

    Process(args)
