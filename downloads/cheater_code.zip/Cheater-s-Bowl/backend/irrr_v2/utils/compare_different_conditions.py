"""
cd backend/irrr_v2 && python utils/compare_different_conditions.py
"""
import argparse
from audioop import avg
import json
from collections import Counter, defaultdict
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
from superdebug import debug
def average(num_list):
    return sum(num_list) / len(num_list)
def average_list(num_list_list):
    avg_list = []
    for i in range(len(num_list_list[0])):
        avg_list.append(average([num_list[i] for num_list in num_list_list]))
    return avg_list
def best_list(num_list_list):
    best_list = num_list_list[0]
    for num_list in num_list_list:
        if sum(num_list) > sum(best_list):
            best_list = num_list
    return best_list

def build_input_dict(input_dir):
    input_dict = defaultdict(dict)
    for hop_n in range(1, 5):
        input_path = os.path.join(input_dir, f"hop{hop_n}", "input.json")
        if os.path.exists(input_path):
            input_list = json.load(open(input_path, "r"))["data"]
            for input_data_piece in input_list:
                id = input_data_piece["id"] if "id" in input_data_piece else input_data_piece["paragraphs"][0]["qas"][0]["id"]
                input_dict[hop_n][id] = input_data_piece
    return input_dict
def build_question_dict(input_path):
    input_list = json.load(open(input_path, "r"))["data"]
    input_dict = {}
    for input_data_piece in input_list:
        id = input_data_piece["id"]
        input_dict[id] = input_data_piece
    return input_dict

def recover_reasoning_path(input, id, id_correct_answer_min_hop, answers_each_hop):
    # answers_each_hop starts from hop1 (do not include hop0 since it is meaningless)
    reasoning_path = []
    init_hop_n = min(list(input.keys()))
    try:
        for hop_n in range(init_hop_n, min(3, id_correct_answer_min_hop) + 1):
            id_input = input[hop_n][id] if id in input[hop_n] else (input[hop_n][id + "_0"] if id + "_0" in input[hop_n] else input[hop_n][id + "_1"])
            id_input_n1 = input[hop_n+1][id] if id in input[hop_n+1] else (input[hop_n+1][id + "_0"] if id + "_0" in input[hop_n+1] else input[hop_n+1][id + "_1"])
            if hop_n == init_hop_n and hop_n != 1:
                for hop_n_1, retrieved_context in enumerate(id_input_n1["paragraphs"][0]["retrieved_context"][:-2]):
                    reasoning_path.append({"retrieved_context": retrieved_context, "answer": answers_each_hop[hop_n_1]}) # NOTE: answer is generated using each retrieved context, however, we only show one retrieved context here
            prev_query = id_input["paragraphs"][0]["prev_query"]
            retrieved_context = id_input_n1["paragraphs"][0]["retrieved_context"][-2] # this is the retrieved context after reranking, which appeared in the n+1 hop
            reasoning_path.append({"prev_query": prev_query, "retrieved_context": retrieved_context, "answer": answers_each_hop[hop_n - 1]})
        return reasoning_path
    except Exception as e:
        # debug("Reasoning path is broken", hop_n=hop_n, id_input=id_input, id_input_n1=id_input_n1, error = e)
        return "Reasoning path is broken"
    

def analyze_different_conditions(args):
    answer_judgement_baseline = json.load(open(args.answer_judgement_baseline, "r"))
    questions = build_question_dict(args.question_file)
    baseline_input = build_input_dict(args.baseline_dir)
    for other_i, answer_judgement_other in enumerate(args.answer_judgement_others):
        # load files
        other_dir = args.others_dir[other_i]
        # answer_other = json.load(open(os.path.join(other_dir), "r"))
        answer_judgement_other = json.load(open(answer_judgement_other, "r"))
        hopn = sorted([_ for _ in os.listdir(other_dir) if _.startswith("hop")])[0]
        other_input = build_input_dict(args.others_dir[other_i])

        # init counters
        other_final_answer_correct = defaultdict(list); other_final_answer_correct_cnt = 0; baseline_final_answer_correct_cnt = 0; baseline_final_answer_incorrect_other_final_answer_correct_cnt = 0; other_final_answer_incorrect_baseline_final_answer_correct_cnt = 0
        other_some_hop_answer_correct = defaultdict(list); other_some_hop_answer_correct_cnt = 0; baseline_some_hop_answer_correct_cnt = 0; baseline_all_hop_answer_incorrect_other_some_hop_answer_correct_cnt = 0; other_all_hop_answer_incorrect_baseline_some_hop_answer_correct_cnt = 0
        other_each_hop_correct = defaultdict(list); other_each_hop_correct_cnt = defaultdict(int); baseline_each_hop_correct_cnt = defaultdict(int)
        other_confident_hop = defaultdict(list); other_confident_hop_hist = defaultdict(int); baseline_confident_hop_hist = defaultdict(int)
        other_correct_answer_min_hop = defaultdict(list); other_correct_answer_min_hop_hist = defaultdict(int); baseline_correct_answer_min_hop_hist = defaultdict(int)
        other_ids = defaultdict(list)
        helpful_input = {}

        # summurize using baseline_id
        for other_id in answer_judgement_other:
            baseline_id = other_id.split("-rand")[0]
            other_ids[baseline_id].append(other_id)
            other_final_answer_correct[baseline_id].append(answer_judgement_other[other_id]["final_answer_correct"])
            other_each_hop_correct[baseline_id].append(answer_judgement_other[other_id]["answers_each_hop_correct"])
            other_some_hop_answer_correct[baseline_id].append(any(answer_judgement_other[other_id]["answers_each_hop_correct"]))
            other_confident_hop[baseline_id].append(answer_judgement_other[other_id]["confident_hop"])
            other_correct_answer_min_hop[baseline_id].append(answer_judgement_other[other_id]["correct_answer_min_hop"])

        # count
        for baseline_id in other_final_answer_correct:
            other_id_final_answer_correct = any(other_final_answer_correct[baseline_id]) if args.reduce_repeated_question == "best" else average(other_final_answer_correct[baseline_id])
            other_final_answer_correct_cnt += other_id_final_answer_correct
            baseline_final_answer_correct_cnt += int(answer_judgement_baseline[baseline_id]["final_answer_correct"])

            if other_id_final_answer_correct != 0 and not answer_judgement_baseline[baseline_id]["final_answer_correct"]:
                baseline_final_answer_incorrect_other_final_answer_correct_cnt += 1
            if other_id_final_answer_correct == 0 and answer_judgement_baseline[baseline_id]["final_answer_correct"]:
                other_final_answer_incorrect_baseline_final_answer_correct_cnt += 1

            other_id_some_hop_answer_correct = any(other_some_hop_answer_correct[baseline_id]) if args.reduce_repeated_question == "best" else average(other_some_hop_answer_correct[baseline_id])
            other_some_hop_answer_correct_cnt += other_id_some_hop_answer_correct; baseline_some_hop_answer_correct_cnt += int(any(answer_judgement_baseline[baseline_id]["answers_each_hop_correct"]))
            if other_id_some_hop_answer_correct != 0 and not any(answer_judgement_baseline[baseline_id]["answers_each_hop_correct"]):
                baseline_all_hop_answer_incorrect_other_some_hop_answer_correct_cnt += 1
            if other_id_some_hop_answer_correct == 0 and any(answer_judgement_baseline[baseline_id]["answers_each_hop_correct"]):
                other_all_hop_answer_incorrect_baseline_some_hop_answer_correct_cnt += 1

            # filtering
            if "baseline" in args.filter_mode and not any(answer_judgement_baseline[baseline_id]["answers_each_hop_correct"]):
                continue
            if "other" in args.filter_mode and other_id_some_hop_answer_correct == 0:
                continue
            other_id_each_hop_correct = best_list(other_each_hop_correct[baseline_id]) if args.reduce_repeated_question == "best" else average_list(other_each_hop_correct[baseline_id])
            for hop_n_1, _ in enumerate(answer_judgement_baseline[baseline_id]["answers_each_hop_correct"]):
                other_each_hop_correct_cnt[hop_n_1 + 1] += other_id_each_hop_correct[hop_n_1]
                baseline_each_hop_correct_cnt[hop_n_1 + 1] += int(answer_judgement_baseline[baseline_id]["answers_each_hop_correct"][hop_n_1])

            other_id_confident_hop = min(other_confident_hop[baseline_id]) if args.reduce_repeated_question == "best" else round(average(other_confident_hop[baseline_id]))
            other_confident_hop_hist[other_id_confident_hop] += 1; baseline_confident_hop_hist[answer_judgement_baseline[baseline_id]["confident_hop"]] += 1
            other_id_correct_answer_min_hop = min(other_correct_answer_min_hop[baseline_id]) if args.reduce_repeated_question == "best" else round(average(other_correct_answer_min_hop[baseline_id]))
            baseline_id_correct_answer_min_hop = answer_judgement_baseline[baseline_id]["correct_answer_min_hop"]
            other_correct_answer_min_hop_hist[other_id_correct_answer_min_hop] += 1; baseline_correct_answer_min_hop_hist[baseline_id_correct_answer_min_hop] += 1

            for _other_i, other_id in enumerate(other_ids[baseline_id]):
                if other_correct_answer_min_hop[baseline_id][_other_i] == int(other_id_correct_answer_min_hop) and int(other_id_correct_answer_min_hop) <= baseline_id_correct_answer_min_hop - 2:
                    question = questions[baseline_id]
                    if baseline_id not in helpful_input:
                        helpful_input[baseline_id] = {
                            "question": question["question"],
                            "answer": question["answers"][0],
                            "baseline_id": baseline_id,
                            "baseline_input": {
                                "correct_answer_min_hop": baseline_id_correct_answer_min_hop,
                                "reasoning_path": recover_reasoning_path(baseline_input, baseline_id, baseline_id_correct_answer_min_hop, answer_judgement_baseline[baseline_id]["answers_each_hop"]),
                                
                            },
                            "helpful_input": []
                        }
                    helpful_input[baseline_id]["helpful_input"].append(
                        {
                            "id": other_id,
                            "correct_answer_min_hop": other_correct_answer_min_hop[baseline_id][_other_i],
                            "reasoning_path": recover_reasoning_path(other_input, other_id, other_id_correct_answer_min_hop, answer_judgement_other[other_id]["answers_each_hop"]),
                        }
                    )
        
        # print
        print("other_final_answer_correct_rate:", 100 * other_final_answer_correct_cnt / len(other_final_answer_correct), "baseline_final_answer_correct_rate:", 100 * baseline_final_answer_correct_cnt / len(other_final_answer_correct), "baseline_final_answer_incorrect_other_final_answer_correct_rate:", 100 * baseline_final_answer_incorrect_other_final_answer_correct_cnt / len(other_final_answer_correct), "other_final_answer_incorrect_baseline_final_answer_correct_rate:", 100 * other_final_answer_incorrect_baseline_final_answer_correct_cnt / len(other_final_answer_correct))
        print("other_some_hop_answer_correct_rate:", 100 * other_some_hop_answer_correct_cnt / len(other_final_answer_correct), "baseline_some_hop_answer_correct_rate:", 100 * baseline_some_hop_answer_correct_cnt / len(other_final_answer_correct), "baseline_all_hop_answer_incorrect_other_some_hop_answer_correct_rate:", 100 * baseline_all_hop_answer_incorrect_other_some_hop_answer_correct_cnt / len(other_final_answer_correct), "other_all_hop_answer_incorrect_baseline_some_hop_answer_correct_rate:", 100 * other_all_hop_answer_incorrect_baseline_some_hop_answer_correct_cnt / len(other_final_answer_correct))
        debug(other_each_hop_correct_cnt = other_each_hop_correct_cnt, baseline_each_hop_correct_cnt = baseline_each_hop_correct_cnt)
        debug(other_confident_hop_hist = other_confident_hop_hist, baseline_confident_hop_hist = baseline_confident_hop_hist)
        debug(other_correct_answer_min_hop_hist = other_correct_answer_min_hop_hist, baseline_correct_answer_min_hop_hist = baseline_correct_answer_min_hop_hist)
        helpful_input_path = os.path.join(other_dir, "helpful_input.json")
        json.dump(helpful_input, open(helpful_input_path, "w"), indent=4)
        debug(helpful_input_path=helpful_input_path)


def run_baseline(args):
    script = f"bash scripts/predict_dynamic_hops.sh {args.baseline_dir}  ./data/qanta/squadified_qanta_test_from_collected.json   ../irrr_model 10 3 electra beerqa_wiki_doc_para   {args.model_checkpoint}"
    print(script)
    os.system(script)

def run_others(args):
    for other_dir in args.others_dir:
        # hop_n = int(other_dir[-4:-3])
        hop_n = int(sorted([_ for _ in os.listdir(other_dir) if _.startswith("hop")])[-1][-1])
        debug(hop_n=hop_n, other_dir=other_dir)
        script = f"bash scripts/predict_dynamic_hops.sh {other_dir}  {os.path.join(other_dir, 'question_file.json')}  ../irrr_model 10 3 electra beerqa_wiki_doc_para {args.model_checkpoint} {hop_n} {os.path.join(other_dir, 'question_file.json')}"
        print(script)
        os.system(script)

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline_dir", type=str, default="output/test_collected_qanta_query") # output/test_qanta_collected_orig
    parser.add_argument("--others_dir", default=[f"data/qanta/test_init_hop_collected_qanta_query/init_{hopn}hop" for hopn in range(0, 1)]) # data/qanta/qanta_test_init_hop_collected_orig/init_{hopn}hop 1 4
    # NOTE: when testing a different model, run convert_collected_data.py again to produce input in another directory
    parser.add_argument("--question_file", type=str, default="data/qanta/squadified_qanta_test_from_collected.json")
    parser.add_argument("--model_checkpoint", type=str, default="") # "" "../output/train_qanta/model.ckpt-12000"
    parser.add_argument("--filter_mode", type=str, default="") # "baseline others"
    parser.add_argument("--reduce_repeated_question", type=str, default="best", choices = ["best", "average"])
    parser.add_argument("--tasks", default = ["run_baseline", "run_others", "analyze"]) # "run_baseline", "run_others", "analyze"
    args = parser.parse_args()
    args.answer_judgement_baseline = os.path.join(args.baseline_dir, "answer_judgement.json")
    args.answer_judgement_others = [os.path.join(other_dir, "answer_judgement.json") for other_dir in args.others_dir]
    if args.model_checkpoint == "":
        args.model_checkpoint = f"../official_model/model.ckpt"
    return args

if __name__ == "__main__":
    args = get_args()
    
    if "run_baseline" in args.tasks:
        run_baseline(args)
    if "run_others" in args.tasks:
        run_others(args)
    if "analyze" in args.tasks:
        analyze_different_conditions(args)