# merge best answer predictions from each hop
# python -m utils.merge_answers irrr/output/prediction_custom_wrong/hop 3 irrr/output/prediction_custom_wrong --input_orig backend/irrr_v2/data/beerqa/beerqa_dev_v1.0_custom_wrong.json
from argparse import ArgumentParser
from collections import Counter, defaultdict
import json
import os
from superdebug import debug
import sys
sys.path.append("")
from backend.utils import answer_matches

def judge_answer(ground_truths, final_predictions, hops_answer, hops):
    answer_juedgement = {}
    final_answer_correct_cnt = 0
    some_hop_answer_correct_cnt = 0
    each_hop_correct_cnt = defaultdict(int)
    confident_hop_hist = defaultdict(int)
    correct_answer_min_hop_hist = defaultdict(int)
    for id in final_predictions:
        ground_truth: list = ground_truths[id]
        final_answer = final_predictions[id]
        answers_each_hop: list = hops_answer[id]

        final_answer_correct = answer_matches(final_answer, ground_truth)
        confident_hop = hops[id]
        confident_hop_hist[confident_hop] += 1
        final_answer_correct_cnt += int(final_answer_correct)
        answers_each_hop_correct = []
        for hop_n_1, hop_answer in enumerate(answers_each_hop):
            answers_each_hop_correct.append(answer_matches(hop_answer, ground_truth))
            each_hop_correct_cnt[hop_n_1 + 1] += int(answers_each_hop_correct[-1])
        some_hop_answer_correct_cnt += int(any(answers_each_hop_correct))
        correct_answer_min_hop = min([hop_i + 1 if hop_answer_correct else 9999 for (hop_i, hop_answer_correct) in enumerate(answers_each_hop_correct)])
        correct_answer_min_hop_hist[correct_answer_min_hop] += 1
        answer_juedgement[id] = {
            "ground_truth": ground_truth,

            "final_answer": final_answer,
            "final_answer_correct": final_answer_correct,
            "confident_hop": confident_hop,

            "answers_each_hop": answers_each_hop,
            "answers_each_hop_correct": answers_each_hop_correct,
            "correct_answer_min_hop": correct_answer_min_hop,
        }
    print("final_answer_correct_rate:", 100 * final_answer_correct_cnt / len(final_predictions))
    print("some_hop_answer_correct_rate:", 100 * some_hop_answer_correct_cnt / len(final_predictions))
    print("each_hop_correct_cnt:", each_hop_correct_cnt)
    print("confident_hop_hist:", confident_hop_hist)
    print("correct_answer_min_hop_hist:", correct_answer_min_hop_hist)
    return answer_juedgement




def main(args):
    final_predictions = {}
    final_path = {}
    hops = {}
    hops_answer = {}
    hops_conf = {}
    hops_conf_all = {}
    hops_title_all = {}
    
    PAN = args.pan
    THRES = args.thres
    
    print ("PAN : " + str(PAN) +  ", THRES : " + str(THRES))
    if not os.path.exists(os.path.join(f"{args.input_prefix}{max(1, args.init_hop)}", "answer_predictions.json")):
        print ("No answer predictions for hop " + str(max(1, args.init_hop)))
        return 
    for hop_answer in range(max(1, args.init_hop), args.max_hops + 1): # do not include hop0 since it is meaningless
        with open(os.path.join(f"{args.input_prefix}{hop_answer}", "answer_predictions.json")) as f:
            pred = json.load(f)
        with open(os.path.join(f"{args.input_prefix}{hop_answer}", "null_odds.json")) as f:
            conf = json.load(f)            
        with open(os.path.join(f"{args.input_prefix}{hop_answer}", "predictions_titles.json")) as f:
            path = json.load(f)
            
        for id in pred.keys():
            if hop_answer == max(1, args.init_hop):
              hops_answer[id] = [""] * (max(1, args.init_hop) - 1)
              hops_conf[id] = [] # confidence
              hops_conf_all[id] = [9999] * (max(1, args.init_hop) - 1)
              hops_title_all[id] = [None] * (max(1, args.init_hop) - 1)
              
            conf_p = conf[id] + hop_answer*PAN
            if len(hops_conf[id]) == 0 or conf_p < hops_conf[id][-1]:
              final_predictions[id] = pred[id]
              final_path[id] = path[id] 
              hops[id] = hop_answer
              hops_conf[id].append(conf_p)               
            
            hops_title_all[id].append(path[id])
            hops_conf_all[id].append(conf_p)
            hops_answer[id].append(pred[id])
    # debug(final_predictions = final_predictions, final_path=final_path, hops=hops, hops_title_all=hops_title_all, hops_conf_all=hops_conf_all, hops_answer=hops_answer)
        # DEBUG: 6 vars: ['final_predictions', 'final_path', 'hops', 'hops_title_all', 'hops_conf_all', 'hops_answer'], at backend/irrr_v2/utils/merge_answers.py:46 main
        # 0 / 1.  final_predictions dict {.} with 1 keys ['686c81517e3167a0acacb5cedb423740d31122cc']
        #     686c81517e3167a0acacb5cedb423740d31122cc str len 5: China
        # 1 / 2.  final_path dict {.} with 1 keys ['686c81517e3167a0acacb5cedb423740d31122cc']
        #     686c81517e3167a0acacb5cedb423740d31122cc list size: 1 val: ['Elon Mask']
        # 2 / 3.  hops dict {.} with 1 keys ['686c81517e3167a0acacb5cedb423740d31122cc']
        #     686c81517e3167a0acacb5cedb423740d31122cc num val: 1
        # 3 / 4.  hops_title_all dict {.} with 1 keys ['686c81517e3167a0acacb5cedb423740d31122cc']
        #     686c81517e3167a0acacb5cedb423740d31122cc list size: 3 [...]
        #     item 0:  list size: 1 val: ['Elon Mask']
        #     item 1:  list size: 2 val: ['Elon Mask', 'Elon Mask']
        #     item 2:  list size: 3 val: ['Elon Mask', 'Elon Mask', 'Elon Mask']
        # 4 / 5.  hops_conf_all dict {.} with 1 keys ['686c81517e3167a0acacb5cedb423740d31122cc']
        #     686c81517e3167a0acacb5cedb423740d31122cc list size: 3 val: [3.722910785675049, 12.563328552246094, 17.463328552246097]
        # 5 / 6.  hops_answer dict {.} with 1 keys ['686c81517e3167a0acacb5cedb423740d31122cc']
        #     686c81517e3167a0acacb5cedb423740d31122cc list size: 3 val: ['China', 'China', 'China']
    for id in hops_answer.keys():
      for hop_i, hop_answer in enumerate(hops_answer[id]):
        if hops_conf_all[id][hop_i] < THRES: #^ use the last hop that has a confidence lower than THRES (more and more confident)
          final_predictions[id] = hop_answer
          hops[id]=hop_i+1 
          final_path[id] = hops_title_all[id][hop_i]
          break
    
    # debug(final_predictions=final_predictions, final_path=final_path, hops=hops)
    #     DEBUG: 3 vars: ['final_predictions', 'final_path', 'hops'], at backend/irrr_v2/utils/merge_answers.py:55 main
    #     0 / 7.  final_predictions dict {.} with 1 keys ['686c81517e3167a0acacb5cedb423740d31122cc']
    #         686c81517e3167a0acacb5cedb423740d31122cc str len 5: China
    #     1 / 8.  final_path dict {.} with 1 keys ['686c81517e3167a0acacb5cedb423740d31122cc']
    #         686c81517e3167a0acacb5cedb423740d31122cc list size: 1 val: ['Elon Mask']
    #     2 / 9.  hops dict {.} with 1 keys ['686c81517e3167a0acacb5cedb423740d31122cc']
    #         686c81517e3167a0acacb5cedb423740d31122cc num val: 1
    with open(os.path.join(args.output_prefix, "answer_predictions.json"), 'w') as f:
        json.dump({'answer': final_predictions}, f)

    with open(os.path.join(args.output_prefix, "answer_predictions_titles.json"), 'w') as f:
        json.dump(final_path, f)
        
    print(Counter(hops.values()))
    print(sum(hops.values()) / len(hops))

    if args.input_orig != "":
        ground_truths = {}
        input_orig = json.load(open(args.input_orig, "r"))
        for qa_data in input_orig["data"]:
            ground_truths[qa_data["id"]] = qa_data["answers"]
        answer_juedgement = judge_answer(ground_truths, final_predictions, hops_answer, hops)
        with open(os.path.join(args.output_prefix, "answer_judgement.json"), 'w') as f:
            json.dump(answer_juedgement, f)
        debug(f"answer_judgement saved in {os.path.join(args.output_prefix, 'answer_judgement.json')}")
    

if __name__ == '__main__':
    parser = ArgumentParser()

    parser.add_argument('input_prefix', type=str, help="Prefix for hop output directories")
    parser.add_argument('max_hops', type=int)
    parser.add_argument('output_prefix', type=str, help="Output dir")
    parser.add_argument('--init_hop', type=int, default=0)


    parser.add_argument('--pan', type=float, default=4.9)
    parser.add_argument('--thres', type=float, default=4.9)
    parser.add_argument('--input_orig', type=str, default="")
    
    args = parser.parse_args()
    args.max_hops = max(args.init_hop, args.max_hops)

    main(args)
