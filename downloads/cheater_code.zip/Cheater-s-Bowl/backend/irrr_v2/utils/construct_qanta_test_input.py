from argparse import ArgumentParser
import json
from superdebug import debug
import hashlib
# from scripts.index_processed_wiki import STOPWORDS
# from scripts.gen_hotpot_hop123_imp_ngram_2 import _has_connection

def main(args):
    with open(args.input_file) as f:
        data = json.load(f)["questions"]

    output_data = []

    for d in data:
        for start_index, end_index in d["tokenizations"]:
            output_data.append({
                'id': hashlib.sha1(d['text'][start_index:end_index].encode('utf-8')).hexdigest(),
                "src": "hotpotqa",
                "answers": [
                    d["answer"]
                ],
                'question': d['text'][start_index:end_index],
                "context": []
            })

    with open(args.output_file, 'w') as f:
        json.dump({
            "version": "1.0",
            "split": "test",
            'data': output_data
        }, f)

if __name__ == '__main__':
    parser = ArgumentParser()

    parser.add_argument('--input_file', default = "data/qanta/qanta.test.example.json")
    parser.add_argument('--output_file', default = "data/beerqa/qanta.test.example.json")
    parser.add_argument('--include_question', default=False, action='store_true', help="Include question before the context for the query generator")

    args = parser.parse_args()

    main(args)
