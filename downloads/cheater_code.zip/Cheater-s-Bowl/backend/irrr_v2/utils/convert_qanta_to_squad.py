from argparse import ArgumentParser
import json
from superdebug import debug
from search.search import single_query_for_context, bulk_query_for_context
import re
from tqdm import tqdm
import unidecode
# from scripts.index_processed_wiki import STOPWORDS
def filter_answer(answer):
    filtered_answer = unidecode.unidecode(answer)
    if answer.endswith(")"):
        filtered_answer = answer.split("(")[0]
    # if filtered_answer.endswith("]"):
    filtered_answer = filtered_answer.split("[")[0]
    filtered_answer = filtered_answer.split(" or ")[0]
    filtered_answer = filtered_answer.split(";")[0]
    filtered_answer = filtered_answer.strip()
    return filtered_answer
def retrieve_construct_context(qas): # question, filtered_answer):
    ress = bulk_query_for_context(qas)
    contexts = []
    for i in range(len(qas)):
        res = ress[i:i+2]
        question, filtered_answer = qas[i]
        if len(res) == 0 and len(filtered_answer.split()) == 1 and filtered_answer.endswith("s"):
            res = single_query_for_context(question, filtered_answer[:-1])
        if len(res) == 0:
            debug(question=question, filtered_answer=filtered_answer, res = res)
        context = []
        for paragraph in res:
            context.append(f'{paragraph["title"]} [et] {paragraph["text"]}')
        context = ' [SEP] '.join(context)
        contexts.append(context)
    return contexts


def construct_official_context_dict(args):
    contexts = open(args.context_file, "r")
    context_dict = {}
    debug("Loading context file...")
    while True:
        line = contexts.readline()
        if not line:
            break
        context = json.loads(line)
        context_dict[context["qanta_id"]] = []
        for paragraph in context["annotated_paras"][0]:
            context_dict[context["qanta_id"]].append(paragraph["paragraph"])
        context_dict[context["qanta_id"]] = " [et] " + " [SEP] [et] ".join(context_dict[context["qanta_id"]])
    return context_dict

def main(args):
    with open(args.input_file) as f:
        data = json.load(f)["questions"]

    context_dict = construct_official_context_dict(args)

    output_data = []

    for d in tqdm(data):
        qid = d['qanta_id']
        qas = []
        for start_index, end_index in d["tokenizations"]:
            question = unidecode.unidecode(d['text'][:end_index])
            # if end_index - start_index < 10:
            #     continue
            # answer = d["answer"]
            # filtered_answer = filter_answer(answer)
            filtered_answer = unidecode.unidecode(d['page'].split("(")[0].strip())
            qas.append((question, filtered_answer))
        
        # contexts = retrieve_construct_context(qas)
        for i, (question, filtered_answer) in enumerate(qas):
            # context = contexts[i]
            context = context_dict[qid] # use official context instead
            answers = []
            try:
                for m in re.finditer(filtered_answer, context):
                    answers.append({"text": filtered_answer, "answer_start": m.start()})
            except Exception as e:
                debug(question=question, filtered_answer=filtered_answer, context=context, e=e)
            if len(answers) == 0:
                answers = [{"text": filtered_answer, "answer_start": -1}]
            output_data.append({
                'title': '',
                'paragraphs': [{
                    'context': context,
                    'query': "",
                    'qas': [{
                        'id': qid,
                        'question': question,
                        'answers':  answers,
                        'is_impossible': False, # TODO: retrieve the context from wikipage of the answer (overlap is ok)
                        'is_last_non_gt': True,
                        'is_alternative': False
                    }]
                }]
            })

    with open(args.output_file, 'w') as f:
        json.dump({'data': output_data}, f)


if __name__ == '__main__':
    parser = ArgumentParser()

    # parser.add_argument('--input_file', default = "data/qanta/qanta.train.2018.04.18.json") # "data/qanta/qanta.test.example.json")
    parser.add_argument('--input_file', default = "data/qanta/qanta.dev.2018.04.18.json") # "data/qanta/qanta.test.example.json")
    parser.add_argument('--context_file', default = "data/qanta/qanta.dev.paragraphs.2018.04.18.jsonl")
    
    # parser.add_argument('--output_file', default = "data/qanta/trainset/squadified_qanta.train.2018.04.18.json") # "data/qanta/trainset_sample/qanta_example.json")
    parser.add_argument('--output_file', default = "data/qanta/devset/squadified_qanta.dev.2018.04.18.json") # "data/qanta/trainset_sample/qanta_example.json")
    parser.add_argument('--include_question', default=False, action='store_true', help="Include question before the context for the query generator")

    args = parser.parse_args()

    main(args)
