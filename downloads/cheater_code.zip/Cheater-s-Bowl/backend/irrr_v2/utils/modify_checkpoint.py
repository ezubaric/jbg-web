# -*- coding:utf-8 -*-
# cd backend/irrr_v2 && python utils/modify_checkpoint.py
from superdebug import debug
import re
from tensorflow.python.training import py_checkpoint_reader
import tensorflow as tf
import argparse
import os


def get_tensors_in_checkpoint_file(file_name, do_print=False):
    reader = py_checkpoint_reader.NewCheckpointReader(file_name)

    var_to_shape_map = reader.get_variable_to_shape_map()
    var_to_dtype_map = reader.get_variable_to_dtype_map()
    var_to_shape_map = {name: shape for (name, shape) in tf.train.list_variables(file_name)}

    debug(_CHECKPOINTABLE_OBJECT_GRAPH_in_map = "_CHECKPOINTABLE_OBJECT_GRAPH" in var_to_shape_map)
    if do_print:
        for key, value in sorted(var_to_shape_map.items()):
            debug(key=key, type=var_to_dtype_map[key].name, value=value)
            debug(reader.get_tensor(key))
    return var_to_shape_map, var_to_dtype_map

def rename_vars(checkpoint_path, rename_var_src, rename_var_dst):
    vars = {}
    reader = tf.train.load_checkpoint(checkpoint_path)
    dtypes = reader.get_variable_to_dtype_map()
    for key in dtypes.keys():
        new_key = re.sub(rename_var_src, rename_var_dst, key)
        if new_key != key:
            print('Renaming %s to %s.' % (key, new_key))
        vars[new_key] = tf.Variable(reader.get_tensor(key))
    return vars
def convert_tf1_to_tf2(vars, checkpoint_path, save_path):
    saver = tf.compat.v1.train.Saver(vars)
    path_v1 = saver.save(sess=None, save_path=save_path.format("1"))
    path_v2 = tf.train.Checkpoint(vars=vars).save(save_path.format("2"))
    dir_ckpt = os.path.dirname(checkpoint_path); dir_v1 = os.path.dirname(path_v1); dir_v2 = os.path.dirname(path_v2)
    for other_file in os.listdir(os.path.dirname(checkpoint_path)):
        if ".ckpt" not in other_file and other_file != "checkpoint":
            os.system("cp {} {}".format(os.path.join(dir_ckpt, other_file), os.path.join(dir_v1, other_file)))
            os.system("cp {} {}".format(os.path.join(dir_ckpt, other_file), os.path.join(dir_v2, other_file)))

    return path_v1, path_v2


def get_args():
    parser = argparse.ArgumentParser(description='parameters to rename tensorflow variable!')
    parser.add_argument('--ckpt_path', type=str, default = "irrr_model/model.ckpt", help='the ckpt file where to load.')
    parser.add_argument('--ref_path', type=str, default = "output/train_qanta_sample/model.ckpt-14000", help='the ckpt file to reference.')
    parser.add_argument('--save_path', type=str, default = "irrr_model_v{}/model.ckpt", help='the ckpt file where to save.')
    parser.add_argument('--rename_var_src', type=str, default = "loss_scale", help="""Comma separated list of replace variable from""")
    parser.add_argument('--rename_var_dst', type=str, default = "current_loss_scale", help="""Comma separated list of replace variable to""")
    args = parser.parse_args()
    return args

if __name__ == '__main__':
    args = get_args()

    var_to_shape_map_1, var_to_dtype_map_1 = get_tensors_in_checkpoint_file(file_name=args.ckpt_path, do_print=False)
    var_to_shape_map_2, var_to_dtype_map_2 = get_tensors_in_checkpoint_file(file_name=args.ref_path, do_print=False)

    var_only_1 = {k: v for k, v in var_to_shape_map_1.items() if k not in var_to_shape_map_2 and "layer_normalization" not in k and "LayerNorm" not in k}
    var_only_2 = {k: v for k, v in var_to_shape_map_2.items() if k not in var_to_shape_map_1 and "layer_normalization" not in k and "LayerNorm" not in k}
    debug(var_only_1=var_only_1, var_only_2 = var_only_2)

    args.checkpoint_dir = os.path.dirname(args.ckpt_path)
    args.save_dir = os.path.dirname(args.save_path)

    vars = rename_vars(args.ckpt_path, args.rename_var_src, args.rename_var_dst)
    converted_path = convert_tf1_to_tf2(vars, args.ckpt_path, args.save_path)
    debug(converted_path=converted_path)

