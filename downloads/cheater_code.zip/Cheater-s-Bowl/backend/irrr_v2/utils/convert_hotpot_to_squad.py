from argparse import ArgumentParser
import json
from superdebug import debug
import re
# from scripts.index_processed_wiki import STOPWORDS
# from scripts.gen_hotpot_hop123_imp_ngram_2 import _has_connection

def main(args):
    with open(args.input_file) as f:
        data = json.load(f)["data"]

    output_data = []

    for d in data:
        try:
            last_non_gt = True
            last_retrieved = None

            if 'supporting_facts' in d:
                supporting_facts_left = d['supporting_facts']
                if len(d['retrieved_context']) > 0:
                    last_retrieved = d['retrieved_context'][-1]
                    if 'wiki_para_id' in d:
                        if len(supporting_facts_left) > 0 and last_retrieved['docid'] == d['wiki_para_id']:
                            last_non_gt = False
                    else:
                        if any(last_retrieved['title'] == x[0] for x in supporting_facts_left):
                            last_non_gt = False
            d['context'] = ' [SEP] '.join([f"{x[0]} [et] {''.join(x[1])}" for x in d['context']])
            answer = []
            if isinstance(d['answers'], list):
                # debug()
                if any(a in d['context'] for a in d['answers']):
                    for a in set(d['answers']):
                        for m in re.finditer(a, d['context']):
                            answer.append({"text": a, "answer_start": m.start()})
            elif d['answers'] in d['context']:
                # debug()
                if d['answers'] in ['yes', 'no']:
                    if 'supporting_facts' in d and len(d['supporting_facts']) == 0:
                        answer.append({"text": d['answers'], "answer_start": -1})
                else:
                    for m in re.finditer(d['answers'], d['context']):
                        answer.append({"text": d['answers'], "answer_start": m.start()})

            if len(answer) == 0:
                answer.append({"text": "", "answer_start": -1})

            output_data.append({
                'title': '',
                # 'retrieved_context': d['retrieved_context'],
                'paragraphs': [{
                    'context': d['context'],
                    # 'context': d['context'] if not args.include_question else (" [SEP] ".join([x for x in [d['question'], d['context']] if len(x) > 0])),
                    'query': "",
                    # 'query': d['query'],
                    # 'query_short': d['query_short'],
                    # 'prev_query': d.get('prev_query', ''),
                    # 'prev_query_short': d.get('prev_query_short', ''),
                    'qas': [{
                        'id': d['id'],
                        'question': d['question'],
                        'answers':  answer,
                        'is_impossible': False, # 'supporting_facts' not in d or len(d['supporting_facts']) > 0,
                        'is_last_non_gt': last_non_gt,
                        'is_alternative': False if last_retrieved is None else _has_connection(last_retrieved, d['last_target_para']['title'], True)
                    }]
                }]
            })

            if 'supporting_facts' in d:
                output_data[-1]['supporting_facts'] = d['supporting_facts']
        except Exception as e:
            debug(e)
            
    with open(args.output_file, 'w') as f:
        json.dump({'data': output_data}, f)

if __name__ == '__main__':
    parser = ArgumentParser()

    parser.add_argument('--input_file', type=str, default = "data/beerqa/beerqa_train_v1.0.json")
    parser.add_argument('--output_file', type=str, default = "data/beerqa/trainset/squadified_beerqa_train_v1.0.json")
    parser.add_argument('--include_question', default=False, action='store_true', help="Include question before the context for the query generator")

    args = parser.parse_args()

    main(args)
