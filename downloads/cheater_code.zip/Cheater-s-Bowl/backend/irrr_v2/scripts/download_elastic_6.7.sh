# download elasticsearch
wget https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-6.7.0.tar.gz
# extract
tar -xzvf elasticsearch-6.7.0.tar.gz
# clean up
rm elasticsearch-6.7.0.tar.gz
