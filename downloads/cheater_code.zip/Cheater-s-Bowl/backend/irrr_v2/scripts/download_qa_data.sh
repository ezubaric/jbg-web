mkdir -p downloads/beerqa
wget https://nlp.stanford.edu/projects/beerqa/beerqa_dev_v1.0.json -O downloads/beerqa/beerqa_dev_v1.0.json
wget https://nlp.stanford.edu/projects/beerqa/beerqa_test_questions_v1.0.json -O downloads/beerqa/beerqa_test_questions_v1.0.json