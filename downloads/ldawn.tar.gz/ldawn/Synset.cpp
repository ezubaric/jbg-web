
#include "Synset.h"
#include <assert.h>
#include <iostream>

using namespace std;

Synset::Synset(int nw, int off, double alpha)
{
	assert(nw >= 0);
	assert(off > 0);
	assert(alpha >= 0);

  this->hungWords = 0;
	this->numberPaths = 0;
	this->numberWords = nw;
	this->alphaScale = alpha;
	this->ID = off;
	if(this->numberWords > 0)
    this->words = (int *)malloc(nw * sizeof(int));
	this->dirichletNormalizer=0;

	for(int i=0; i<nw; i++)
	{
		this->words[i] = -1;
	}
}

double Synset::getDirichletNormalizer()
{
	return this->dirichletNormalizer;
}

void Synset::printSynsetStatus()
{
	int i;
	int nc = this->getNumberChildren();

	cout << "Synset " << this->ID << " has " << this->numberWords << " words and " <<
		nc << " children." << endl;
	if(nc > 0)
	{
		cout << "Words: ";
		for(i=0; i<this->numberWords; i++)
			cout << this->words[i] << " ";
		cout << endl;
	}
	if(nc > 0)
	{
		cout << "Children: ";
		for(i=0; i<nc; i++)
			cout << this->children[i] << " ";
		cout << endl;
	}
	cout << endl;
}

void Synset::changeAlpha(double newAlpha)
{
  this->alphaScale = newAlpha * this->alphaScale;
}

double Synset::getAlpha(int i)
{
	assert(i < (int)this->alpha.size());
	double val = this->alpha[i];
	if(val > this->alphaScale)
	{
		cout << "Synset " << this->ID << "(" << i << ") : " << this->alpha[i] << endl;
	}
	//assert(val <= this->alphaScale);
	return val;
}


Synset::~Synset()
{
  if(this->numberWords > 0)
    delete this->words;
}

int Synset::getWord(int i)
{
  if(i >= 0 && i < this->numberWords)
    return words[i];
  else
    return -1;
}

int Synset::getChild(int i)
{
  if(i >= (int)this->children.size())
    cerr << "Tried to access the " << i << "th child of " << 
	this->ID << ", but it only has " << this->getNumberChildren() << 
      " words." << endl;
	assert(i < (int)this->children.size());
	return this->children[i];
}

void Synset::addAlpha(double alpha)
{
	this->alpha.push_back(alpha);
}

/*
 * This adds a child, and adds an alpha if alpha is greater 
 * than zero
 */
void Synset::addChild(int childID, double alpha)
{
	//cout << "Added child " << childID << " to " << this->ID << endl;
	this->children.push_back(childID);

	// In the case where alpha is less than zero, we
	// ignore it.  This seems odd, but we need to
	// be able to sum over multiple counts when
	// we hang multiple words off of a single synset
	//
	// Thus, we have to add alpha later.  If this doesn't
	// happen, it will break an assertion in the 
	// normalization of alpha.
	if(alpha >= 0)
		this->alpha.push_back(alpha);
}

/*
 * Normalize 
 */
void Synset::finalizeAlphas()
{
	
	// We must have the same number of alphas as children
	if(this->alpha.size()!=this->children.size())
		cout << "Synset " << this->ID << " disagreed children:" << this->children.size() << " alphas:" << this->alpha.size() << endl;
	assert(this->alpha.size()==this->children.size());
	int numAlphas = (int)this->alpha.size();

	double sum=0;
	unsigned int i;

	if(numAlphas==1)
	{
		// This might seem silly because this preprocessing step
		// should still work, but we can get floating point errors 
		// if the alphaScale is too small, so if there's only one 
		// child, just short-circuit
		this->alpha[0]=this->alphaScale;
	}
	else
	{
		for(i=0; i<numAlphas; i++)
			sum += this->alpha[i] + ALPHA_EPSILON;
		for(i=0; i<numAlphas; i++)
		{
			double val = this->alphaScale * (this->alpha[i] + ALPHA_EPSILON) / sum;

			// We can get floating point errors for things very close to the max,
			// which will break assertions later
			if(val > this->alphaScale)
			{
				cout << "Off by " << val - this->alphaScale << endl;
				val = this->alphaScale;
			}

			this->alpha[i] = val;
		}
	}

	this->dirichletNormalizer = lgamma(this->alphaScale);
	for(i=0; i<numAlphas; i++)
		this->dirichletNormalizer -= lgamma(this->alpha[i]);
	if(my_isnan(this->dirichletNormalizer))
		cerr << "Bad alpha for " << this->ID;
	assert(!my_isnan(this->dirichletNormalizer));
	//cout << this->alphaProduct << endl;
}

void Synset::addChild(int childID)
{
  //cout << "Added child " << childID << " to " << this->ID << endl;
  this->children.push_back(childID);
  this->alpha.push_back(1.0);
}

// Tells the synset we're hanging another node off
// with a word
void Synset::hangWord()
{
  this->hungWords++;
}

int Synset::getHungWords()
{
  return this->hungWords;
}

int Synset::getNumberChildren()
{
	return (int)this->children.size();
}

void Synset::addWord(int index, int word)
{
	assert(this->words[index]==-1);
	assert(index < this->numberWords);
	this->words[index]=word;
}
