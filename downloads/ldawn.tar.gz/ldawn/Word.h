
#ifndef WORD_INCLUDED
#define WORD_INCLUDED

#include "Path.h"
#include <vector>
#include <assert.h>
#include <map>

using namespace std;

struct Word
{
	vector <Path*> paths;
	map <int, int> synsets;

	Path * getPath(int id);
	int getSynsetID(int synset);

	int numberSynsets();
	int numberPaths();

	void printSynsets();
	void sortPaths();
	void insertSynset(int synset);
    void printPaths(int id);
};


#endif
