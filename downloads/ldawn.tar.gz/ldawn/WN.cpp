
#include "WN.h"
#include <fstream>
#include <iostream>
#include <assert.h>
#include <vector>
#include <string>
#include <set>

using namespace std;

/*
 * 
 */
WN::WN(char * corpus, bool hang, bool varyAlpha, double alphaScale, char * alphaFileName, std::set<int> debug)
{
  this->varyAlphaWithDepth = varyAlpha;
  this->debug_words = debug;
  
  // Add the debug words "STARLING" and "CRANE"
  //this->debug_words.insert(3199);
  //this->debug_words.insert(29406);

 
  // Toy corpus
  //this->debug_words.insert(0);
  //this->debug_words.insert(2);
  //this->debug_words.insert(3);
  
  // Man
  //this->debug_words.insert(39045);
  
  // Time
  //this->debug_words.insert(46442);
  
  this->numberSynsets = 0;
  this->hangWords = hang;
  
  this->readWords((string(corpus) + ".voc").c_str());
  cout << "Done reading in vocabulary file of " << this->vocabSize << " words." << endl;
  this->readSynsets((string(corpus) + ".id").c_str(), 
                    (string(corpus) + ".words").c_str(), 
                    alphaScale,
                    alphaFileName);
  cout << "Done creating space for synsets with alpha of " << alphaScale 
       << ", now reading in links" << endl;
  this->readLinks((string(corpus) + ".links").c_str(), alphaFileName);
  cout << "Done creating links, now we build the paths for each word" << endl;
  int md = createPaths();
  cout << "Created paths of maximum length " << md << "." << endl;
  
  int i;

  
  double alphaCutoff = ALPHA_CUTOFF * alphaScale;
  

  // We find other synsets that are highly suggested by the paths
  // we're already following
  set<int> strong_debug;
  
  for(i=0; i<this->numberSynsets; i++)
    {
      this->synsets[i]->finalizeAlphas();
      
      // We need to fix up the debug to know what's going on
      if(has(i, this->debug_synsets))
        {
          int j;
          for(j=0; j<this->synsets[i]->getNumberChildren(); j++)
            {
              double alphaVal = this->synsets[i]->getAlpha(j);
              if(alphaVal > alphaCutoff)
                {
                  //this->synsets[i]->finalizeAlphas();
                  cout << "Adding synset:" << this->synsets[i]->getChild(j) << " (" << alphaVal << ") " << endl;
                  strong_debug.insert(this->synsets[i]->getChild(j));
                }
            }
        }
    }
  
  set<int>::iterator syn;
  
  // Put the new debug words into the set
  for(syn=strong_debug.begin(); syn!=strong_debug.end(); syn++)
    {
      this->debug_synsets.insert(*syn);
      this->addDebugChildren(*syn);
    }
  
}

void WN::sortPaths()
{
  int i;
  for(i=0; i<this->vocabSize; i++)
  {
    if(this->pathList[i]->numberPaths()>0)
      this->pathList[i]->sortPaths();
  }
}

void WN::addDebugChildren(int parent)
{
  int j;
  for(j=0; j<this->synsets[parent]->getNumberChildren(); j++) {
    int child = this->synsets[parent]->getChild(j);
    if(this->synsets[child]->ID==this->synsets[parent]->ID) {
      this->debug_synsets.insert(child);
      //cout << "Adding " << this->synsets[p->synset[i]]->getChild(j)  << "(" << this->synsets[this->synsets[p->synset[i]]->getChild(j)]->ID << ")" << " to debug." << endl;
    }
  }
}

void WN::addDebugPath(Path * p) {
  //p->print();
  int i;
  for(i=0; i<=p->getLength(); i++) {
    //cout << "Adding *" << p->synset[i] << "(" << this->synsets[p->synset[i]]->ID << ")" << " to debug." << endl;
    this->debug_synsets.insert(p->synset[i]);
    // We also want to add all the children that are words
    this->addDebugChildren(p->synset[i]);
  }
}

void WN::readWords(const char * vocabFile)
{
  ifstream infile (vocabFile, std::ios_base::in);
  string line;
  while (getline(infile, line, '\n'))
  {
	  //cout << line << endl;
	  this->wordList.push_back (line);
  }
  this->vocabSize = (int)this->wordList.size();
}

/*
 * Fills the debug words with the words from
 * a document (and those only)
 */
void WN::setDebug(doc_t * d)
{
	this->debug_synsets.clear();
	this->debug_words.clear();
	int i, j;

	for(i=0; i<d->nterms; i++)
	{
		this->debug_words.insert(d->word[i]);
		for(j=0; j<this->pathList[d->word[i]]->numberPaths(); j++)
		{
			this->addDebugPath(this->pathList[d->word[i]]->paths[j]);
		}
	}
}

WN::~WN()
{
	int i;
  // For some reason it seems to crash on the last
  // one ... this is a bit of a hack
	for(i=0; i<this->numberSynsets; i++)
  {
		delete this->synsets[i];
  }
  cout << "Done deleting.";
	delete synsets;
}

/*
 * Prints all the synsets that we're going to debug
 */
void WN::printDebug()
{
	set<int>::iterator i;
	int count=0;

	cout << "DEBUG SYNSETS(";
	for(i=debug_words.begin(); i!=debug_words.end(); i++)
	{
		cout << this->wordList[*i] << " ";
		count++;
	}
	cout << ") TOTAL = " << count << ": " << endl;
	count = 0;

	/*
	for(i=debug_synsets.begin(); i!=debug_synsets.end(); i++)
	{
		cout << *i << " ";
		count++;
	}
	*/
	cout << "(TOTAL SYNSETS: " << count << ")" << endl;
}

int WN::createPaths()
{
	int i;
	vector <int> traversed;
	vector <int> nextPointers;


	this->pathList = (Word**)malloc(this->vocabSize * sizeof(Word*));

	if(!this->pathList)
	{
		cerr << "Could not allocate memory for paths." << endl;
		exit(0);
	}

	for(i=0; i<this->vocabSize; i++)
	{
		this->pathList[i]=new Word();
	}

	cout << "Done creating lists for the paths." << endl;

  int maxDepth = this->depthFirstSearch(traversed, nextPointers, 0, 0);
  this->sortPaths();
	return maxDepth;
}

int WN::depthFirstSearch(vector<int>& traversed, 
						 vector<int>& nextPointers,
						 int depth, int rootSynset)
{
	int maxDepth=depth;
	int i;

	assert(rootSynset >= 0 && rootSynset < this->numberSynsets);

	// We visit the starting node
	traversed.push_back(rootSynset);
	this->synsets[rootSynset]->numberPaths++;

  if(this->varyAlphaWithDepth && this->synsets[rootSynset]->numberPaths==1)
  {
    this->synsets[rootSynset]->changeAlpha(1.0 / ((double)depth + 1.0));
  }

	/*
	 * We create a path corresponding to this walk and
	 * add it to all of the words in this synset
	 */
	//printPath(traversed, nextPointers);

	Path * p = new Path(traversed, nextPointers);
	for(i=0; i<this->synsets[rootSynset]->numberWords; i++)
	{
		int word = synsets[rootSynset]->getWord(i);
		assert(this->validatePath(p, word));
    //cout << "Word: " << word << " " << this->wordList[word] << endl;
		this->pathList[word]->paths.push_back(p);
		this->pathList[word]->insertSynset(this->synsets[rootSynset]->ID);
		if(has(word, this->debug_words))
		{
      //cout << "Adding debug path of length " << p->getLength() << endl;
			this->addDebugPath(p);
		}
		//this->pathList[synsets[rootSynset]->words[i]]->
		//		printPaths(synsets[rootSynset]->words[i]);
	}
	
	/*
	 * We now follow that node's children
	 */
	for (i=0; i<this->synsets[rootSynset]->getNumberChildren(); i++) 
	{
		nextPointers.push_back(i);
		int childDepth = this->depthFirstSearch
				(traversed, nextPointers, depth + 1, 
				 this->synsets[rootSynset]->getChild(i));
		nextPointers.pop_back();

		if (childDepth > maxDepth)
			maxDepth = childDepth;
	}

	traversed.pop_back();
	return maxDepth;
}

bool WN::validatePath(Path * p, int word)
{
	int i;
	bool valid = true;
	for(i=0; valid && i<p->getLength()-1; i++)
	{
		valid = valid && 
			this->synsets[p->synset[i]]->getChild(p->nextIndex[i]) == p->synset[i+1];
	}
	if(!valid)
	{
		cout << "Error in link from " << this->synsets[p->synset[i]]->ID << " to " << 
			this->synsets[p->synset[i]]->ID << " for " << word << "." << endl;
	}

	return valid;
}

/*
 * Returns the minimum number of nodes required to get from
 * synsetA to synsetB over all of the paths of a given
 * word.  Used to calculate the distance between predictions.
 */
int WN::distance(int word, int SynsetA, int SynsetB)
{
	Word * w = this->pathList[word];
	int i,j;
	int distance = MAX_PATH;
	int numberPaths = w->numberPaths();

	for(i=0; i<numberPaths; i++)
	{
		Path * p1 = w->getPath(i);
		int end1 = this->getSynset(p1->lastSynset())->ID;
		if(end1 != SynsetA)
			continue;

		for(j=0; j<numberPaths; j++)
		{
			Path * p2 = w->getPath(j);
			int end2 = this->getSynset(p2->lastSynset())->ID;
			if(end2 != SynsetB)
				continue;

			int newDistance = p1->distance(p2);
	

			if(newDistance < distance)
				distance = newDistance;
		}
	}

	if(distance >= MAX_PATH)
		cout << word << " " << this->wordList[word] << SynsetA << " " << SynsetB << endl;
	assert(distance < MAX_PATH);

	// Corrects for how we hang words off of synsets
	// (adds in an extra link)
	if(distance > 0)
	    distance-=2;

	return distance;
}

void WN::readLinks(const char *linksFilename, const char * alphaFilename)
{
	ifstream linkFile;
	ifstream alphaFile;
	int synsetID;
	int childID;

	int i;
	map <int, double> alpha;

	bool loadAlpha=false;

	if(strcmp(alphaFilename, ""))
		loadAlpha = true;

	if(loadAlpha)
	{
	  cout << "Loading alpha" << endl;
		int id=-1;
		double val;
		alphaFile.open(alphaFilename);
		for(i=0; i<this->numberSynsets; i++)
		{
			if(id==this->synsets[i]->ID)
				continue;

			id = this->synsets[i]->ID;
			assert(alphaFile >> val);			
			alpha[id]=val;
		}
	}


	// So now we 
	// set up the links
	linkFile.open(linksFilename);

	while(linkFile >> synsetID)
	{
		assert(linkFile >> childID);

		if(childID >= 0)
		{
			int u = this->findID(synsetID);
			int v = this->findID(childID);
			if(v!=-1)
			{
				if(loadAlpha)
					this->synsets[u]->addChild(v, alpha[childID]);
				else
					this->synsets[u]->addChild(v);
			}
			//this->synsets[pos]->printSynsetStatus();
		}
	}
	
}

/*
 * The links are encoded in terms of the offset in 
 * the lexocographer files, but we want the position
 * in the array of synsets, so we perform a binary
 * search.
 */
int WN::findID(int offset)
{
	return this->findID(offset, 0, this->numberSynsets);
}

/*
 * The recursive private function to perform the binary search
 */
int WN::findID(int offset, int l, int r)
{
   if (l <= r) {
       int mid = (l + r) / 2;  // compute mid point.
       if (offset > this->synsets[mid]->ID) 
           return this->findID(offset, mid+1, r);
       else if (offset < this->synsets[mid]->ID) 
           return this->findID(offset, l, mid-1);
       else
	   {
		   // because we hang synsets off, we might 
		   // have more than one synset with the same ID
		   while(mid > 0 && this->synsets[mid-1]->ID==offset)
			   mid--;
           return mid;
	   }
   }
   return -1; // Failed to find ID	
}

/*
 * Creates the synsets and populates the synsets with words
 * this is dependent on the training corpus, as the IDs 
 * of the words have to match up.  This allows us to remove
 * words that will never appear in our corpus
 */
void WN::readSynsets(const char *synsetFilename, const char *wordFilename, double alpha, char * alphaFileName)
{
  int i=0;
  int j=0;
  int numberWords=0;
  int id=0;
  
  ifstream idFile;
  ifstream wordFile;
  ifstream alphaFile;
  double count;
  
  // Do we have to load in alphas from a file?
  bool loadAlpha = false;
  if(strcmp(alphaFileName, "")) {
    loadAlpha = true;
  }
  
  // If so, we're going to have to keep around these 
  // data structures until the synsets get created
  vector <double> alphaWord;
  vector <int> synsetIDs;
  
  /*
   * Count the number of the lines in the file
   */
  idFile.open(synsetFilename);
  while (idFile >> id)  {
    synsetIDs.push_back(id);
    this->numberSynsets++;
  }
  idFile.close();
  
  if(loadAlpha) {
    alphaFile.open(alphaFileName);
    for(i=0; i<this->numberSynsets; i++)
      assert(alphaFile >> count);
    
    for(i=0; i<this->vocabSize; i++) {
      assert(alphaFile >> count);
      alphaWord.push_back(count);
    }
    alphaFile.close();
  }
	
  // If we're hanging words, then we actually have more synsets
  if(this->hangWords) {
    wordFile.open(wordFilename);
    while (wordFile >> numberWords) {
      for(j=0; j<numberWords; j++) {
        int wordId=-1;
        assert(wordFile >> wordId);
        this->numberSynsets++;
      }
    }
    wordFile.close();
    wordFile.clear();
  } else {
    wordFile.open(wordFilename);
    while (wordFile >> numberWords) {
      if(numberWords > 0)
        this->numberSynsets++;
      
      for(j=0; j<numberWords; j++) {
        int wordId=-1;
        assert(wordFile >> wordId);
      }
    }
    wordFile.close();
    wordFile.clear();		
  }
  
  cout << "Read in " << this->numberSynsets << " from  " << synsetFilename << endl;
  
  /*
   * Now that we know how many synsets are in the
   * file, we create space for them
   */
  this->synsets = (Synset**) malloc(this->numberSynsets * sizeof(Synset *));
  if(this->synsets==NULL) {
    cerr << "Could not allocate space for synsets, exiting." << endl;
    exit(0);
  }
  
  wordFile.open(wordFilename);
  i=0;
  int synsetID=0;
  
  while (wordFile >> numberWords) {
    id = synsetIDs[synsetID++];
    double alphaSum = 0;
    
    //cout << "Current synset(" << id << "): " << i << " has " << numberWords << " words" << endl;
    // Now, create a new synset and populate it
    this->synsets[i] = new Synset(0, id, alpha);
    
    // If we're not hanging synsets off and 
    // we have words, we need to create a new
    // node to hold those words
    if(!this->hangWords && numberWords > 0) {
      this->synsets[i+1] = new Synset(numberWords, this->synsets[i]->ID, 0);

      // If we're hanging words and loading alpha, we don't know what value
      // to give alpha
      if(loadAlpha)
        this->synsets[i]->addChild(i+1, -1);
      else
        this->synsets[i]->addChild(i+1);
    }
    
    for(j=0; j<numberWords; j++) {
      int wordId = -1;
      assert(wordFile >> wordId);
      this->synsets[i]->hangWord();
      
      if(this->hangWords) {
        this->synsets[i+j+1] = new Synset(1, this->synsets[i]->ID, 0);
        this->synsets[i+j+1]->addWord(0, wordId);
        
        // Do we tell them the alphas?
        if(loadAlpha)
          this->synsets[i]->addChild(i+j+1, alphaWord[wordId]);	
        else
          this->synsets[i]->addChild(i+j+1);	
        
	
      } else {
        if(loadAlpha) {
          this->synsets[i+1]->addWord(j, wordId);
          alphaSum += alphaWord[wordId];
        } else {
          this->synsets[i+1]->addWord(j, wordId);
        }
      }
    }
    
    if(this->hangWords) {
      // We add one node for the synset itself
      // and one for all of its words
      i += numberWords + 1;
    } else {
      if(numberWords > 0) {
        if(loadAlpha)
          this->synsets[i]->addAlpha(alphaSum);
        // We add one synset for the real synset
        // and for the words
        i+=2;
      }	else {
        i++;
      }
    }
    //this->synsets[i]->printSynsetStatus();
  }
  if(i==this->numberSynsets) {
    cout << "Initialized " << i << " synsets and their member words." << endl;
  } else {
    cerr << "Mismatch in word and id files for nouns:" << i << "!=" << this->numberSynsets << endl;
    assert(i==this->numberSynsets);
  }
  
  wordFile.close();
  synsetIDs.clear();
  
  
}

string WN::getWord(int synset, int word)
{
	int wid = this->synsets[synset]->getWord(word);
	return this->wordList[wid];
}

Synset * WN::getSynset(int id)
{
  if(!(id < this->numberSynsets && id >= 0))
    {
      cout << "BAD SYNSET " << id << endl;
    }
	assert(id < this->numberSynsets && id >= 0);
	return this->synsets[id];
}

/*
 
 Code for testing ... mostly for path length



int main(int argc, char**argv)
{
  int word=0, s1=-1, s2=-1;
  set<int> debug;
  WN * walk = new WN("noun.ID", "combined.words", "noun.links", "combined.voc", false, 1.0, "", debug);


  while(word>=0)
    {
      if(s1 > 0 && s2 > 0)
	{
	  cout << "Distance = " << walk->distance(word, s1, s2) << endl;
	}
      

      cout << "Enter word synset1 synset2 (-1 to stop)" << endl;

      cin >> word;
      cin >> s1;
      cin >> s2;

    }
  delete walk;

}
*/
