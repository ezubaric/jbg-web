
#ifndef SYNSET_INCLUDED
#define SYNSET_INCLUDED

#include <vector>
#include "gsl-wrappers.h"

using namespace std;

class Synset
{
public:
	// Functions
	Synset(int nw, int off, double alpha);
  ~Synset();
	void addWord(int index, int word);
	void addChild(int childID);
	void addChild(int childID, double alpha);
  void changeAlpha(double newAlpha);
	int getChild(int i);
  int getWord(int i);

	// Debug
	void printSynsetStatus();

	// Data
	int numberWords;
	int numberPaths;
	int ID;
	void hangWord();
	int getHungWords();
	double getAlpha(int i);
	void addAlpha(double alpha);
	int getNumberChildren();
	double getDirichletNormalizer();
	void finalizeAlphas();
	double alphaScale;
	//friend class WN;
	//friend class TopicWalk;
private:
	vector <int> children;
	vector <double> alpha;
	double dirichletNormalizer;
	int * words;
	int hungWords;
};

#endif
