
#ifndef GIBBS_INCLUDED
#define GIBBS_INCLUDED

#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <sstream>
#include <string>
#include "SuperCorpus.h"
#include "WN.h"
#include "Word.h"
using namespace std;

char options[] = 
" COMMAND LINE OPTIONS (default in brackets)\n"
"-----------------------------------------------------------------------\n"
"-help                       Print this message\n"
"-numIterations [1000]       How many times do we sample all words?\n"
"-tau                        Set Dirichlet prior on document topics\n"
"-debug                      Add the word with that line number to DOT files\n"
"                            (requires verbose output)\n"
"-burnIn [100]               Wait how many iterations before using counts?\n"
"-alpha [1]                  The Dirichlet parameter for nodes\n"
"-numTopics [5]              How many topics do we use\n"
"-noHang                     Don't estimate seperate probability for words\n"
"-verboseFiles               Print out (possibly) useful files\n"
"-infocon                    Use alpha derived from word frequences\n"
"-varyAlpha                  Dicrease alpha by 1/depth at all nodes\n"
"-alphaFile [combined.alpha] Load alpha from that file\n"
"-noCache                    Turns of chaching\n"
"                            (not reccomended ... doesn't even save memory)\n"
"-topicSeed                  Use already defined topics in modelName.top\n"
"-resume                     Look for existing files and resume\n"
"-weightPaths [-1]           Raise path length to this exponent and \n"
"                            multiply by the computed path probability\n"
"-modelName [data/counts]    Write results to what file?\n";

void ShowUsage()
{
  fprintf(stderr, "Usage: ldawn [-option [arg ...] ...]\n");
  fprintf(stderr, options);
  exit(1);
}

void CheckOption(char *option, int argc, int minargc)
{
  if(argc < minargc)
  {
    fprintf(stderr, "Too few arguments for %s\n", option);
    ShowUsage();
  }
}


static const int MAX_PATHS=40;

struct WordState {
	int path;
	int topic;
	WordState::WordState(int paths, int topics)
	{
    assert(topics>0);
    if(paths==0)
      this->path=-1;
    else
      this->path = randomInteger(paths);

	  this->topic = -1;
		//cout << "RANDOM STATE: " << this->path << "/" << paths << " " << this->topic << "/" << topics << endl;
	}
};

class Gibbs 
{
public:
	Gibbs(WN * walk, int numTopics, SuperCorpus * data, double tau, string output, bool hang, double weightPaths, bool topicCache, bool cheat);
	~Gibbs();
	void runSampler(int nIter, int burnIn, bool verbose, int startRound);
	void writeCounts(string filename, bool xml);
	double walksDataProbability();
	double topicDataProbability();
	void cheat(int corpus);
	int mostLikelySynset(int doc, int word, int wordID);
	int readState();
	void initializeCounts();
private:
	double tau;
	WordState *** assignments;
	TopicWalk ** topics;
	string output;
	int burnInRounds;

	// We want to include multiple corpora
	SuperCorpus * data;
	//corpus_t * data;
	WN * walk;
	double * tempPathProb;
	double * tempTopicProb;
	int *** senseCounts;
	int *** topicCounts;
	int * topicTotals;
	int ** wordIDs;
	int nTopics;
	int nDocs;
	bool loadCheat;
	double weightPaths;
	double averageDistance;

	void writeState(int round);
	void setTopicTotals(int doc);
	void initializePathsFromCounts();
	double totalPosterior();

	void recordState();
	void printState(int doc);
	void sampleWords(int doc, int word); 
	string writeReport(string file);
	void changePathCount(Path * p, int topic, double change);
	int logSample(double * array, int number);
	int samplePath(int topic, int wordID);
	double topicWordProbability(int topic, int docTotal, int wordID);
  double topicProbability(int topic, int docTotal);
};



#endif
