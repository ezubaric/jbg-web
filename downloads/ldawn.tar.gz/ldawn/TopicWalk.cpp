
#include "TopicWalk.h"

using namespace std;


/*
 * Write out a file to be read by GraphViz
 * 
 * Puts out a file with all of the transitions between
 * the synsets in the debug_synsets data structure.
 */
void TopicWalk::writeGraph(string filename)
{
  //this->walk->printDebug();
	ofstream myfile;
	set <int>::iterator i;
	int j;

	myfile.open(filename.c_str());
	myfile << setprecision(4);
	myfile << "digraph states {" << endl;

  double bestProb = -1e100;

  for(i=walk->debug_synsets.begin(); i!=walk->debug_synsets.end(); i++)
  {
    int synset = *i;
    int ID = this->walk->getSynset(synset)->ID;
    int numberWords = walk->getSynset(synset)->numberWords;
    //cout << "Synset " << synset << " has " << numberWords << " words." << endl;
    for(j=0; j<numberWords; j++)
    {
      int word = walk->getSynset(synset)->getWord(j);
      //cout << bestProb << " " << this->synsetGivenWord(word, ID) << endl;
      if (has(word, this->walk->debug_words) && bestProb < this->synsetGivenWord(word, ID))
      {
        bestProb = this->synsetGivenWord(word, ID);
      }
    }
  }

  //cout << "BEST PROB: " << exp(bestProb) << endl;

  for(i=walk->debug_synsets.begin(); i!=walk->debug_synsets.end(); i++)
  {
    int synset = *i;
    int ID = this->walk->getSynset(synset)->ID;
    int numberWords = walk->getSynset(synset)->numberWords;
    int color=100;

    myfile << "\t" << synset << " [style=filled,label=\"";

    if(numberWords==0)
      myfile << ID;
    else
      {
        for(j=0; j<numberWords; j++)
        {
          int word = walk->getSynset(synset)->getWord(j);
          double prob = this->synsetGivenWord(word, ID);

          if(has(word, walk->debug_words))
          {
            int newColor = 100 - int(100.0 * exp(prob - bestProb));
            if(newColor < color)
              color = newColor;
          }

          myfile << walk->getWord(synset, j) << "(" << exp(prob) << ") ";
        }
      }

    myfile << "\", fillcolor=\"grey" << color << "\"";

    if(color < 50)
      myfile << ", fontcolor=\"white\"]" << endl;    
    else
      myfile << "]" << endl;




    for(j=0; j<walk->getSynset(synset)->getNumberChildren(); j++)
    {
      // The position in the array                                                                                                                          
      int childPOS = walk->getSynset(synset)->getChild(j);

      // Print out all of the children in the list of                                                                                                       
      // synsets to be printed                                                                                                                              
    if(has(childPOS, walk->debug_synsets))
      myfile << "\t" << synset << " -> " << childPOS << " [label=\"" <<
          exp(this->transProbability(synset, j)) << "/" << gsl_vector_get(this->counts[synset], j) << "\"]" << endl;
    }
    /* self-loop, removed for the moment
    if(walk->synsets[synset]->numberChildren > 0)
      myfile << "\t" << ID << " -> " << ID << " [label=\"" <<
        exp(gsl_vector_get(b[synset], 0)) << "\"]" << endl;
	*/

  }
  myfile << "}" << endl;
  myfile.close();
}


void TopicWalk::writeTopic(string filename, double probCutoff)
{
	ofstream myfile;
	myfile.open(filename.c_str());

    // create empty dictionary
    StrDblMMap dict;

	int word=0;
	double prob;

	StrDblMMap::iterator pos;
	intintmap::iterator synsets;

	for(word=0; word<this->walk->vocabSize; word++)
	{
		dict.insert(make_pair(this->synsetGivenWord(word, -1), word));
	}

    for (pos = dict.begin(); pos != dict.end(); ++pos) {
		word = pos->second;
		prob = pos->first;

		if(prob > probCutoff)
		{
			myfile << exp(prob) << " " << word << " " << this->walk->wordList[word] << ":";
	
			for(synsets=this->walk->pathList[word]->synsets.begin(); synsets != this->walk->pathList[word]->synsets.end(); ++synsets)
				myfile << " " << synsets->first << " " << exp(this->synsetGivenWord(word, synsets->first));
			myfile << endl;
		}
    }
	myfile.close();
}

TopicWalk::TopicWalk(WN * walk, double pathMultiplier, bool cache)
{
	this->walk = walk;
	this->useCache = cache;
	this->weightPathLength = pathMultiplier;
	int i;
	this->counts = (gsl_vector**)malloc(sizeof(gsl_vector*)*walk->numberSynsets);
	
	for(i=0; i<walk->numberSynsets; i++)
	{
		if(walk->getSynset(i)->getNumberChildren() > 0)
			this->counts[i] = gsl_vector_calloc(walk->getSynset(i)->getNumberChildren());
	}

	// For caching
	if(this->useCache)
	{
		this->cacheVersion = 1;
		this->synsetProbCache = new double[this->walk->numberSynsets];
		this->synsetProbCacheVersion = new unsigned int[this->walk->numberSynsets];
		this->flushCache();
	}
}

void TopicWalk::changeCounts(Path *p, double change)
{
	if(this->useCache)
	{
		this->cacheVersion++;

		//cout << "CV now " << this->cacheVersion << endl;

		if(this->cacheVersion==0)
			this->flushCache();
	}

	int i;
	for(i=0; i<p->getLength(); i++)
	{
		int current = p->synset[i];
		int next = p->nextIndex[i];
		gsl_vector_set(this->counts[current], next,
			gsl_vector_get(this->counts[current], next) + change);
	}
}

void TopicWalk::flushCache()
{
	int i;
	int cached=0;
	
	for(i=0; i<walk->numberSynsets; i++)
	{
		Synset * s = walk->getSynset(i);
		cached += (this->synsetProbCache[i] != 0.0);

		// By setting all of the cache versions to zero,
		// we prevent any values from being cached 
		// (this can't work because we don't know
		// which path it came from and thus can't
		// trust the cached value)
		if(s->numberPaths!=1)
			this->synsetProbCacheVersion[i] = 0;
		else
			this->synsetProbCacheVersion[i] = 1;
	}

	if(this->cacheVersion==0)
		cout << "Done flushing: " << (double)cached / (double)this->walk->numberSynsets << endl;
	
	this->cacheVersion = 2;
}

double TopicWalk::transProbability(int start, int nextOffset)
{
	/*
	cout << "Going from " << this->walk->synsets[start]->ID << " to " <<
		this->walk->synsets[this->walk->synsets[start]->children[nextOffset]]->ID;

	cout << "There are " << this->walk->synsets[start]->numberChildren << " children, " <<
		" looking at " << nextOffset << endl;
	*/

	double observed = gsl_vector_get(this->counts[start], nextOffset);
	double pseudoCount = walk->getSynset(start)->getAlpha(nextOffset);
	double numerator = log(observed + pseudoCount);

	double countSum = sum(this->counts[start]);
	double alphaTotal = walk->getSynset(start)->alphaScale;
	double denominator = log(countSum + alphaTotal);

	double prob = numerator - denominator;
	
	/*
    cout << "         With " << gsl_vector_get(this->counts[start], nextOffset) << " of " <<
		sum(this->counts[start]) << " and a=" << walk->getSynset(start)->getAlphaSum() << ":" << walk->getSynset(start)->getAlpha(nextOffset) << ", prob=" << exp(prob) << endl;
  walk->getSynset(start)->printSynsetStatus();
  */

	assert(prob <= 0);
	return prob;
}

double TopicWalk::dataProb()
{
	int i;
	double sum=0;
	double nodeProb = 0;

	// For debugging the probability
	bool debug=false;

	if(debug)
		cout << "---------------------------------------" << endl;

	for(i=0; i<walk->numberSynsets; i++)
	{
	
		if(walk->getSynset(i)->getNumberChildren()>1)
		{
			nodeProb = this->nodeDataProb(i);
			sum += nodeProb;

			if(debug)
			{
				cout << nodeProb << " ";
				this->printNodeStatus(i);
			}
		}

		if(debug)
			cout << i << " " << nodeProb << endl;
	}
	
	if(debug)
	{
		cout << "PRODUCT: " << sum << endl;
		cout << "---------------------------------------" << endl;
	}

	assert(sum <= 0);
	return sum;
}

/*
 * Gives the probability summed over all paths that lead 
 * to the word with id given divided by all the word's paths.
 * If synset==-1, then it's unormalized
 */
double TopicWalk::synsetGivenWord(int wordID, int synsetID)
{
  int i;
  double val=safe_log(0.0);
  double normalizer=safe_log(0.0);
  for(i=0; i<this->walk->pathList[wordID]->numberPaths(); i++)
  {
	  Path * p = this->walk->pathList[wordID]->paths[i];
	  double prob = pathProb(p);

	  normalizer=log_sum(normalizer, prob);
	  if(this->walk->getSynset(p->lastSynset())->ID==synsetID)
		val = log_sum(val, prob);
  }
  if(synsetID==-1)
	  return normalizer;
  else
	return val - normalizer;
}

double TopicWalk::nodeDataProb(int i)
{
  // Check to see if we always go to the child
	int j;
	Synset * s = walk->getSynset(i);
	int numberChildren = s->getNumberChildren();
	
	// Handy expressions
	double alphaSum = s->alphaScale;
	double countSum = sum(this->counts[i]);

	if(countSum < 1)
		return 0;

	// This is for the first term
	double z1 = s->getDirichletNormalizer();
	//cout << "As = " << alphaSum << " Ap = " << s->getLogGammaAlphaProduct() << " b=" << s->getNumberChildren() << endl;
	//cout << "Z1= " << z1 << endl;

	// Removed - we have N observations from an infinite draw from 
	// Mult(1, theta), not a Mult(N, theta) draw
	// double z2 = lgamma(1.0 + countSum); 

	//cout << "Z2= " << z2 << endl;
	double z3 = -lgamma(alphaSum + countSum);

	for(j=0; j < numberChildren; j++)
	{
		double count = gsl_vector_get(this->counts[i],j);
		double alpha = s->getAlpha(j);

		// Not sure about this either, think it should be reversed
		// z2 -= lgamma(1.0 + count);
		z3 += lgamma(alpha + count);
	}
  //cout << "Z1=" << z1 << ", Z2 " << z2 << " p = " << exp(z1+z2+z3) << endl;

	return z1 + z3;
}

void TopicWalk::printNodeStatus(int node)
{
	int i;
	Synset * s = this->walk->getSynset(node);

	cout << "Node " << s->ID << "[";
	for(i=0; i<s->getNumberChildren(); i++)
	{
		if(i>0)
			cout << ", ";
		cout << gsl_vector_get(this->counts[node], i);
	}
	cout << "]" << endl;
}

double TopicWalk::pathProb(Path *p)
{
	int index;
	double prob = 0.0;
	double cache = 0.0;
	bool analCheck = ANAL_CHECK;
	
	//Synset * last = walk->getSynset(p->lastSynset());

	//p->print();
	//cout << "Last word: " << this->walk->wordList[last->words[0]] << " " << "Last ID:" << last->ID << endl;

	if(this->useCache || analCheck)
	{
		for(index = p->getLength() - 1; index >= 0; index--)
		{
			int synsetID = p->synset[index];
			int nodeCache = this->synsetProbCacheVersion[synsetID];
			if(nodeCache==this->cacheVersion)
			{
				cache = this->synsetProbCache[synsetID];
				break;
			}
		}

		//cout << "We got to index " << index << endl;

		// If we got this far, we know nothing
		if(index<0)index=0;

		// We've now found the probability of reaching the synset at this index
		for(index = index; index < p->getLength(); index++)
		{
			//cout << p->synset[index] << " Offset: " << this->walk->synsets[p->synset[index]]->ID <<
			//	" " << this->walk->synsets[p->synset[index]]->numberWords << endl;
			cache += this->transProbability(p->synset[index], p->nextIndex[index]);
			if(this->synsetProbCacheVersion[p->synset[index+1]] > 0)
			{
				this->synsetProbCache[p->synset[index+1]]=cache;
				this->synsetProbCacheVersion[p->synset[index+1]]=this->cacheVersion;
			}

		}

	}
	
	if(!this->useCache || analCheck)
	{
		for(index = 0; index < p->getLength(); index++)
		{
			prob += this->transProbability(p->synset[index], p->nextIndex[index]);
		}
	}

	//cout << "CACHE:" << cache << " PROB: " << prob << " " << cache-prob << endl;
	if(analCheck)
		assert(cache==prob);

  if(this->useCache)
    prob=cache;


	// Removed, we assume a constant
	//prob-=log((double)this->walk->getSynset(p->lastSynset())->numberWords);
	//prob-=log(1.78);

	// Weight by length - removed for now, should be added back in
	if(this->weightPathLength)
		prob+= weightPathLength * log((double)p->getLength());

	return prob;
}
