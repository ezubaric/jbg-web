#ifndef DATA_H
#define DATA_H

#include "gsl-wrappers.h"
// Jerry #include "param.h"
#include <stdio.h>
#include <stdlib.h>

#define OFFSET 0

/*
 * a document is a collection of counts and terms
 *
 */

typedef struct doc_t
{
    int total;
    int nterms;
    int * word;
    int * count;
} doc_t;


/*
 * a corpus is a collection of documents
 *
 */

typedef struct corpus_t
{
    doc_t** doc;
    int ndocs;
    int nterms;
    int max_unique;  // maximum number of unique terms in a document
} corpus_t;


/*
 * functions
 *
 */

corpus_t* read_corpus(const char* name);
void write_corpus(corpus_t* c, char* filename);

#endif
