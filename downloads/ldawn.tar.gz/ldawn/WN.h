

#ifndef WN_INCLUDED
#define WN_INCLUDED

#include "Synset.h"
#include "Word.h"
#include "data.h"
#include "TopicWalk.h"
#include <set>
#include <map>
#include <vector>

using namespace std;
/*
 * Will print out a .dot file for all the paths
 * leading to this word.
 */

template<class T, class Comp>
bool has(T x, std::set<T, Comp>& s)
{
	return (s.count(x)==1 ? true : false);
}

class WN
{
 public:

  // Constructor and Destructor
  WN(char * corpus, bool hang, bool varyAlpha, double alphaScale, char * alphaFileName, std::set<int> debug);
  ~WN();
  
  
  // Do we hang words off of synsets?
  bool hangWords;
  bool varyAlphaWithDepth;
  
  // Public Functions
  
  void setDebug(doc_t * d);
  
  /*
   * Find the position of a synset in the array
   * given its WN id
   */
  int findID(int offset);
  
  /*
   * Creates all the path linked lists, returns the
   * length of the longest path
   */
  int createPaths();
  
  /*
   * Pointer going to all of the words' paths
   */
  Word** pathList;
  
  /*
   * Keeps track of all of the words in the vocabulary
   */
  vector <string> wordList;
  
  /*
   * The total number of synsets in WordNet,
   * defines the size of the synsets array
   */
  int numberSynsets;
  
  /*
   * The number of words in the LDA vocabulary,
   * this is the size of the paths array, and
   * there at most this many linked lists of
   * paths
   */
  int vocabSize;
  void printDebug();
  Synset * getSynset(int id);
  string getWord(int synset, int word);
  set<int> debug_synsets;
  bool validatePath(Path * p, int path);
  set<int> debug_words;
  int distance(int word, int SynsetA, int SynsetB);
  
 private:
  /*
   * Pointer to the synsets
   */
  Synset** synsets;
  void readSynsets(const char *synsetFilename, const char *wordFilename, double alpha, char * alphaFileName);
  void sortPaths();
  int findID(int offset, int l, int r);
  void readLinks(const char *linksFilename, const char * alphaFilename);
  void readWords(const char *wordsFilename);
  int depthFirstSearch(vector<int>& traversed, 
                       vector<int>& nextPointers,
                       int depth, int rootSynset);
  void addDebugPath(Path * p);
  void addDebugChildren(int parent);
  
};

#endif
