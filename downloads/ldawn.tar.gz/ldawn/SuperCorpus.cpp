#include "SuperCorpus.h"

SuperCorpus::SuperCorpus(int numberCorpora)
{
	this->corpora = new corpus_t * [numberCorpora];
	this->hasAnswer = new bool [numberCorpora];
	this->hasTopic = new bool [numberCorpora];
	this->nCorpora = 0;
	this->nDocs = 0;
	this->senses = new int ** [numberCorpora];
	this->topics = new int ** [numberCorpora];
	this->words = new int ** [numberCorpora];
	this->totalWords = new int * [numberCorpora];
}


doc_t * SuperCorpus::getDoc(int doc)
{
	int corpus = 0;
	while(doc >= this->corpora[corpus]->ndocs)
		doc -= this->corpora[corpus++]->ndocs;
	assert(doc >= 0 && corpus < this->nCorpora);
	return this->corpora[corpus]->doc[doc];
}

/*
 * Returns the topic of a word, -1 if it wasn't
 * preloaded from LDA
 */
int SuperCorpus::getTopic(int doc, int word)
{
	int corpus = 0;
	while(doc >= this->corpora[corpus]->ndocs)
		doc -= this->corpora[corpus++]->ndocs;
	assert(doc >= 0 && corpus < this->nCorpora);
	
	if(this->hasTopic[corpus])
		return this->topics[corpus][doc][word];
	else
		return -1;
}

void SuperCorpus::addCorpus(string name, bool answer, bool topic, int topics, bool cheat)
{
	this->corpora[this->nCorpora] = read_corpus((name + ".dat").c_str());
	this->hasAnswer[this->nCorpora] = answer;
	this->hasTopic[this->nCorpora] = topic;
	this->nDocs += this->corpora[this->nCorpora]->ndocs;

	if(answer)
	{
		int numberDocs;
		int numberWords;

		int word;
		int synset;

		int doc,i;

		ifstream infile;

		// Loads the specified cheat if we're in to that sort
		// of things
		if(cheat)
		  infile.open((name + ".cheat").c_str());
		else
		  infile.open((name + ".ans").c_str());

    int totalDocs = this->corpora[this->nCorpora]->ndocs;

		assert(infile >> numberDocs);
    cout << "NUM DOCS: " << numberDocs << " " << this->corpora[this->nCorpora]->ndocs << endl;  
		assert(numberDocs <= this->corpora[this->nCorpora]->ndocs);

		this->totalWords[this->nCorpora] = new int [totalDocs];
		this->words[this->nCorpora] = new int * [numberDocs];
		this->senses[this->nCorpora] = new int * [numberDocs];

		for(doc=0; doc < totalDocs; doc++)
		{
      if(doc < numberDocs)
      {
        infile >> numberWords;
        /*        if(this->corpora[this->nCorpora]->doc[doc]->total != numberWords)
        {
          cout << "Mismatch in answers vs. dat file for doc " << doc << endl;
          cout << "             Expecting " << this->corpora[this->nCorpora]->doc[doc]->total << endl;
          cout << "             Saw       " << numberWords << endl;
          }*/
        this->totalWords[this->nCorpora][doc]=numberWords;

        this->words[this->nCorpora][doc] = new int [numberWords];
        this->senses[this->nCorpora][doc] = new int [numberWords];

        for(i=0; i<numberWords; i++)
        {
          infile >> synset;
          infile >> word;
          this->words[this->nCorpora][doc][i] = word;
          this->senses[this->nCorpora][doc][i] = synset;
        }
      }
      else
      {
        numberWords = 0;
        this->totalWords[this->nCorpora][doc]=numberWords;        

        //this->words[this->nCorpora][doc] = new int [numberWords];
        //this->senses[this->nCorpora][doc] = new int [numberWords];
      }
		}
    cout << "Break on through to the other side." << endl;
	}


	if(topic)
	{
		int numberWords;

		int word;
		int topic;

		int doc,i;

		ifstream infile;
    string filename = name + "-" + itos(topics) + ".top";
		infile.open(filename.c_str());

    cout << "Opening topics from " << filename << endl;

		int numberDocs = this->corpora[this->nCorpora]->ndocs;
		this->topics[this->nCorpora] = new int * [numberDocs];

		for(doc=0; doc < numberDocs; doc++)
		{
			infile >> numberWords;
			if(this->corpora[this->nCorpora]->doc[doc]->nterms != numberWords)
			{
				cout << "Mismatch in topic vs. dat file for doc " << doc << endl;
				cout << "             Expecting " << this->corpora[this->nCorpora]->doc[doc]->nterms << endl;
				cout << "             Saw       " << numberWords << endl;
			}
			assert(this->corpora[this->nCorpora]->doc[doc]->nterms == numberWords);
			this->topics[this->nCorpora][doc] = new int [numberWords];

			for(i=0; i<numberWords; i++)
			{
				infile >> word;
				infile >> topic;
				
				assert(this->corpora[this->nCorpora]->doc[doc]->word[i]==word);
				this->topics[this->nCorpora][doc][i] = topic;
			}
		}

	}
        
	this->nCorpora++;
}

int SuperCorpus::numberDocs()
{
	return this->nDocs;
}

SuperCorpus::~SuperCorpus()
{
	int corpus, doc;

	for(corpus=0; corpus<this->nCorpora; corpus++)
	{
		for(doc=0; doc<this->corpora[corpus]->ndocs; doc++)
		{
			delete this->words[corpus][doc];
			delete this->senses[corpus][doc];
		}
		delete this->words[corpus];
		delete this->senses[corpus];
	}
	delete this->words;
	delete this->senses;
	delete this->hasAnswer;
}
