#ifndef PATH_INCLUDED
#define PATH_INCLUDED

#include <vector>
#include <iostream>

using namespace std;

void printPath(const vector<int>& path, const vector<int>& off);

class Path
{
public:
	Path(const vector<int>& path, const vector<int>& off);

	friend struct Word;
	friend class TopicWalk;
	friend class WN;
	void print();
	int getLength();
	int lastSynset();
	int distance(Path * p);
	
private:
	vector <int> synset;
	vector <int> nextIndex;
};



#endif
