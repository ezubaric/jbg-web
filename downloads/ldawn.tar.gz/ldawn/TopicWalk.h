
#ifndef TOPICWALK_INCLUDED
#define TOPICWALK_INCLUDED

#include <set>
#include <iterator>
#include <map>
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include "WN.h"

typedef multimap<double,int> StrDblMMap;
typedef map<int, int> intintmap;

class TopicWalk {

public:
	TopicWalk(WN * walk, double pathMultiplier, bool cache);
	void changeCounts(Path * p, double change);
	void writeGraph(string filename);
	void writeTopic(string filename, double probCutoff);
	double pathProb(Path * p);
	double dataProb();
	double transProbability(int start, int nextOffset);
private:
	gsl_vector ** counts;
	double nodeDataProb(int i);
	WN * walk;

	// For caching
	double * synsetProbCache;
	bool useCache;
  
	double weightPathLength;
	double synsetGivenWord(int wordID, int synsetID);
	void printNodeStatus(int node);
	unsigned int cacheVersion;
	unsigned int * synsetProbCacheVersion;
	void flushCache();
};


#endif
