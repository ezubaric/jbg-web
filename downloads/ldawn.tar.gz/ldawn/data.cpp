#include "data.h"
#include <iostream>

using namespace std;

/*
 * read corpus
 *
 */

corpus_t* read_corpus(const char* filename)
{
  int length, count, word, n;
  corpus_t* c;
  
//    outlog(stderr, "[DATA] reading from %s", filename);
  c = (corpus_t*) malloc(sizeof(corpus_t));
  c->max_unique = 0;
  FILE *fileptr = fopen(filename, "r");
  
  if(fileptr == NULL) {
    cerr << "Could not open " << filename << " for input." << endl;
    exit(0);
  }

  c->ndocs = 0; 
  c->nterms = 0;
  c->doc = (doc_t**)malloc(sizeof(doc_t*));
  while ((fscanf(fileptr, "%10d", &length) != EOF)) {
    if (length > c->max_unique) c->max_unique = length;
    c->doc = (doc_t**) realloc(c->doc, sizeof(doc_t*)*(c->ndocs+1));
    c->doc[c->ndocs] = (doc_t*) malloc(sizeof(doc_t));
    c->doc[c->ndocs]->nterms = length;
    c->doc[c->ndocs]->total = 0;
    c->doc[c->ndocs]->word = (int*)malloc(sizeof(int)*length);
    c->doc[c->ndocs]->count = (int*)malloc(sizeof(int)*length);
    for (n = 0; n < length; n++) {
      fscanf(fileptr, "%10d:%10d", &word, &count);
      word = word - OFFSET;
      c->doc[c->ndocs]->word[n] = word;
      c->doc[c->ndocs]->count[n] = count;
      c->doc[c->ndocs]->total += count;
      if (word >= c->nterms) { c->nterms = word + 1; }
    }
    c->ndocs = c->ndocs + 1;
  }
  fclose(fileptr);
  fprintf(stderr, "[DATA] ndocs = %d; nterms = %d; unique = %d\n", c->ndocs, c->nterms, c->max_unique);
  return(c);
}


/*
 * write corpus
 *
 */

void write_corpus(corpus_t* c, char* filename)
{
    int i, j;
    FILE * fileptr;
    doc_t * d;
//    outlog(stderr, "[DATA] writing %d docs to %s", c->ndocs, filename);
    fileptr = fopen(filename, "w");
    for (i = 0; i < c->ndocs; i++)
    {
        d = c->doc[i];
        fprintf(fileptr, "%d", d->nterms);
        for (j = 0; j < d->nterms; j++)
        {
            fprintf(fileptr, " %d:%d", d->word[j], d->count[j]);
        }
        fprintf(fileptr, "\n");
    }
    fclose(fileptr);
}
