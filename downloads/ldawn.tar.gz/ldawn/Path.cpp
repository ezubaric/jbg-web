
#include <vector>
#include "Path.h"
#include <assert.h>

void printPath(const vector<int>& path, const vector<int>& off)
{
	unsigned int i;

	cout << "Synsets: ";
	for(i=0; i<path.size(); i++)
		cout << "(" << i << ")" << path[i] << "\t";
	cout << endl << "Offsets: ";
	for(i=0; i<off.size(); i++)
		cout << "(" << i << ")" << off[i] << "\t";
	cout << endl;
}

int Path::distance(Path *p)
{
	int i=0;

	// Subtract 1 in order to account for the words we've hung
	int p1length = (int)this->synset.size();
	int p2length = (int)p->synset.size();
	int length = min(p1length, p2length);

	// Find where they start not to match
	while(i<length && this->synset[i]==p->synset[i])
		i++;

	//p->print();
	//this->print();
	//cout << i << endl;

	return p1length + p2length - 2*i;
}

void Path::print()
{
	cout << "The length of synsets is " << synset.size() << ", and links is " << this->getLength() << endl;
	printPath(synset, nextIndex);
}

int Path::lastSynset()
{
	assert(synset.size()>0);
	return synset[synset.size()-1];
}

Path::Path(const vector<int>& path, const vector<int>& off)
{
	assert(path.size() == (off.size() + 1));

	int i=0;
	int length=(int)off.size();

	for(i=0; i<length; i++)
	{
		this->synset.push_back(path[i]);
		this->nextIndex.push_back(off[i]);
	}
	this->synset.push_back(path[i]);

	assert(synset[i]==path[i]);
	assert(synset.size()==(nextIndex.size()+1));
	//cout << "Created new path that ends at synset " << path[i] << endl;
}

int Path::getLength()
{
	return (int)nextIndex.size();
}


