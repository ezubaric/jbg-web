#ifndef GSL_WRAPPERS_H
#define GSL_WRAPPERS_H

// #include <gsl/gsl_check_range.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_multimin.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_blas.h>
#include <math.h>
#include <assert.h>
#include<iostream>
#include<string>
#include<sstream>
using namespace std;
//#include <time.h>

// Do we check to make sure caching gave us the right answer
#define ANAL_CHECK false
#define MAXFLOAT 3.40282347e+38F
// How often do we print results
#define PRINT_EVERY_N_ROUNDS 100
// How much do we smooth alpha (should be very small ... 
// just for cases when we had no word observations)
#define ALPHA_EPSILON 0.1
// This needs to be a number longer than the longest path
// in the network
#define MAX_PATH 1000
// For printing the dot file, how strongly does the
// prior need to point to a synset for us to include it
#define ALPHA_CUTOFF 0.50

//time_t TIME;
//char line1[80];


double safe_log(double);
double log_sum(double, double);

//#define outlog(f, format, args) TIME = time(NULL); sprintf(line1, format, args); fprintf(f, "%-80s %s", line1, ctime(&TIME)); fflush(f);

static inline double vget(const gsl_vector* v, int i)
{ return(gsl_vector_get(v, i)); };

static inline void vset(gsl_vector* v, int i, double x)
{ gsl_vector_set(v, i, x); };

void vinc(gsl_vector*, int, double);

static inline double mget(const gsl_matrix* m, int i, int j)
{ return(gsl_matrix_get(m, i, j)); };

static inline void mset(gsl_matrix* m, int i, int j, double x)
{ gsl_matrix_set(m, i, j, x); };

bool my_isnan(double x);

void msetcol(gsl_matrix* m, int r, const gsl_vector* val);

void minc(gsl_matrix*, int, int, double);
void msetrow(gsl_matrix*, int, const gsl_vector*);

void col_sum(gsl_matrix*, gsl_vector*);

void vct_printf(const gsl_vector* v);
void mtx_printf(const gsl_matrix* m);
void vct_fscanf(const char*, gsl_vector* v);
void mtx_fscanf(const char*, gsl_matrix* m);
void vct_fprintf(const char* filename, gsl_vector* v);
void mtx_fprintf(const char* filename, const gsl_matrix* m);

double log_det(gsl_matrix*);

void matrix_inverse(gsl_matrix*, gsl_matrix*);

void sym_eigen(gsl_matrix*, gsl_vector*, gsl_matrix*);

string itos(int i);
string dtos(double i);

double sum(const gsl_vector* v);

double norm(gsl_vector * v);

void vct_log(gsl_vector* v);
void vct_exp(gsl_vector* x);

//void choose_k_from_n(int k, int n, int* result);

void log_normalize(gsl_vector* x);
void normalize(gsl_vector* x);

int randomInteger(int maxrand);

void optimize(int dim,
              gsl_vector* x,
              void* params,
              void (*fdf)(const gsl_vector*, void*, double*, gsl_vector*),
              void (*df)(const gsl_vector*, void*, gsl_vector*),
              double (*f)(const gsl_vector*, void*));

void optimize_fdf(int dim,
                  gsl_vector* x,
                  void* params,
                  void (*fdf)(const gsl_vector*, void*, double*, gsl_vector*),
                  void (*df)(const gsl_vector*, void*, gsl_vector*),
                  double (*f)(const gsl_vector*, void*),
                  double* f_val,
                  double* conv_val,
                  int* niter);

void log_write(FILE* f, char* string);

double lgamma(double x);

#endif
