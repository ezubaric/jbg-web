#include "gibbs.h"
#include <ctime>



int main(int argc, char** argv)
{

  //int topics = atoi(argv[1]);
  int topics=5;
  char output[30] = "data/counts";
  char wn_prefix[30] = "input/toy";
  char alphaFile[30] = "";
  
  int niter=1000;
  int burnin=100;
  bool topicCache = true;
  bool useTopics = false;
  bool resume = false;
  bool verbose = false;
  bool cheat = false;
  bool loadAlpha = false;
  bool bnc = false;
  bool varyAlpha = false;
  double alpha = 1.0;
  bool hang=true;
  double weightPaths=-1.0;
  double tau=5.0;
  std::set<int> debug;
  std::vector<string> documents;

  argv++; argc--;
  while (argc > 0)
  {
    if (!strcmp(*argv, "-burnIn"))
      {
        CheckOption(*argv, argc, 2);
        burnin = atoi(argv[1]);
        cout << "Using a burn in of " << burnin << " rounds." << endl;
        argv += 2; argc -= 2;
      }
    else if (!strcmp(*argv, "-numTopics"))
      {
        CheckOption(*argv, argc, 2);
        topics = atoi(argv[1]);
        cout << "Using " << topics << " topics." << endl;
        argv += 2; argc -= 2;
      }
    else if (!strcmp(*argv, "-doc"))
      {
        CheckOption(*argv, argc, 2);
        string doc(argv[1]);
        cout << "Adding " << doc << " to debug list." << endl;
        documents.push_back(doc);
        argv += 2; argc -= 2;
      }
    else if (!strcmp(*argv, "-debug"))
      {
        CheckOption(*argv, argc, 2);
        int word = atoi(argv[1]);
        cout << "Adding " << word << " to debug list." << endl;
        debug.insert(word);
        argv += 2; argc -= 2;
      }
    else if (!strcmp(*argv, "-alpha"))
      {
        CheckOption(*argv, argc, 2);
        alpha = atof(argv[1]);
        cout << "Using alpha scale of " << alpha << endl;
        argv += 2; argc -= 2;
      }
    else if (!strcmp(*argv, "-weightPaths"))
      {
        CheckOption(*argv, argc, 2);
        weightPaths = atof(argv[1]);
        cout << "Weighting paths by " << weightPaths << endl;
        argv += 2; argc -= 2;
      }
    else if (!strcmp(*argv, "-tau"))
      {
        CheckOption(*argv, argc, 2);
        tau = atof(argv[1]);
        cout << "Using tau of:" << weightPaths << endl;
        argv += 2; argc -= 2;
      }
    else if (!strcmp(*argv, "-infocon"))
      {
        CheckOption(*argv, argc, 1);
        loadAlpha = true;
        cout << "Loading alpha from a file." << endl;
        argv+=1; argc-=1;
      }
    else if (!strcmp(*argv, "-cheat"))
      {
        CheckOption(*argv, argc, 1);
        cheat = true;
        cout << "Starting by cheating with SemCor." << endl;
        argv+=1; argc-=1;
      }
    else if (!strcmp(*argv, "-varyAlpha"))
      {
        CheckOption(*argv, argc, 1);
        varyAlpha = true;
        cout << "Varying alpha with depth." << endl;
        argv+=1; argc-=1;
      }
    else if (!strcmp(*argv, "-noCache"))
      {
        CheckOption(*argv, argc, 1);
        topicCache = false;
        cout << "Not using caching." << endl;
        argv+=1; argc-=1;
      }
    else if (!strcmp(*argv, "-bnc"))
	{
          bnc = true;
          CheckOption(*argv, argc, 1);
          argv+=1; argc-=1;
	}
    else if (!strcmp(*argv, "-resume"))
      {
        resume = true;
        CheckOption(*argv, argc, 1);
        argv+=1; argc-=1;
      }
    else if (!strcmp(*argv, "-topicSeed"))
      {
        useTopics = true;
        CheckOption(*argv, argc, 1);
        argv += 1; argc -= 1;
      }
    else if (!strcmp(*argv, "-verboseFiles"))
      {
        verbose = true;
        CheckOption(*argv, argc, 1);
        argv += 1; argc -= 1;
      }
    else if (!strcmp(*argv, "-noHang"))
      {
        hang = false;
        CheckOption(*argv, argc, 1);
        argv += 1; argc -= 1;
      }
    else if (!strcmp(*argv, "-numIterations"))
      {
      CheckOption(*argv, argc, 2);
      niter = atoi(argv[1]);
      argv += 2; argc -= 2;
      }
    else if (!strcmp(*argv, "-alphaFile"))
      {
        CheckOption(*argv, argc, 2);
        strcpy(alphaFile, argv[1]);
        argv += 2; argc -= 2;
      }
    else if (!strcmp(*argv, "-modelPrefix"))
      {
        CheckOption(*argv, argc, 2);
        strcpy(wn_prefix, argv[1]);
        cout << "Using WN prefix of: " << wn_prefix << endl;
        argv += 2; argc -= 2;
      }
    else if (!strcmp(*argv, "-modelName"))
      {
        CheckOption(*argv, argc, 2);
        strcpy(output, argv[1]);
        cout << "Writing output to: " << output << endl;
        argv += 2; argc -= 2;
      }
    else
      {
        ShowUsage();
      }
    
  }

  cout << "Using " << topics << " topics." << endl;

  WN * walk;
  SuperCorpus * sc = new SuperCorpus(1);

  if(loadAlpha && alphaFile==NULL)
    strcpy(alphaFile, "input/toy.alpha");

  walk = new WN(wn_prefix, hang, varyAlpha, alpha, alphaFile, debug);


  if(documents.size()==0) {
    cerr << "No documents have been added." << endl;
  } else {
    for(int i=0; i<documents.size(); i++) {
      sc->addCorpus(documents[i].c_str(), true, useTopics, topics, cheat);
    }
  } 
  assert(documents.size() > 0);

  Gibbs * g = new Gibbs(walk, topics, sc, tau, output, hang, weightPaths, topicCache, cheat);
  
  int round = 0;
  if(resume)
    {
      cout << "Reading in old counts ..." << endl;
      round = g->readState();
      cout << "done.  On round " << round << "." << endl;
    }
  else
    {
      cout << "Initializing ... " << endl;
      g->initializeCounts();
      cout << "done" << endl;
    }
  
  if(cheat)
    {
      cout << "Cheating by loading in SemCor answers ..." << endl;
      g->cheat(0);
      cout << "done." << endl;
    }

  srand((unsigned int)time(NULL));
  
  g->runSampler(niter, burnin, verbose, round);
  
  cout << "Pause here." << endl;
  delete walk;
  delete g;
  delete sc;
  return 0;
}

double Gibbs::totalPosterior()
{
	int i, j, k, word;
	int topic, pathID, wordID;
	Path * p;
	double sum=0;

	for(i=0; i < this->nDocs; i++)
	{
		doc_t * doc = this->data->getDoc(i);
		this->setTopicTotals(i);	
		word = 0;
		for(j=0; j<doc->nterms; j++)
		{
			for(k=0; k<doc->count[j]; k++)
			{
				wordID = doc->word[j];
				topic = this->assignments[i][word]->topic;
				pathID = this->assignments[i][word]->path;
				p = this->walk->pathList[wordID]->getPath(pathID);
				sum += this->topicWordProbability(topic, doc->total, wordID);
				sum += this->topics[topic]->pathProb(p);
				word++;
			}
		}
	}
	return sum;
}

void Gibbs::printState(int docID)
{
	int i, j, word, topic;
	doc_t * doc = this->data->getDoc(docID);
	word = 0;

	for(i=0; i<doc->nterms; i++)
	{
		for(j=0; j<doc->count[i]; j++)
		{
			int wordID = doc->word[i];
			cout << word << " " << this->walk->wordList[wordID] << " t=" << this->assignments[i][word]->topic << " p=" << this->assignments[i][word]->path << ":" << endl;
			for(topic=0; topic < this->nTopics; topic++)
			{
				double p = this->topicWordProbability(topic, doc->total, wordID);
				cout << "  Topic " << topic << " "  << exp(p) << endl;
			}
			cout << endl;
			word++;
		}
	}

	cout << "TOPIC PROBS (for doc " << docID << "):";
	for(topic=0; topic<this->nTopics; topic++)
	{
		cout << exp(this->topicProbability(topic, docID)) << " ";
	}
	cout << endl;
}

/*
 * For all of the corpora for which we have 
 * answers, write out how many we get correct
 */
string Gibbs::writeReport(string file)
{
  unsigned int distance=0, overallDistance=0, overallTotal=0, corpusDistance=0;
  int correct=0, stateCorrect=0, total=0, nlines=0;
  string result = "";
  
  ofstream outfile;
  outfile.open((file+".wsd").c_str());
  
  int corpus, j, word, k, token;
  int doc=-1;
  
  map <int, int> bestSynset;
  map <int, int> stateSynset;
  map <int, int> topic;
  
  doc_t * doc_data;
  for(corpus = 0; corpus < this->data->nCorpora; corpus++) {
    if(this->data->hasAnswer[corpus]) {
      for(j = 0; j < this->data->corpora[corpus]->ndocs; j++) {
        doc_data = this->data->getDoc(++doc);
        bestSynset.clear();
        stateSynset.clear();
        
        //cout << "--------------------------" << endl;
        
        token=0;
        for(word = 0; 
            word < doc_data->nterms;
            word++)
          {
            int wordID = doc_data->word[word];
            
            bestSynset[wordID] = 
              this->mostLikelySynset(doc, word, wordID);
            
            stateSynset[wordID] = 
              this->walk->getSynset(
                                    this->walk->pathList[wordID]->getPath(
                                                                          this->assignments[doc][token]->path)->lastSynset())->ID;
            //cout << this->walk->wordList[wordID] << " ";	
            topic[wordID] = this->assignments[doc][token]->topic;
            
            for(k=0; k<doc_data->count[word]; k++)
              token++;
            
          }
	
        
        //cout << endl << "--------------------------" << endl;
        
        for(word = 0;
            word < this->data->totalWords[corpus][j];
            word++)
          {
            int wordID = this->data->words[corpus][j][word];
            //cout << this->walk->wordList[wordID] << " ";

            if(bestSynset.find(wordID)==bestSynset.end())
              {
                //cout << "Skipping word " << this->walk->wordList[wordID] << endl;
						continue;
              }
            
            int prediction = bestSynset[wordID];
            int statePrediction = stateSynset[wordID];
            int synset = this->data->senses[corpus][j][word];
            string wordString = this->walk->wordList[wordID];
            
            // Do we count?
            if(this->walk->pathList[wordID]->numberSynsets()>1)
              {
                if(synset == statePrediction)stateCorrect++;
                
                total++;
                if(synset == prediction)
                  {
                    correct++;
                    outfile << "+ ";
                  } else {
                  outfile << "- ";	
                }
                
                distance = this->walk->distance(wordID, prediction, synset);
                corpusDistance += distance;
                // Make sure we don't overflow on very large corpora
                assert(corpusDistance >= corpusDistance - distance);
              }
            else
              {
                outfile << "  ";
              }
            
            nlines++;
            
            outfile << topic[wordID] << " ";
            
            outfile << wordID << " " << wordString << " " << prediction << " " << synset << " " << distance << endl;
            distance = 0;
            
            
          }
      }
      
      overallDistance += corpusDistance;
      //cout << "Overall Distance =" << overallDistance << endl;
      overallTotal+=total;
      
      result += dtos((double)stateCorrect/(double)total) + " " + 
        dtos((double)correct/(double)total) + " (" + 
        dtos((double)corpusDistance / (double)total) + ") ";
      
      
      correct = 0;
      stateCorrect = 0;
      corpusDistance = 0;
      total = 0;
    }
    else
      {
        ++doc;
      }
  }
  
  cout << "Wrote " << nlines << " to " << file << ".wsd." << endl;
  this->averageDistance = (double)overallDistance / (double)overallTotal;
  return result;
}

double Gibbs::topicDataProbability()
{
  int i,j;
  double sum=0;
  double tauPerTopic = (double)this->tau / (double)this->nTopics;
  
  for(i=0; i<this->nDocs; i++)
    {
      doc_t * doc = this->data->getDoc(i);
      this->setTopicTotals(i);
      sum += lgamma(this->tau);
      sum -= lgamma((double)doc->nterms + this->tau);
      for(j=0; j<this->nTopics; j++)
        {
          double total = (double)this->topicTotals[j];
          if(total > 0)
            {
              sum += lgamma(this->topicTotals[j] + tauPerTopic);
				sum -= lgamma(tauPerTopic);
            }
        }	
    }
  return sum;
}

double Gibbs::walksDataProbability()
{
  int i;
  double sum=0;
  
  // Compute the data probability
  for(i=0; i<this->nTopics; i++)
    sum += this->topics[i]->dataProb();
  return sum;
}

void Gibbs::runSampler(int nIter, int burnIn, bool verbose, int startRound)
{
  int i=0,j=0,k=0;
  string correct;
  this->burnInRounds = burnIn;
  
  ofstream probfile;
  
  if(this->output!="") {
    // If we're resuming another run, we start at that round
    if(startRound==0)
      probfile.open((output + ".prob").c_str(), ofstream::out);
    else
      probfile.open((output + ".prob").c_str(), ofstream::out | ofstream::app);
    
    if(verbose) {
      for(j=0; j<this->nTopics; j++) {
        this->topics[j]->writeGraph(this->output + itos(i) + "-" + itos(j) + ".dot");
        this->topics[j]->writeTopic(this->output + itos(i) + "-" + itos(j) + ".tct", -8);
      }
    }
  }
  
  i=startRound;
  
  while(i++<nIter) {
    for(j=0; j < this->nDocs; j++) {
      doc_t * doc = this->data->getDoc(j);
      this->setTopicTotals(j);
      
      for(k=0; k < doc->total; k++) {
        this->sampleWords(j, k);
      }

      if(j%500 ==0 || j==this->nDocs-1)
        cout << "       " << j << "/" << this->nDocs << endl;
      
    }
    
    double p1 = this->walksDataProbability();
    double p2 = this->topicDataProbability();
    // Removed, but we can put this back in if we're paranoid
    //double p3 = this->totalPosterior();
    
    if(i>burnIn) {
      this->recordState();
    }


    if(verbose && this->output!="" && i>burnIn && (i%PRINT_EVERY_N_ROUNDS==0)) {
      for(j=0; j<this->nTopics; j++) {
        this->topics[j]->writeGraph(this->output + itos(i) + "-" + 
                                    itos(j) + ".dot");
        this->topics[j]->writeTopic(this->output + itos(i) + "-" + 
                                    itos(j) + ".tct", -8);
      }
    }
    
    // If verbosity is turned on we keep backup copies of the disambiguation
    // otherwise, we just keep the newest
    if(verbose)
      correct = this->writeReport(this->output + 
                                  itos((i / PRINT_EVERY_N_ROUNDS) * 
                                       PRINT_EVERY_N_ROUNDS + 
                                       PRINT_EVERY_N_ROUNDS-1));
    else
      correct = this->writeReport(this->output);
    
    if(output!="")
      {
        probfile << setprecision(10) << p1 + p2 << " " << correct << endl;
        probfile.flush();
      }
    
    // Print out the probabilities and the accuracy measures
    cout << i << " " << p1 << " " << p2 << " " 
         << correct << " " << this->averageDistance << endl;
    
    // Save the state
    this->writeCounts(output + ".cnt", false);
    this->writeState(i);
  }
  
  if(this->output=="")
    output = "final";
  else
    output += "_final";
  
  this->writeCounts(output + ".cnt", false);
  this->writeReport(output);
  if(output!="")
    probfile.close();
}

/*
 * Cheats by loading in the answers from the corpus
 */ 
void Gibbs::cheat(int cheaterCorpus)
{
  int doc=-1;
  int corpus, j, word, k, token;
  
  map <int, int> answer;		
  doc_t * doc_data;
  
  for(corpus = 0; corpus < this->data->nCorpora; corpus++) {
    if(this->data->hasAnswer[corpus]) {
      for(j = 0; j < this->data->corpora[corpus]->ndocs; j++) {			
        doc_data = this->data->getDoc(++doc);
        answer.clear();
        
        for(word = 0;
            word < this->data->totalWords[corpus][j];
            word++) {
          int wordID = this->data->words[corpus][j][word];
          //cout << this->walk->wordList[wordID] << " ";
          
          int synset = this->data->senses[corpus][j][word];
          answer[wordID] = synset;
        }
        
        
        
        //cout << "--------------------------" << endl;
              
        token=0;
        for(word = 0; 
            word < doc_data->nterms;
            word++) {
          int wordID = doc_data->word[word];
          
          if(answer.find(wordID)==answer.end()) {
            //cout << "Skipping word " << this->walk->wordList[wordID] << endl;
            for(k=0; k<doc_data->count[word]; k++)
              token++;
            continue;
          }						
          
          int synset = answer[wordID];
          
          for(k=0; k<doc_data->count[word]; k++) {
            int numPaths = this->walk->pathList[wordID]->numberPaths();
            int p;
            for(p=0; p<numPaths; p++) {
              if(synset==this->walk->getSynset(
                                               this->walk->pathList[wordID]->getPath(p)->lastSynset())->ID) {
                int topic = this->assignments[doc][token]->topic;
                Path * pathObject = this->walk->pathList[wordID]->getPath(this->assignments[doc][token]->path);
                this->changePathCount(pathObject, topic, -1);
                this->assignments[doc][token]->path = p;
                pathObject = this->walk->pathList[wordID]->getPath(this->assignments[doc][token]->path);
                this->changePathCount(pathObject, topic, 1);
                break;
              }
            }
            if(p==numPaths)
              cout << doc << " " << token << " " << this->walk->wordList[wordID] << " " << this->walk->getSynset(this->walk->pathList[wordID]->getPath(p)->lastSynset())->ID << " " << synset << endl; 
            token++;
          }
          
        }
        
        
      }
    } else {
      for(j = 0; j < this->data->corpora[corpus]->ndocs; j++)
        ++doc;
    }
    
  }
}

/*
 * Writes the current state to a file
 */
void Gibbs::writeState(int round)
{
  int i, j, k;
  
  ofstream outfile;
  
  if(this->output!="") {
    outfile.open((output + ".state").c_str());
    outfile << round << endl;
    
    for(i=0; i < this->nDocs; i++) {
      doc_t * doc = this->data->getDoc(i);
      int word = 0;
      for(j=0; j < doc->nterms; j++) {
        for(k=0; k < doc->count[j]; k++) {
          outfile << assignments[i][word]->topic << " " << assignments[i][word]->path << endl;
          word++;
        }
      }
      assert(word==doc->total);
    }
    outfile.close();
  }
}

void Gibbs::recordState()
{
  int i, j, k;
  
  for(i=0; i < this->nDocs; i++) {
    doc_t * doc = this->data->getDoc(i);
    int word = 0;
    for(j=0; j < doc->nterms; j++) {
      for(k=0; k < doc->count[j]; k++) {
        int wordID = this->wordIDs[i][word];
        int synset = this->walk->pathList[wordID]->paths[assignments[i][word]->path]->lastSynset();
        int offset = this->walk->getSynset(synset)->ID;
        int sense = this->walk->pathList[wordID]->getSynsetID(offset);
        this->senseCounts[i][j][sense]++;
        this->topicCounts[i][j][assignments[i][word]->topic]++;
        //cout << "*" << i << " " << j << " " << this->senseCounts[i][j][sense] << " " << this->topicCounts[i][j][assignments[i][j]->topic] << endl;
        word++;
      }
    }
    assert(word==doc->total);
  }
}

void Gibbs::setTopicTotals(int docNum) {
  int i;
  doc_t * doc = this->data->getDoc(docNum);
  
  for(i=0; i<this->nTopics; i++)
    this->topicTotals[i]=0;

  for(i=0; i<doc->total; i++) {
    int topic = this->assignments[docNum][i]->topic;
    if(topic >= 0)
      this->topicTotals[topic]++;
  }
}

int Gibbs::mostLikelySynset(int docNum, int word, int wordID) {
  map <int, int>::iterator iter;
  
  int bestSynset = -1;
  int highCounts = -1;
  
  //cout << " Trying to get counts for " << word << "th word, " << wordID << "=" << this->walk->wordList[wordID] << " (" << this->walk->pathList[wordID]->numberSynsets() << " synsets)." << endl;
  for(iter=this->walk->pathList[wordID]->synsets.begin(); 
      iter!=this->walk->pathList[wordID]->synsets.end(); 
      iter++)
    {
      //cout << "         " << iter->first << " " << iter->second << " " << this->senseCounts[docNum][word][iter->second] << endl;
      int counts = this->senseCounts[docNum][word][iter->second];
      if(counts > highCounts || (counts == highCounts && bestSynset > iter->first)) {
        bestSynset = iter->first;
        highCounts = counts;
      }
    }
  return bestSynset;
}

void Gibbs::writeCounts(string filename, bool xml)
{
  ofstream myfile;
  myfile.open(filename.c_str());
  
  int i,j,k;
  
  int ndocs = this->data->numberDocs();
  for(i=0; i < ndocs; i++)
    {
      if(xml)
			myfile << "<doc>" << endl;
      else
        myfile << "DOC " << i << endl;
      
      doc_t * doc = this->data->getDoc(i);
      for(j=0; j < doc->nterms; j++)
        {
          int word = doc->word[j];
          myfile << word << " " << this->walk->wordList[word] << endl;
          
          if(!xml)
            {
              for(k=0; k<this->nTopics; k++)
                myfile << this->topicCounts[i][j][k] << " ";
				myfile << endl;
            }
          
          map <int, int>::iterator iter;
          
          for(iter=this->walk->pathList[word]->synsets.begin(); 
              iter!=this->walk->pathList[word]->synsets.end(); 
				iter++)
            {
              myfile << iter->first << " " << this->senseCounts[i][j][iter->second] << " ";
            }
          myfile << endl;
		}
    }
  myfile.close();
}

int Gibbs::readState()
{
  string filename;
  ifstream myfile;
  string crap;
  int temp, round;
  int i,j,k;
  int ndocs = this->data->numberDocs();

  filename = this->output + ".state";
  myfile.open(filename.c_str());

  myfile >> round;

  for(i=0; i < this->nDocs; i++)
  {
    doc_t * doc = this->data->getDoc(i);
    int word = 0;
    for(j=0; j < doc->nterms; j++)
    {
      for(k=0; k < doc->count[j]; k++)
      {
	int wordID = this->wordIDs[i][word];
	assert(myfile >> assignments[i][word]->topic);
	assert(myfile >> assignments[i][word]->path);
	assert(assignments[i][word]->topic < 
	       this->nTopics);
	assert(assignments[i][word]->path < 
	       this->walk->pathList[wordID]->numberPaths());
	
	Path * p = this->walk->pathList[wordID]->getPath(assignments[i][word]->path);
	this->changePathCount(p, 
			      assignments[i][word]->topic, 1);
	
	word++;
      }
    }
    assert(word==doc->total);
    this->setTopicTotals(i);
  }
  myfile.close();


  filename = this->output + ".cnt";
  myfile.open(filename.c_str());
  
  
  
  
  for(i=0; i < ndocs; i++)
    {
      myfile >> crap;
      myfile >> temp;
      assert(temp==i);
      
      doc_t * doc = this->data->getDoc(i);
      for(j=0; j < doc->nterms; j++)
        {
          int word = doc->word[j];
          myfile >> temp;
          assert(temp==word);
          myfile >> crap;
          
          for(k=0; k<this->nTopics; k++)
            {
              myfile >> temp;
              if(round > this->burnInRounds)
                this->topicCounts[i][j][k] = temp;
              else
                this->topicCounts[i][j][k] = 0;
            }
          
          map <int, int>::iterator iter;
          
          for(iter=this->walk->pathList[word]->synsets.begin(); 
              iter!=this->walk->pathList[word]->synsets.end(); 
              iter++)
            {
              myfile >> temp;
              assert(temp==iter->first);
              myfile >> temp;
              if(round > this->burnInRounds)
                this->senseCounts[i][j][iter->second] = temp;
              else
                this->senseCounts[i][j][iter->second] = 0;
            }
        }
    }
  myfile.close();
  
  
  return round;
}


void Gibbs::sampleWords(int docID, int word)
{
  int i;
  
  int path = this->assignments[docID][word]->path;
  int topic = this->assignments[docID][word]->topic;
  int wordID = this->wordIDs[docID][word];
  Path * p = NULL;
  
  // Our total is minus one because we sample out one word
  int total = this->data->getDoc(docID)->total - 1;
  
  //cout << "[" << docID << "] Sampling word " << wordID << "," << this->walk->wordList[wordID] << " " << path << " " << topic << endl;
  
  // The path is -1 if this word isn't in WN
  if(path!=-1)
    {
      p = this->walk->pathList[wordID]->getPath(path);
		this->changePathCount(p, topic, -1);
    }
  
  this->topicTotals[topic]--;
  
  for(i=0; i<this->nTopics; i++)
    this->tempTopicProb[i] = this->topicWordProbability(i, total, wordID);
  
  //this->printState(doc);
  
  topic = logSample(this->tempTopicProb, this->nTopics);
  
  if(path!=-1 && !this->loadCheat)
    path = samplePath(topic, wordID);
  
  //cout << "[" << doc << "] Changed to " << wordID << "," << this->walk->wordList[wordID] << " " << path << " " << topic << endl;
  
  this->topicTotals[topic]++;
  this->assignments[docID][word]->path = path;
  this->assignments[docID][word]->topic = topic;
  
  if(path!=-1)
    {
      p = this->walk->pathList[wordID]->getPath(path);
      this->changePathCount(p, topic, +1);
    }
  
}

int Gibbs::samplePath(int topic, int wordID)
{
  int i;
  Word * w = this->walk->pathList[wordID];
  
  if(MAX_PATHS <= w->numberPaths())
    cerr << "There were more paths than we had room for, must have at least: " << w->numberPaths() << endl;
  assert(MAX_PATHS > w->numberPaths());
  for(i=0; i < w->numberPaths(); i++)
    {
      assert(this->walk->validatePath(w->paths[i], wordID));
      this->tempPathProb[i] = this->topics[topic]->pathProb(w->paths[i]);
    }
  return this->logSample(this->tempPathProb, w->numberPaths());
}

/*
 * returns the element randomly sampled from the log
 * probabilities in array (number is the number of elements)
 */
int Gibbs::logSample(double * array, int number)
{
  double log_normalizer = safe_log(0.0);
  int i;
  
  for(i=0; i<number; i++)
    {
      log_normalizer = log_sum(log_normalizer, array[i]);
    }
  
  double cutoff = (double)rand() / ((double)RAND_MAX + 1.0);
  double sum = 0;
  
  i = -(sum < cutoff);
  
  while(sum < cutoff)
    {
      double val = exp(array[++i] - log_normalizer);
      if(i==number)
        {
          cout << val << " " << cutoff << " " << sum << endl;
        }
      assert(i<number);
      //if(my_isnan(val))
      //cout << " " << i << " " << array[i] << "(" << exp(array[i] - log_normalizer) << ") ";
      sum += val;
                
    }

  //cout << endl << "Selected (" << cutoff << "):" << i << endl;

  if(i==-1 || i>=number)
    cout << "Badness: " << sum << " " << cutoff << " " << i << endl;
  
  assert(i < number);
  assert(i >= 0);
  return i;
}

/*
 * When we've read in counts from a file, we don't know how
 * to assign the paths from the counts.  We do so that the
 * synsets with the highest number of counts have the current
 * assignment.
 *
 * NOTE: NO LONGER USED!!!
 */
/*
void Gibbs::initializePathsFromCounts()
{
	int i,j,k;
	int word;
	for(i=0; i<this->nDocs; i++)
	{
		doc_t * doc = this->data->getDoc(i);
		word=0;
		for(j=0; j<doc->nterms; j++)
		{
			int wordID = this->wordIDs[i][j];
			int numPaths = this->walk->pathList[wordID]->numberPaths();
			int maxVal=-1;
			int topicID=0;
			int pathID=-1;

			for(k=0; k<this->nTopics; k++)
			{
				if (maxVal < this->topicCounts[i][j][k])
				{
					maxVal = this->topicCounts[i][j][k];
					topicID = k;
				}
			}

			this->assignments[i][j]->topic = topicID;
			maxVal = -1;

			for(k=0; k<numPaths; k++)
			{
				int synset = this->walk->pathList[wordID]->getPath(k)->lastSynset();
				int offset = this->walk->getSynset(synset)->ID;
				int sense = this->walk->pathList[wordID]->getSynsetID(offset);

				if(maxVal < this->senseCounts[i][j][sense])
				{
					maxVal = this->senseCounts[i][j][sense];
					pathID = k;
				}
			}

			for(k=0; k<doc->count[j]; k++)
			{
				if(numPaths>0)
				{
					Path * p = this->walk->pathList[wordID]->getPath(pathID);
					this->changePathCount(p, this->assignments[i][j]->topic, 1);
				}
				this->assignments[i][word]->path = pathID;
				this->assignments[i][word++]->topic = topicID;
			}
		}
	}
}*/

/*
 * Sets the path counts and sample the word paths based 
 * on the path counts thus far.  This should hopefully
 * speed up how long it takes us to converge.
 */
void Gibbs::initializeCounts()
{
  int i,j;
  
  for(i=0; i < this->nDocs; i++)
    {
      if(i%100==0)
        cout << "      " << i << "/" << this->nDocs << endl;
      doc_t * doc = this->data->getDoc(i);
      this->setTopicTotals(i);
      
      for(j=0; j<doc->total; j++)
        {
          // Get the data for this word
          int topic = this->assignments[i][j]->topic;
          int path = this->assignments[i][j]->path;
          int word = this->wordIDs[i][j];
          
          // Decrement the (uniformly random) topic assignment
          // so we can resample
          //this->topicTotals[topic]--;

          // Get new topic probs
          for(topic=0; topic<this->nTopics; topic++)
            this->tempTopicProb[topic] = this->topicWordProbability(topic, j, word);
          topic = logSample(this->tempTopicProb, this->nTopics);
          
          // Update the true count
          this->topicTotals[topic]++;
          
          // Update the topic
          this->assignments[i][j]->topic = topic;
          
			// If this isn't in WN, we don't count a path
          if(path==-1)
            continue;
          
          // Otherwise, sample from the new topic
          path = samplePath(topic, word);
          
          // Now set the path counts (they weren't set before, 
          // so we didn't need to initially decrement)
          Path * p = this->walk->pathList[word]->paths[path];
          this->changePathCount(p, topic, 1);
          this->assignments[i][j]->path = path;
        }
    }
}

/*
 * Computes log probability of a word being in a given topic
 * given the topic assignments in the document
 */
double Gibbs::topicProbability(int topic, int docTotal)
{
	double prob = log(this->topicTotals[topic] + 
                    (this->tau/(double)this->nTopics));

	// We subtract one because one word isn't counted
	prob -= log(docTotal + this->tau);	

	/*
	cout << "TP (t=" << topic << ",d=" << docNum << ") = (" << 
		this->topicTotals[topic] << "+" << this->tau/(float)this->nTopics << 
		") / (" << doc->total << "+" << this->tau << "-1)" << endl;
	*/

	assert(prob <= 0);
	assert(!my_isnan(prob));
	return prob;
}
/*
 * Computes log probability of the wordID th word being in a given
 * topic given all of the other topic assignments *and* paths in the document
 */
double Gibbs::topicWordProbability(int topic, int docTotal, int wordID)
{
	double prob = safe_log(0.0);
	double tp = this->topicProbability(topic, docTotal);
	int numberPaths = this->walk->pathList[wordID]->numberPaths();

	int i;

	//cout << "       TOPIC " << topic << endl;

	for(i=0; i<numberPaths; i++)
	{
		double pathProb = this->topics[topic]->pathProb
			(this->walk->pathList[wordID]->paths[i]);
		prob = log_sum(prob, pathProb);
		//cout << "      path " << i << " " << exp(prob) << "= p'+ " << exp(pathProb) << endl;
	}

	if(numberPaths > 0)
		prob += tp;
	else
		cout << wordID << ", " << this->walk->wordList[wordID] << " has no words" << endl;
	
	assert(prob < 0);

	return prob;
}

Gibbs::~Gibbs()
{
  int i,j;
  
  for(i=0; i<this->nDocs; i++) {
    doc_t * doc = this->data->getDoc(i);
    for(j=0; j < doc->total; j++) {
      delete this->assignments[i][j];
    }
    
    for(j=0; j < doc->nterms; j++) {
      delete this->senseCounts[i][j];
      delete this->topicCounts[i][j];
    }

    delete this->assignments[i];
    delete this->senseCounts[i];
    delete this->topicCounts[i];
    delete this->wordIDs[i];
  }

  delete this->assignments;
  delete this->senseCounts;
  delete this->topicCounts;
  
  for(i=0; i<this->nTopics; i++) {
    delete this->topics[i];
  }
  delete this->topics;
}

Gibbs::Gibbs(WN * walk, int numTopics, SuperCorpus * data, double tau, string output, bool hangWords, double weightPaths, bool topicCache, bool cheat)
{
  int i,j,k,word;
  this->tau = tau;
  this->data = data;
  this->walk = walk;
  this->output = output;
  this->nTopics = numTopics;
  this->nDocs = data->numberDocs();
  this->loadCheat = cheat;
  
  this->tempPathProb = new double [MAX_PATHS];
  this->tempTopicProb = new double [this->nTopics];
  
  this->topicTotals = new int[this->nTopics];
  this->assignments = new WordState ** [this->nDocs];
  this->senseCounts = new int ** [this->nDocs];
  this->topicCounts = new int ** [this->nDocs];
  this->wordIDs = new int * [this->nDocs];
  
  for(i=0; i<this->nDocs; i++) {
    doc_t * doc = data->getDoc(i);
    this->assignments[i] = new WordState * [doc->total];
    this->senseCounts[i] = new int * [doc->nterms];
    this->topicCounts[i] = new int * [doc->nterms];
    this->wordIDs[i] = new int [doc->total];
    
    word = 0;
    for(j=0; j<doc->nterms; j++) {
      //cout << i << " " << j << " " << this->walk->wordList[doc->word[j]];
      int synsets = this->walk->pathList[doc->word[j]]->numberSynsets();
      //cout << " " << synsets;
      
      this->senseCounts[i][j] = new int [synsets];
      this->topicCounts[i][j] = new int [this->nTopics];
      
      for(k = 0; k < synsets; k++) {
        this->senseCounts[i][j][k] = 0;
      }
      for(k = 0; k < this->nTopics; k++) {
        this->topicCounts[i][j][k] = 0;
      }
      
      for(k=0; k<doc->count[j]; k++) {
        this->wordIDs[i][word] = doc->word[j];
        // k keeps track of the instance of the word we're on
        
        //if(walk->pathList[doc->word[j]]->numberPaths()==0)
        //  cout << this->wordIDs[i][word] << " " << this->walk->wordList[this->wordIDs[i][word]] << endl;
        
        this->assignments[i][word] = new WordState(walk->pathList[doc->word[j]]->numberPaths(), numTopics);
        if(this->data->getTopic(i,j) >= 0)
          this->assignments[i][word]->topic = this->data->getTopic(i,j);
        word++;
      }
    }
    assert(word==doc->total);
  }
  
  this->topics = new TopicWalk * [numTopics];
  for(i=0; i<numTopics; i++) {
    this->topics[i] = new TopicWalk(this->walk, weightPaths, topicCache);
  }
}

void Gibbs::changePathCount(Path * p, int topic, double change)
{
  this->topics[topic]->changeCounts(p, change);	
}
