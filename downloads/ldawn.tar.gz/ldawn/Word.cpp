#include "Word.h"


int Word::numberSynsets()
{
	return (int)this->synsets.size();
}

int Word::numberPaths()
{
	return (int)this->paths.size();
}

void Word::printSynsets()
{
     map <int, int>::iterator iter;
      for(iter=this->synsets.begin();
          iter!=this->synsets.end();
          iter++)
        {
          cout << iter->first << " ";
        }
      cout << endl;
}

Path * Word::getPath(int id)
{
	//cout << "Getting path " << id << " of " << this->paths.size() << endl;
	if(id >= (int)this->paths.size())
		cerr << "Invalid path for word: " << id << "(" << (int)this->paths.size() << ")" << endl;
	assert(id < (int)this->paths.size());
	return this->paths[id];
}

/*
 * We need to know the relative number of this synset
 * for this word
 */
int Word::getSynsetID(int synset)
{
  if(this->synsets.find(synset)==this->synsets.end())
    {
      //cout << "Looking for " << synset << " in ";
      this->printSynsets();
    }

	assert(this->synsets.find(synset)!=this->synsets.end());
	return this->synsets[synset];
}

void Word::insertSynset(int synset)
{
	int ns = this->numberSynsets();
	if(this->synsets.end()==this->synsets.find(synset))
	{
		this->synsets[synset]=ns;
		//cout << "Added " << synset << " to " << synsets[synset] << ":" << " ";
    //this->printSynsets();
	}
  /*
    Debug code removed
	else
	{
		cout << "Key already exists for " << synset << " (" << synsets[synset] << ") " << this->numberSynsets() << endl;
	}
  */
}

void Word::sortPaths()
{
	int swapped=1;
	int pathSize=(int)paths.size();
    int i;

    while (swapped)
    {
      swapped = 0;
      for(i=0; i<pathSize-1; i++)
      {
        if(paths[i]->lastSynset() > paths[i+1]->lastSynset())
        {
          Path* temp = paths[i];
          paths[i] = paths[i+1];
          paths[i+1] = temp;
          swapped = 1;
        }
      }
    }
}

void Word::printPaths(int id)
{
	int i;
	unsigned int j;
	cout << "Word " << id << " has " << this->numberPaths() << " paths." << endl;
	for (i=0; i<this->numberPaths(); i++)
	{
		cout << "Path: ";
		for(j=0; j<paths[i]->synset.size(); j++)
			cout << paths[i]->synset[j] << " ";
		cout << endl;
	}
}
