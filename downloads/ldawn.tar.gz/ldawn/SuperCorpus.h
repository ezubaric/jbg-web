

#ifndef SUPERCORPUS_INCLUDED
#define SUPERCORPUS_INCLUDED

#include "data.h"
#include <string>
#include <iostream>
#include <fstream>
#include <map>

using namespace std;

class SuperCorpus {

public:
	SuperCorpus(int numberCorpora);
	~SuperCorpus();
	void addCorpus(string name, bool answer, bool topic, int topics, bool cheat);
	doc_t * getDoc(int doc);
	int getTopic(int doc, int word);
	int numberDocs();

	// This is so SuperCorpus can disambiguate
	friend class Gibbs;

private:
	bool * hasAnswer;
	corpus_t ** corpora;
	int *** senses;
	int *** topics;
	bool * hasTopic;
	int nDocs;
	int *** words;
	int ** totalWords;
	int nCorpora;
};

#endif
