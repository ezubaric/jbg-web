#include "gsl-wrappers.h"

//static gsl_rng* RANDOM_NUMBER_GENERATOR = NULL;

/*
 * safe logarithm function
 *
 */

double safe_log(double x)
{
    if (x == 0)
    {
        return(-1e4);
    }
    else
    {
        return(log(x));
    }
}

// convert int to string
string itos(int i)	
{
	stringstream s;
	s << i;
	return s.str();
}

// convert double to string
string dtos(double d)	
{
	stringstream s;
	s << d;
	return s.str();
}

bool my_isnan(double x)
{ return x != x; }


/*
 * given log(a) and log(b), return log(a+b)
 *
 */

double log_sum(double log_a, double log_b)
{
  double v;

  if (my_isnan(log_a)) return log_b;
  if (my_isnan(log_b)) return log_a;

  if (log_a == -1) return(log_b);

  if (log_a < log_b)
  {
      v = log_b+log(1 + exp(log_a-log_b));
  }
  else
  {
      v = log_a+log(1 + exp(log_b-log_a));
  }
  return(v);
}


void vinc(gsl_vector* v, int i, double x)
{
    vset(v, i, vget(v, i) + x);
}

void minc(gsl_matrix* m, int i, int j, double x)
{
    mset(m, i, j, mget(m, i, j) + x);
}


void msetrow(gsl_matrix* m, int r, const gsl_vector* val)
{
    unsigned int i;
    gsl_vector v = gsl_matrix_row(m, r).vector;
    for (i = 0; i < v.size; i++)
        vset(&v, i, vget(val, i));
}


void msetcol(gsl_matrix* m, int r, const gsl_vector* val)
{
    unsigned int i;
    gsl_vector v = gsl_matrix_column(m, r).vector;
    for (i = 0; i < v.size; i++)
        vset(&v, i, vget(val, i));
}


/*
 * compute the column sums of a matrix
 *
 */

void col_sum(gsl_matrix* m, gsl_vector* val)
{
    unsigned int i, j;
    gsl_vector_set_all(val, 0);

    for (i = 0; i < m->size1; i++)
        for (j = 0; j < m->size2; j++)
            vinc(val, j, mget(m, i, j));
}


/*
 * print a vector to standard out
 *
 */

void vct_printf(const gsl_vector * v)
{
    unsigned int i;
    for (i = 0; i < v->size; i++)
	printf("%5.5f ", vget(v, i));
    printf("\n\n");
}


/*
 * print a matrix to standard out
 *
 */

void mtx_printf(const gsl_matrix * m)
{
    unsigned int i, j;
    for (i = 0; i < m->size1; i++)
    {
	for (j = 0; j < m->size2; j++)
	    printf("%5.5f ", mget(m, i, j));
	printf("\n");
    }
}


/*
 * read/write a vector/matrix from a file
 *
 */

void vct_fscanf(const char* filename, gsl_vector* v)
{
//    outlog(stderr, "[GSL] reading %d vector from %s", v->size, filename);
    FILE* fileptr;
    fileptr = fopen(filename, "r");
    gsl_vector_fscanf(fileptr, v);
    fclose(fileptr);
}

void mtx_fscanf(const char* filename, gsl_matrix * m)
{
//    outlog(stderr, "[GSL] reading %d x %d matrix from %s",
//   m->size1, m->size2, filename);
    FILE* fileptr;
    fileptr = fopen(filename, "r");
    gsl_matrix_fscanf(fileptr, m);
    fclose(fileptr);
}

void vct_fprintf(const char* filename, gsl_vector* v)
{
    //outlog(stderr, "[GSL] writing %d vector to %s", v->size, filename);
    FILE* fileptr;
    fileptr = fopen(filename, "w");
    gsl_vector_fprintf(fileptr, v, "%20.17e");
    fclose(fileptr);
}


void mtx_fprintf(const char* filename, const gsl_matrix * m)
{
//    outlog(stderr, "[GSL] writing %d x %d matrix to %s",
           //m->size1, m->size2, filename);
    FILE* fileptr;
    fileptr = fopen(filename, "w");
    gsl_matrix_fprintf(fileptr, m, "%20.17e");
    fclose(fileptr);
}


/*
 * matrix inversion using blas
 *
 */

void matrix_inverse(gsl_matrix* m, gsl_matrix* inverse)
{
    gsl_matrix *lu;
    gsl_permutation* p;
    int signum;

    p = gsl_permutation_alloc(m->size1);
    lu = gsl_matrix_alloc(m->size1, m->size2);

    gsl_matrix_memcpy(lu, m);
    gsl_linalg_LU_decomp(lu, p, &signum);
    gsl_linalg_LU_invert(lu, p, inverse);

    gsl_matrix_free(lu);
    gsl_permutation_free(p);
}


/*
 * log determinant using blas
 *
 */

double log_det(gsl_matrix* m)
{
    gsl_matrix* lu;
    gsl_permutation* p;
    double result;
    int signum;

    p = gsl_permutation_alloc(m->size1);
    lu = gsl_matrix_alloc(m->size1, m->size2);

    gsl_matrix_memcpy(lu, m);
    gsl_linalg_LU_decomp(lu, p, &signum);
    result = gsl_linalg_LU_lndet(lu);

    gsl_matrix_free(lu);
    gsl_permutation_free(p);

    return(result);
}


/*
 * eigenvalues of a symmetric matrix using blas
 *
 */

void sym_eigen(gsl_matrix* m, gsl_vector* vals, gsl_matrix* vects)
{
    gsl_eigen_symmv_workspace* wk;
    gsl_matrix* mcpy;
    int r;

    mcpy = gsl_matrix_alloc(m->size1, m->size2);
    wk = gsl_eigen_symmv_alloc(m->size1);
    gsl_matrix_memcpy(mcpy, m);
    r = gsl_eigen_symmv(mcpy, vals, vects, wk);
    gsl_eigen_symmv_free(wk);
    gsl_matrix_free(mcpy);
}


/*
 * sum of a vector
 *
 */

double sum(const gsl_vector* v)
{
    double val = 0;
    int i, size = (int)v->size;
    for (i = 0; i < size; i++)
        val += vget(v, i);
    return(val);
}


/*
 * take log of each element
 *
 */

void vct_log(gsl_vector* v)
{
    int i, size = (int)v->size;
    for (i = 0; i < size; i++)
        vset(v, i, safe_log(vget(v, i)));
}


/*
 * l2 norm of a vector
 *
 */

double norm(gsl_vector *v)
{
    double val = 0;
    unsigned int i;

    for (i = 0; i < v->size; i++)
        val += vget(v, i) * vget(v, i);
    return(sqrt(val));
}


int randomInteger(int maxrand)
{
	return (rand() % maxrand);	
}

/*
 * draw K random integers from 0..N-1
 *
 *

void choose_k_from_n(int k, int n, int* result)
{
    int i, x[n];

    if (RANDOM_NUMBER_GENERATOR == NULL)
        RANDOM_NUMBER_GENERATOR = gsl_rng_alloc(gsl_rng_taus);
    for (i = 0; i < n; i++)
        x[i] = i;

    gsl_ran_choose (RANDOM_NUMBER_GENERATOR, (void *) result,  k,
                    (void *) x, n, sizeof(int));
}
*/

/*
 * normalize a vector in log space
 *
 * x_i = log(a_i)
 * v = log(a_1 + ... + a_k)
 * x_i = x_i - v
 *
 */

void log_normalize(gsl_vector* x)
{
    double v = vget(x, 0);
    unsigned int i;

    for (i = 1; i < x->size; i++)
        v = log_sum(v, vget(x, i));

    for (i = 0; i < x->size; i++)
        vset(x, i, vget(x,i)-v);
}


/*
 * normalize a positive vector
 *
 */

void normalize(gsl_vector* x)
{
    double v = 0;
    unsigned int i;

    for (i = 0; i < x->size; i++)
        v += vget(x, i);

    for (i = 0; i < x->size; i++)
        vset(x, i, vget(x, i) / v);
}


/*
 * exponentiate a vector
 *
 */

void vct_exp(gsl_vector* x)
{
    unsigned int i;

    for (i = 0; i < x->size; i++)
        vset(x, i, exp(vget(x, i)));
}


/*
 * maximize a function using its derivative
 *
 */

void optimize_fdf(int dim,
                  gsl_vector* x,
                  void* params,
                  void (*fdf)(const gsl_vector*, void*, double*, gsl_vector*),
                  void (*df)(const gsl_vector*, void*, gsl_vector*),
                  double (*f)(const gsl_vector*, void*),
                  double* f_val,
                  double* conv_val,
                  int* niter)
{
    gsl_multimin_function_fdf obj;
    obj.f = f;
    obj.df = df;
    obj.fdf = fdf;
    obj.n = dim;
    obj.params = params;

//    const gsl_multimin_fdfminimizer_type * method =
//        gsl_multimin_fdfminimizer_vector_bfgs;
    const gsl_multimin_fdfminimizer_type * method =
        gsl_multimin_fdfminimizer_conjugate_fr;

    gsl_multimin_fdfminimizer * opt =
        gsl_multimin_fdfminimizer_alloc(method, dim);

    gsl_multimin_fdfminimizer_set(opt, &obj, x, 0.01, 1e-3);

    int iter = 0, status;
    double converged, f_old = 0;
    do
    {
        iter++;
        status = gsl_multimin_fdfminimizer_iterate(opt);
        // assert(status==0);
        converged = fabs((f_old - opt->f) / (dim * f_old));
        // status = gsl_multimin_test_gradient(opt->gradient, 1e-3);
        // printf("f = %1.15e; conv = %5.3e; norm = %5.3e; niter = %03d\n",
        // opt->f, converged, norm(opt->gradient), iter);
        f_old = opt->f;
    }
    while (converged > 1e-8);
    // while (status == GSL_CONTINUE);
    *f_val = opt->f;
    *conv_val = converged;
    *niter = iter;
    gsl_multimin_fdfminimizer_free(opt);
}



/*
 * maximize a function
 *
 */

/* Jerry
void optimize_f(int dim,
                gsl_vector* x,
                void* params,
                double (*f)(const gsl_vector*, void*))
{
    gsl_multimin_function obj;
    obj.f = f;
    obj.n = dim;
    obj.params = params;

    const gsl_multimin_fminimizer_type * method =
        gsl_multimin_fminimizer_nmsimplex;

    gsl_multimin_fminimizer * opt =
        gsl_multimin_fminimizer_alloc(method, dim);

    gsl_vector * step_size = gsl_vector_alloc(dim);
    gsl_vector_set_all(step_size, 1);
    gsl_multimin_fminimizer_set(opt, &obj, x, step_size);

    int iter = 0, status;
    double converged, f_old;
    do
    {
        iter++;
        f_old = opt->fval;
        status = gsl_multimin_fminimizer_iterate(opt);
        converged = fabs((f_old - opt->fval) / f_old);
        printf("f = %1.15e; conv = %5.3e; size = %5.3e; niter = %03d\n",
               opt->fval, converged, opt->size, iter);
    }
    while ((converged > 1e-10) || (iter < 10000));
    // while (status == GSL_CONTINUE);
    printf("f = %1.15e; conv = %5.3e; niter = %03d\n",
           opt->fval, converged, iter);

    gsl_multimin_fminimizer_free(opt);
    gsl_vector_free(step_size);
}
*/

// lgamma.cpp -- log gamma function of real argument.
//      Algorithms and coefficient values from "Computation of Special
//      Functions", Zhang and Jin, John Wiley and Sons, 1996.
//
//  (C) 2003, C. Bond. All rights reserved.
//
//  Returns log(gamma) of real argument.
//  NOTE: Returns 1e308 if argument is 0 or negative.
//

double lgamma(double x)
{
    double x0,x2,xp,gl,gl0;
    int n=0,k=0;
    static double a[] = {
        8.333333333333333e-02,
       -2.777777777777778e-03,
        7.936507936507937e-04,
       -5.952380952380952e-04,
        8.417508417508418e-04,
       -1.917526917526918e-03,
        6.410256410256410e-03,
       -2.955065359477124e-02,
        1.796443723688307e-01,
       -1.39243221690590};
    
    x0 = x;
    if (x <= 0.0) return 1e308;
    else if ((x == 1.0) || (x == 2.0)) return 0.0;
    else if (x <= 7.0) {
        n = (int)(7-x);
        x0 = x+n;
    }
    x2 = 1.0/(x0*x0);
    xp = 2.0*M_PI;
    gl0 = a[9];
    for (k=8;k>=0;k--) {
        gl0 = gl0*x2 + a[k];
    }
    gl = gl0/x0+0.5*log(xp)+(x0-0.5)*log(x0)-x0;
    if (x <= 7.0) {
        for (k=1;k<=n;k++) {
            gl -= log(x0-1.0);
            x0 -= 1.0;
        }
    }
    return gl;
}
